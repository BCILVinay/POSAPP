﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WebPages_Download : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["FileName"] != null)
        {


            var fileName = Convert.ToString(Request.QueryString["FileName"]);

            Response.ContentType = "image/jpeg";
            var displayName = Path.GetFileNameWithoutExtension(fileName);
            var extn = Path.GetExtension(fileName);
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + (displayName + extn) + "");

            // Write the file to the Response
            const int bufferLength = 10000;
            byte[] buffer = new Byte[bufferLength];
            int length = 0;
            Stream download = null;
            try
            {
                download = new FileStream(fileName, FileMode.Open, FileAccess.Read);
                do
                {
                    if (Response.IsClientConnected)
                    {
                        length = download.Read(buffer, 0, bufferLength);
                        Response.OutputStream.Write(buffer, 0, length);
                        buffer = new Byte[bufferLength];
                    }
                    else
                    {
                        length = -1;
                    }
                }
                while (length > 0);
                Response.Flush();
                Response.End();
            }

            finally
            {
                if (download != null)
                    download.Close();
            }
        }
        else
        {
            Response.StatusCode = 404;
        }
    }
}