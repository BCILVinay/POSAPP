﻿using MobiVUE_ATS.DAL;
using MobiVUE_ATS.PRP;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ViewMovementRequest : System.Web.UI.Page
{
    AssetRquestDAL _assetRquestDAL = null;
    AssetReplacement_PRP oPRP;
    List<AssetRequestDTO> _viewAssetRequest
    {
        get
        {
            return Session["ViewMovementData"] == null ? new List<AssetRequestDTO>() : (List<AssetRequestDTO>)Session["ViewMovementData"];
        }
        set
        {
            Session["ViewMovementData"] = value;
        }
     
        
    }
    


    private bool IsViewRight
    {
        get
        {
            return ViewState["IsViewRight"] == null ? false : (bool)ViewState["IsViewRight"];
        }
        set
        {
            ViewState["IsViewRight"] = value;
        }
    }
    private bool IsSaveRight
    {
        get
        {
            return ViewState["IsSaveRight"] == null ? false : (bool)ViewState["IsSaveRight"];
        }
        set
        {
            ViewState["IsSaveRight"] = value;
        }
    }
    private bool IsEditRight
    {
        get
        {
            return ViewState["IsEditRight"] == null ? false : (bool)ViewState["IsEditRight"];
        }
        set
        {
            ViewState["IsEditRight"] = value;
        }
    }
    private bool IsDeleteRight
    {

        get
        {
            return ViewState["IsDeleteRight"] == null ? false : (bool)ViewState["IsDeleteRight"];
        }
        set
        {
            ViewState["IsDeleteRight"] = value;
        }

    }
    private bool IsExportRight
    {
        get
        {
            return ViewState["IsExportRight"] == null ? false : (bool)ViewState["IsExportRight"];
        }
        set
        {
            ViewState["IsExportRight"] = value;
        }
    }


    string strFilePath = string.Empty;
    private string LoggedInUser
    {
        get
        {
            return Session["CURRENTUSER"] == null ? string.Empty : Convert.ToString(Session["CURRENTUSER"]);
        }

    }
    private string LoggedInLocation
    {
        get
        {
            return Session["CurrentLocation"] == null ? string.Empty : Convert.ToString(Session["CurrentLocation"]);
        }
    }

    public string CurrentDBName
    {
        get
        {
            return Session["DATABASE"] == null ? string.Empty : Convert.ToString(Session["DATABASE"]);
        }
    }

    private AssetRequest AssetReceiveingRequest
    {
        get
        {
            return ViewState["AssetRequest"] == null ? null : (AssetRequest)ViewState["AssetRequest"];
        }
        set
        {
            ViewState["AssetRequest"] = value;
        }
    }

    private DateTime? RequestDateFrom = default(DateTime?);
    private DateTime? RequestDateTo = default(DateTime?);

    public ViewMovementRequest()
    {
        oPRP = new AssetReplacement_PRP();
        _assetRquestDAL = default(AssetRquestDAL);
    }
    ~ViewMovementRequest()
    {
        oPRP = null;
        _assetRquestDAL = null;
    }


    private void BindRequestStatus(DropDownList drpRequestStatus)
    {
        Array itemValues = System.Enum.GetValues(typeof(AssetRequestStage));
        foreach (int value in Enum.GetValues(typeof(AssetRequestStage)))
        {

            ListItem item = default(ListItem);
            switch (value)
            {
                //var name = Enum.GetName(enumerationType, value);
                case 0:
                    item = new ListItem("Select Status", Convert.ToString(value));
                    break;
                case 1:
                    item = new ListItem("Request Raised", Convert.ToString(value));
                    break;
                case 2:
                    item = new ListItem("PM Approved", Convert.ToString(value));
                    break;
                case 3:
                    item = new ListItem("CMF Approved", Convert.ToString(value));
                    break;
                case 4:
                    item = new ListItem("Clearance Approved", Convert.ToString(value));
                    break;
                case 5:
                    item = new ListItem("GatePass", Convert.ToString(value));
                    break;
                case 6:
                    item = new ListItem("Received", Convert.ToString(value));
                    break;
                case 7:
                    item = new ListItem("Clearance Received", Convert.ToString(value));
                    break;
                case 8:
                    item = new ListItem("PM Rejected", Convert.ToString(value));
                    break;
                case 9:
                    item = new ListItem("CMF Rejected", Convert.ToString(value));
                    break;
                case 10:
                    item = new ListItem("Clearance Rejected", Convert.ToString(value));
                    break;
                case 11:
                    item = new ListItem("Clearance Received Rejected", Convert.ToString(value));
                    break;
                default:

                    break;
            }
            drpRequestStatus.Items.Add(item);
        }
    }


    #region PAGE EVENTS
    /// <summary>
    /// Navigates to session expired page in case of user logs off/session expired.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Init(object sender, EventArgs e)
    {
        //if (Session["CURRENTUSER"] == null)
        //{
        //    Server.Transfer("SessionExpired.aspx");
        //}
        //oDAL = new AssetReplacement_DAL(Session["DATABASE"].ToString());
        //txtActiveInAssetCode.Focus();
    }

    /// <summary>
    /// Checking user group rights for Asset replacement operation.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Page.IsPostBack)
            {
                string _strRights = clsGeneral.GetRights("VIEW_MOVEMENT", (System.Data.DataTable)Session["UserRights"]);
                clsGeneral._strRights = _strRights.Split('^');

                this.IsViewRight = clsGeneral._strRights[0] == "0" ? false : true;
                this.IsSaveRight = clsGeneral._strRights[1] == "0" ? false : true;
                this.IsEditRight = clsGeneral._strRights[2] == "0" ? false : true;
                this.IsDeleteRight = clsGeneral._strRights[3] == "0" ? false : true;
                this.IsExportRight = clsGeneral._strRights[4] == "0" ? false : true;

                clsGeneral.LogUserOperationToLogFile(Session["CURRENTUSER"].ToString(), Session["COMP_NAME"].ToString(), "ASSET_ALLOCATION");
                if (!this.IsViewRight)
                {
                    Response.Redirect("UnauthorizedUser.aspx", false);
                }

                BindRequestStatus(drpRequestStatus);

            }

        }
        catch (Exception ex)
        {
            HandleExceptions(ex);
        }
    }
    #endregion
    #region Exception Handler
    private void HandleExceptions(Exception ex)
    {
        clsGeneral.LogErrorToLogFile(ex, "Asset Request");
        if (!ex.Message.ToString().Contains("Thread was being aborted."))
        {
            clsGeneral.ErrMsg = ex.Message.ToString(); try { string[] arrErr = ex.Message.ToString().Split('\n'); Session["ErrMsg"] = arrErr[0].ToString().Trim(); }
            catch { } Response.Redirect("Error.aspx");
        }
    }
    #endregion


    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            _assetRquestDAL = new AssetRquestDAL(this.CurrentDBName);
            var _searchCriteria = new AssetSearchCriteria()
                {
                    LocationCode = this.LoggedInLocation,
                    RequestId = txtRequestNo.Text.Trim(),
                    AssetCode = txtAssetCode.Text.Trim(),
                    RequestStage = (AssetRequestStage)Convert.ToInt32(drpRequestStatus.SelectedValue)
                };

            if (!ValidateSearchDate())
            {
                lblErrorMsg.Text = "Please enter valid date format dd/MMM/yyyy";
                return;
            }

            else if (ValidateSearchDate() == true
                && (RequestDateFrom != default(DateTime?) && RequestDateTo == default(DateTime?))
                || (RequestDateFrom == default(DateTime?) && RequestDateTo != default(DateTime?))
                )
            {
                lblErrorMsg.Text = "Please select request From and To date";
                return;
            }
            else if (ValidateSearchDate() == true && RequestDateFrom > RequestDateTo)
            {
                lblErrorMsg.Text = "Request From date should not be greater than To date";
                return;
            }
            else
            {
                _searchCriteria.RequestFrom = RequestDateFrom;
                _searchCriteria.RequestFrom = RequestDateTo;
            }


            _viewAssetRequest = _assetRquestDAL.GetViewAssetRequest(
               _searchCriteria
                );

            var ctr = _viewAssetRequest.Count();

            if (_viewAssetRequest.Count() > 0)
            {
                lblErrorMsg.Text = string.Format("Request found :{0} .", ctr);
            }
            else
            {
                lblErrorMsg.Text = "No request found !!!";
            }
            gvMovementRequest.DataSource = _viewAssetRequest;
            gvMovementRequest.DataBind();

        }
        catch (Exception ex)
        {
            this.HandleExceptions(ex);
        }
    }

    private bool ValidateSearchDate()
    {
        try
        {

            if (!string.IsNullOrEmpty(txtRequestFrom.Text))
            {
                var dt = txtRequestFrom.Text.Trim().Split('/');
                RequestDateFrom = new DateTime(Convert.ToInt32(dt[2]), Convert.ToInt32(AssetRquestDAL.GetMonth(dt[1])), Convert.ToInt32(dt[0]));
            }

            if (!string.IsNullOrEmpty(txtRequestTo.Text))
            {
                var dt = txtRequestTo.Text.Trim().Split('/');
                RequestDateTo = new DateTime(Convert.ToInt32(dt[2]), Convert.ToInt32(AssetRquestDAL.GetMonth(dt[1])), Convert.ToInt32(dt[0]));
            }
            return true;
        }
        catch (Exception)
        {
            return false;
        }
    }
    protected void btnExport_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            if (this._viewAssetRequest!=null && this._viewAssetRequest.Count()>0)
            {
                Response.Clear();
                Response.Buffer = true;
                Response.ClearContent();
                Response.ClearHeaders();
                Response.Charset = "";
                //DataTable dt = this._viewAssetRequest;
                //DataSet dsExport = new DataSet();
                System.IO.StringWriter tw = new System.IO.StringWriter();
                System.Web.UI.HtmlTextWriter hw = new System.Web.UI.HtmlTextWriter(tw);
                string FileName = "ViewMovementData_" + DateTime.Now + ".xls";
                DataGrid dgGrid = new DataGrid();
                dgGrid.DataSource = this._viewAssetRequest;
                dgGrid.HeaderStyle.Font.Bold = true;
                dgGrid.DataBind();
                dgGrid.RenderControl(hw);
                Response.ContentType = "application/vnd.ms-excel";
                Response.AddHeader("Content-Disposition", "attachment;filename=" + FileName);
                this.EnableViewState = false;
                Response.Write(tw.ToString());
                Response.End();

            }
        }
        catch (Exception ex)
        {
            HandleExceptions(ex);
        }
    }
}