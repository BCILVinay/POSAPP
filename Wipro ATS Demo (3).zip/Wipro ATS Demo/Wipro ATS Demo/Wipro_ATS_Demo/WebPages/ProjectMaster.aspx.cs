﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using MobiVUE_ATS.DAL;
using MobiVUE_ATS.PRP;

public partial class ProjectMaster : System.Web.UI.Page
{
    ProjectMaster_DAL oDAL;
    ProjectMaster_PRP oPRP;
    public ProjectMaster()
    {
        oPRP = new ProjectMaster_PRP();
    }
    ~ProjectMaster()
    {
        oDAL = null; oPRP = null;
    }

    #region PAGE EVENTS
    /// <summary>
    /// Navigates to session expired page in case of user logs off
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Init(object sender, EventArgs e)
    {
        if (Session["CURRENTUSER"] == null)
        {
            Server.Transfer("SessionExpired.aspx");
        }
        oDAL = new ProjectMaster_DAL(Session["DATABASE"].ToString());
    }

    /// <summary>
    /// Check user rights for Project master operations.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                if (Session["CURRENTUSER"].ToString() != "test")
                {
                    string _strRights = clsGeneral.GetRights("PROJECT_MASTER", (DataTable)Session["UserRights"]);
                    clsGeneral._strRights = _strRights.Split('^');
                    clsGeneral.LogUserOperationToLogFile(Session["CURRENTUSER"].ToString(), Session["COMP_NAME"].ToString(), "PROJECT_MASTER");
                    if (clsGeneral._strRights[0] == "0")
                    {
                        Response.Redirect("UnauthorizedUser.aspx", false);
                    }
                }
                PopulateDepartment(Session["COMPANY"].ToString());
                GetProjectDetails(Session["COMPLOCATION"].ToString());                
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    #endregion

    #region PRIVATE FUNCTIONS
    /// <summary>
    /// Populate employee code/name for Project owner selection.
    /// </summary>
    private void PopulateEmployee(string CompCode)
    {
        //ddlProcOwner.DataSource = null;
        //DataTable dt = new DataTable();
        //dt = oDAL.GetEmployee(CompCode);
        //ddlProcOwner.DataSource = dt;
        //ddlProcOwner.DataValueField = "EMPLOYEE_CODE";
        //ddlProcOwner.DataTextField = "EMPLOYEE_NAME";
        //ddlProcOwner.DataBind();
        //ddlProcOwner.Items.Insert(0, "-- Select Owner --");
    }

    /// <summary>
    /// Populate department code/name from dropdown selection.
    /// </summary>
    private void PopulateDepartment(string CompCode)
    {
        ddlDepartment.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.GetDepartment(CompCode);
        ddlDepartment.DataSource = dt;
        ddlDepartment.DataValueField = "DEPT_CODE";
        ddlDepartment.DataTextField = "DEPT_NAME";
        ddlDepartment.DataBind();
        ddlDepartment.Items.Insert(0, "-- Select Department --");
    }

    /// <summary>
    /// Catch unhandled exceptions.
    /// </summary>
    /// <param name="ex"></param>
    public void HandleExceptions(Exception ex)
    {
        clsGeneral.LogErrorToLogFile(ex, "Project Master");
        if (!ex.Message.ToString().Contains("Thread was being aborted."))
        {
            //oBL_ClsLog.SaveLog(Convert.ToString(Session["CURRENTUSER"]).Trim(), "Exception", ex.Message.ToString(), "GROUP MASTER");
            clsGeneral.ErrMsg = ex.Message.ToString(); try { string[] arrErr = ex.Message.ToString().Split('\n'); Session["ErrMsg"] = arrErr[0].ToString().Trim(); }
            catch { } Server.Transfer("Error.aspx");
        }
    }

    /// <summary>
    /// Populate Project master details into gridview.
    /// </summary>
    private void GetProjectDetails(string LocCode)
    {
        gvProjectMaster.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.GetProjectDetails(LocCode);
        gvProjectMaster.DataSource = Session["PROJECT"] = dt;
        gvProjectMaster.DataBind();
    }
    #endregion

    #region SUBMIT EVENT
    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (clsGeneral._strRights[1] == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }       
            oPRP.DeptCode=ddlDepartment.SelectedValue ;
            oPRP.ProjectCode = txtProjectCode.Text.Trim().ToUpper();
            oPRP.ProjectName = txtProjectName.Text.Trim();
            oPRP.ProejctManagerName = txtPMName.Text.Trim().ToUpper();
            oPRP.ProejctManagerEmailId = txtPMEmailId.Text.Trim().ToUpper();
            oPRP.Remarks = "";
            oPRP.Active = chkSetStatus.Checked;
            oPRP.CreatedBy = Session["CURRENTUSER"].ToString();
            oPRP.LocCode = Session["COMPLOCATION"].ToString();
            oPRP.CompCode = Session["COMPANY"].ToString();
            bool bResp = oDAL.SaveProject(oPRP);
            if (!bResp)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Please Note : Duplicate Project Code cannot be saved.');", true);
                txtProjectCode.Focus();
            }
            else
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ClearFields", "ClearFields();", true);
                upSubmit.Update();
            }
            GetProjectDetails(Session["COMPLOCATION"].ToString());
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Export gridview data to excel sheet.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnExport_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            if (clsGeneral._strRights[4] == "0")
            {
                Response.Redirect("UnauthorizedUser.aspx");
            }
            if (gvProjectMaster.Rows.Count > 0)
            {
                Response.Clear();
                DataTable dt = (DataTable)Session["PROJECT"];
                DataSet dsExport = new DataSet();
                System.IO.StringWriter tw = new System.IO.StringWriter();
                System.Web.UI.HtmlTextWriter hw = new System.Web.UI.HtmlTextWriter(tw);
                DataGrid dgGrid = new DataGrid();
                dgGrid.DataSource = dt;
                hw.WriteLine("<b><u><font size='5'> " + Session["COMPLOCATION"].ToString() + "</font></u></b>");
                hw.WriteLine("<br>");
                hw.WriteLine("<b><u><font size='4'> Project Master</font></u></b>");
                hw.WriteLine("<br>");
                dgGrid.HeaderStyle.Font.Bold = true;
                dgGrid.DataBind();
                dgGrid.RenderControl(hw);
                Response.ContentType = "application/vnd.ms-excel";
                Response.AddHeader("Content-Disposition", "attachment;filename=ProjectMaster.xls");  
                this.EnableViewState = false;
                Response.Write(tw.ToString());
                Response.End();
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    #endregion

    #region GRIDVIEW EVENTS
    /// <summary>
    /// Gets Project details in delete mode
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvProjectMaster_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            if (clsGeneral._strRights[3] == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            GridViewRow gvRow = gvProjectMaster.Rows[e.RowIndex];
            oPRP.ProjectCode = ((Label)(gvRow.FindControl("lblProcCode"))).Text.Trim();
            bool DelRslt = oDAL.DeleteProject(oPRP.ProjectCode, Session["COMPLOCATION"].ToString());
            //if (DelRslt == "Project_MAPPED")
            //{
            //    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg",
            //       "ShowErrMsg('Please Note : Project is mapped with employees, hence cannot be deleted.');", true);
            //    return;
            //}
            //if (DelRslt == "ASSET_MAPPED")
            //{
            //    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg",
            //       "ShowErrMsg('Please Note : Project is mapped with assets, hence cannot be deleted.');", true);
            //    return;
            //}
            if (DelRslt)
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg",
                       "ShowErrMsg('Please Note : Project deleted successfully.');", true);
            GetProjectDetails(Session["COMPLOCATION"].ToString());
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Gets Project details in edit mode
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvProjectMaster_RowEditing(object sender, GridViewEditEventArgs e)
    {
        try
        {
            if (clsGeneral._strRights[2] == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }

            GridViewRow gvRow = (GridViewRow)gvProjectMaster.Rows[e.NewEditIndex];

            ViewState["DEPT"] = ((Label)gvRow.FindControl("lblDeptCode")).Text.Trim();
            gvProjectMaster.EditIndex = e.NewEditIndex;
            GetProjectDetails(Session["COMPLOCATION"].ToString());
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    
    /// <summary>
    /// Project details can be updated
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvProjectMaster_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            if (clsGeneral._strRights[2] == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }

            GridViewRow gvRow = gvProjectMaster.Rows[e.RowIndex];
            oPRP.DeptCode = ((DropDownList)(gvRow.FindControl("ddlEDeptCode"))).SelectedValue.ToString();
            oPRP.ProjectCode = ((Label)(gvRow.FindControl("lblEProcCode"))).Text.Trim();
            oPRP.ProjectName = ((TextBox)(gvRow.FindControl("txtEProcName"))).Text.Trim();
            oPRP.ProejctManagerName = ((TextBox)(gvRow.FindControl("txtProjectManagerName"))).Text.Trim(); 
            oPRP.ProejctManagerEmailId = ((TextBox)(gvRow.FindControl("txtProjectManagerEmailId"))).Text.Trim(); 
            //if (((DropDownList)(gvRow.FindControl("ddlEProcOwner"))).SelectedValue.ToString() != "-- Select Owner --")
            //    oPRP.ProjectOwner = ((DropDownList)(gvRow.FindControl("ddlEProcOwner"))).SelectedValue.ToString();
            //else
            //    oPRP.ProjectOwner = "";
            oPRP.Remarks = "";
            oPRP.Active = ((CheckBox)(gvRow.FindControl("chkEditActive"))).Checked;
            oPRP.ModifiedBy = Session["CURRENTUSER"].ToString();
            oPRP.LocCode = Session["COMPLOCATION"].ToString();
            oDAL.UpdateProject(oPRP);

            gvProjectMaster.EditIndex = -1;
            GetProjectDetails(Session["COMPLOCATION"].ToString());
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Project details are cancelled from edit/update/delete
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvProjectMaster_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        try
        {
            gvProjectMaster.EditIndex = -1;
            GetProjectDetails(Session["COMPLOCATION"].ToString());
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    
    /// <summary>
    /// populate Project owner dropdownlist inside gridview for edit operation.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvProjectMaster_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //DropDownList ddlEProcOwner = (DropDownList)e.Row.FindControl("ddlEProcOwner");
                //if (ddlEProcOwner != null)
                //{
                //    ddlEProcOwner.DataSource = oDAL.GetEmployee(Session["COMPANY"].ToString());
                //    ddlEProcOwner.DataTextField = "EMPLOYEE_NAME";
                //    ddlEProcOwner.DataValueField = "EMPLOYEE_CODE";
                //    ddlEProcOwner.DataBind();
                //    ddlEProcOwner.Items.Insert(0, "-- Select Owner --");
                //    if (ViewState["OWNER"].ToString() != "")
                //        ddlEProcOwner.SelectedIndex = ddlEProcOwner.Items.IndexOf(ddlEProcOwner.Items.FindByText(ViewState["OWNER"].ToString()));
                //    else
                //    {
                //        ddlEProcOwner.SelectedIndex = ddlEProcOwner.Items.IndexOf(ddlEProcOwner.Items.FindByText("-- Select Owner --"));
                //    }
                //}

                //DropDownList ddlEDeptCode = (DropDownList)e.Row.FindControl("ddlEDeptCode");
                //if (ddlEDeptCode != null)
                //{
                //    ddlEDeptCode.DataSource = oDAL.GetDepartment(Session["COMPANY"].ToString());
                //    ddlEDeptCode.DataTextField = "DEPT_NAME";
                //    ddlEDeptCode.DataValueField = "DEPT_CODE";
                //    ddlEDeptCode.DataBind();
                //    ddlEDeptCode.Items.Insert(0, "-- Select Department --");
                //    if (ViewState["DEPT"].ToString() != "")
                //        ddlEDeptCode.SelectedIndex = ddlEDeptCode.Items.IndexOf(ddlEDeptCode.Items.FindByText(ViewState["DEPT"].ToString()));
                //    else
                //    {
                //        ddlEDeptCode.SelectedIndex = ddlEDeptCode.Items.IndexOf(ddlEDeptCode.Items.FindByText("-- Select Owner --"));
                //    }
                //}

                ImageButton imagebuttonEdit = (ImageButton)e.Row.FindControl("imagebuttonEdit");
                ImageButton imagebuttonDelete = (ImageButton)e.Row.FindControl("imagebuttonDelete");
                if (imagebuttonEdit != null)
                {
                    if (clsGeneral._strRights[2] == "0")
                        imagebuttonEdit.Enabled = false;
                    else
                        imagebuttonEdit.Enabled = true;
                }
                if (imagebuttonDelete != null)
                {
                    if (clsGeneral._strRights[3] == "0")
                        imagebuttonDelete.Enabled = false;
                    else
                        imagebuttonDelete.Enabled = true;
                }

                DropDownList ddlEDeptCode = (DropDownList)e.Row.FindControl("ddlEDeptCode");
                if (ddlEDeptCode != null)
                {
                    ddlEDeptCode.DataSource = oDAL.GetDepartment(Session["COMPANY"].ToString());
                    ddlEDeptCode.DataTextField = "DEPT_NAME";
                    ddlEDeptCode.DataValueField = "DEPT_CODE";
                    ddlEDeptCode.DataBind();
                    ddlEDeptCode.Items.Insert(0, "-- Select Department --");
                    if (ViewState["DEPT"].ToString() != "")
                        ddlEDeptCode.SelectedIndex = ddlEDeptCode.Items.IndexOf(ddlEDeptCode.Items.FindByText(ViewState["DEPT"].ToString()));
                    else
                    {
                        ddlEDeptCode.SelectedIndex = ddlEDeptCode.Items.IndexOf(ddlEDeptCode.Items.FindByText("-- Select Owner --"));
                    }

                }
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Project master gridview page index changing event.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvProjectMaster_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvProjectMaster.PageIndex = e.NewPageIndex;
            GetProjectDetails(Session["COMPLOCATION"].ToString());
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    #endregion
}