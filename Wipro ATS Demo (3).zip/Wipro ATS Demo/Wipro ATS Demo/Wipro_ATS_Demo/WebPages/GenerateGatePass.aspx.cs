﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Text;
using System.Web;
using System.Net.Mail;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using MobiVUE_ATS.DAL;
using MobiVUE_ATS.PRP;

public partial class GenerateGatePass : System.Web.UI.Page
{
    GatePassGeneration_DAL oDAL;
    GatePassGeneration_PRP oPRP;
    bool bTransOpen = false;
    public GenerateGatePass()
    {
        oPRP = new GatePassGeneration_PRP();
    }
    ~GenerateGatePass()
    {
        oDAL = null; oPRP = null;
    }

    #region PAGE EVENTS
    /// <summary>
    /// Navigates to session expired page in case of user logs off/session expired.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Init(object sender, EventArgs e)
    {
        if (Session["CURRENTUSER"] == null)
        {
            Server.Transfer("SessionExpired.aspx");
        }
        oDAL = new GatePassGeneration_DAL(Session["DATABASE"].ToString());
    }

    /// <summary>
    /// Checking user group rights for gate pass generation operation.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                HttpContext.Current.Response.Cache.SetAllowResponseInBrowserHistory(false);
                string _strRights = clsGeneral.GetRights("GATEPASS_GENERATION", (DataTable)Session["UserRights"]);
                clsGeneral._strRights = _strRights.Split('^');
                clsGeneral.LogUserOperationToLogFile(Session["CURRENTUSER"].ToString(), Session["COMP_NAME"].ToString(), "GATEPASS_GENERATION");
                if (clsGeneral._strRights[0] == "0")
                {
                    Response.Redirect("UnauthorizedUser.aspx", false);
                }
                ddlAssetType.SelectedValue = clsGeneral.gStrAssetType;
                lblAssetType.Text = clsGeneral.gStrAssetType;
                PopulateCategory(lblAssetType.Text.Trim());
                PopulateLocation();
                if ((string)Request.QueryString["GatePassCode"] != null)
                {
                    string _GatePassCode = Request.QueryString["GatePassCode"].ToString();
                    GetGatePassDetails(_GatePassCode);
                }
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    #endregion

    #region PRIVATE FUNCTIONS
    /// <summary>
    /// Populate asset details based on filters supplied.
    /// </summary>
    private void PopulateAssetDetails()
    {
        gvAssets.DataSource = null;
        DataTable dt = new DataTable();
        oPRP.AssetCode = "";
        if (ddlAssetType.SelectedIndex != 0)
            oPRP.AssetType = ddlAssetType.SelectedValue.ToString();
        else
            oPRP.AssetType = "";
        string[] LocParts = { };
        if (lblLocCode.Text != "0")
        {
            LocParts = lblLocCode.Text.Trim().Split('-');
            if (LocParts[2] == "00")
                oPRP.AssetLocation = LocParts[0] + "-" + LocParts[1];
            else if (LocParts[3] == "00")
                oPRP.AssetLocation = LocParts[0] + "-" + LocParts[1] + "-" + LocParts[2];
            else if (LocParts[4] == "00")
                oPRP.AssetLocation = LocParts[0] + "-" + LocParts[1] + "-" + LocParts[2] + "-" + LocParts[3];
            else if (LocParts[5] == "00")
                oPRP.AssetLocation = LocParts[0] + "-" + LocParts[1] + "-" + LocParts[2] + "-" + LocParts[3] + "-" + LocParts[4];
            else
                oPRP.AssetLocation = LocParts[0] + "-" + LocParts[1] + "-" + LocParts[2] + "-" + LocParts[3] + "-" + LocParts[4] + "-" + LocParts[5];
        }
        else
            oPRP.AssetLocation = "";

        if (ddlAssetMake.SelectedIndex != 0)
            oPRP.AssetMake = ddlAssetMake.SelectedValue.ToString();
        else
            oPRP.AssetMake = "";
        for (int iCnt = 0; iCnt < lstModelName.Items.Count; iCnt++)
        {
            if (lstModelName.Items[iCnt].Selected)
                oPRP.ModelName += lstModelName.Items[iCnt].Value.ToString() + ",";
        }
        if (oPRP.ModelName != null)
        {
            oPRP.ModelName = oPRP.ModelName.TrimEnd(',');
            oPRP.ModelName = oPRP.ModelName.Replace(",", "','");
            oPRP.ModelName = "'" + oPRP.ModelName + "'";
        }
        else
            oPRP.ModelName = "";
        if (ddlAssetType.SelectedIndex != 0)
            oPRP.AssetType = ddlAssetType.SelectedValue.ToString();
        if (ddlAssetCategory.SelectedIndex != 0)
            oPRP.CategoryCode = ddlAssetCategory.SelectedValue.ToString();
        else
            oPRP.CategoryCode = "";
        oPRP.CompCode = Session["COMPANY"].ToString();
        dt = oDAL.GetAssetsWithLocation(oPRP);
        if (dt.Rows.Count > 0)
        {
            gvAssets.DataSource = dt;
            gvAssets.DataBind();
            gvAssets.Visible = true;
            lblAssetCount.Text = "Assets Count : " + dt.Rows.Count.ToString();
        }
        else
        {
            gvAssets.DataSource = null;
            gvAssets.Visible = false;
            lblAssetCount.Text = "Assets Count : 0";
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Please Note : Assets not found in the selected criterian.');", true);
            return;
        }
    }

    /// <summary>
    /// populate gate pass details into gridview.
    /// </summary>
    private void GetGatePassDetails(string _GatePassCode)
    {
        txtGatePassNo.Text = _GatePassCode.ToString().Trim();
        DataSet ds = oDAL.GetGatePassDetails(_GatePassCode);
        DataTable dtGPG = ds.Tables[0];
        DataTable dtGPA = ds.Tables[1];

        if (dtGPG.Rows.Count > 0)
        {
            clsGeneral.gStrApproveStatus = bool.Parse(dtGPG.Rows[0]["APPROVE_GATEPASS"].ToString());
            txtGatePassNo.Text = dtGPG.Rows[0]["GATEPASS_CODE"].ToString();
            ddlGatePassType.SelectedValue = dtGPG.Rows[0]["GATEPASS_TYPE"].ToString();
            txtGatePassDate.Text = Convert.ToDateTime(dtGPG.Rows[0]["GATEPASS_DATE"].ToString()).ToString("dd/MMM/yyyy");
            if (dtGPG.Rows[0]["GATEPASS_VENDOR_CODE"].ToString() != "")
            {
                ddlGatePassFor.SelectedIndex = 2;
                ddlGatePassFor_SelectedIndexChanged(this, EventArgs.Empty);
                ddlGatePassForName.SelectedValue = dtGPG.Rows[0]["GATEPASS_VENDOR_CODE"].ToString();
            }
            else if (dtGPG.Rows[0]["GATEPASS_EMPLOYEE_CODE"].ToString() != "")
            {
                ddlGatePassFor.SelectedIndex = 1;
                ddlGatePassFor_SelectedIndexChanged(this, EventArgs.Empty);
                ddlGatePassForName.SelectedValue = dtGPG.Rows[0]["GATEPASS_EMPLOYEE_CODE"].ToString();
            }
            ddlGPLocation.SelectedValue = dtGPG.Rows[0]["ASSET_LOCATION"].ToString();
            txtGPCarrier.Text = dtGPG.Rows[0]["GATEPASS_CARRIER_NAME"].ToString();
            txtGPBearerName.Text = dtGPG.Rows[0]["GATEPASS_BEARER_NAME"].ToString();
            if (ddlGatePassType.SelectedValue == "RETURNABLE")
            {
                if (Convert.ToDateTime(dtGPA.Rows[0]["EXP_RETURN_DATE"].ToString()).ToString("dd/MMM/yyyy") != "01/Jan/1900")
                    txtReturnableDate.Text = Convert.ToDateTime(dtGPA.Rows[0]["EXP_RETURN_DATE"].ToString()).ToString("dd/MMM/yyyy");
            }
            txtGPRemarks.Text = dtGPG.Rows[0]["PURPOSE"].ToString();
        }
        if (dtGPA.Rows.Count > 0)
        {
            gvAssets.DataSource = null;
            gvAssets.DataSource = dtGPA;
            gvAssets.DataBind();
            foreach (GridViewRow gvRow in gvAssets.Rows)
                ((CheckBox)gvRow.FindControl("chkSelectAsset")).Checked = true;
        }
        btnSubmit.Enabled = false;
        btnClear.Enabled = false;
        btnRefreshLocation.Enabled = false;
        btnSearch.Enabled = false;
        btnPrintGatePass.Enabled = true;
    }

    /// <summary>
    /// Catch unhandled exceptions.
    /// </summary>
    /// <param name="ex"></param>
    public void HandleExceptions(Exception ex)
    {
        clsGeneral.LogErrorToLogFile(ex, "Generate GatePass");
        if (!ex.Message.ToString().Contains("Thread was being aborted."))
        {
            clsGeneral.ErrMsg = ex.Message.ToString(); try { string[] arrErr = ex.Message.ToString().Split('\n'); Session["ErrMsg"] = arrErr[0].ToString().Trim(); }
            catch { } Response.Redirect("Error.aspx");
        }
    }

    /// <summary>
    /// Get location code/name for location selection.
    /// </summary>
    private void PopulateLocation()
    {
        lblLocCode.Text = "0";
        ddlGPLocation.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.GetLocation(Session["COMPANY"].ToString(), "", 1);
        ddlGPLocation.DataSource = dt;
        ddlGPLocation.DataValueField = "LOC_CODE";
        ddlGPLocation.DataTextField = "LOC_NAME";
        ddlGPLocation.DataBind();
        ddlGPLocation.Items.Insert(0, "-- Select Location --");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="p"></param>
    private void MailGatepassDetails(string GatePassCode)
    {
        SmtpClient smtpClient = new SmtpClient();
        MailMessage message = new MailMessage();
        MailAddress fromAddress = new MailAddress(ConfigurationManager.AppSettings["SENDER"].ToString(), "ATS");
        smtpClient.Host = ConfigurationManager.AppSettings["SMTP_HOST"].ToString();
        smtpClient.Port = int.Parse(ConfigurationManager.AppSettings["SMTP_PORT"].ToString());
        message.From = fromAddress;
        message.To.Add(Session["EMAIL"].ToString());
        message.Subject = "WIPRO : RTS - New GatePass For Approval";
        message.IsBodyHtml = false;
        StringBuilder sbMsg = new StringBuilder();

        DataTable dt = new DataTable();
        dt = oDAL.GetPrintGatepassDetails(GatePassCode, clsGeneral.gStrApproveStatus);
        DataRow dr = dt.Rows[0];

        sbMsg.AppendLine("Please Note,");
        sbMsg.AppendLine("A new gatepass has been generated for being approved.");
        sbMsg.AppendLine("");
        sbMsg.AppendLine("Gatepass Code : " + dr["GATEPASS_CODE"].ToString());
        sbMsg.AppendLine("Gatepass Date : " + dr["GATEPASS_DATE"].ToString());
        sbMsg.AppendLine("Bearer Name : " + dr["GATEPASS_BEARER_NAME"].ToString());
        sbMsg.AppendLine("Carrier Name : " + dr["GATEPASS_CARRIER_NAME"].ToString());

        if (dr["GATEPASS_EMPLOYEE_CODE"].ToString().Trim() != "")
        {
            sbMsg.AppendLine("");
            sbMsg.AppendLine("Emloyee Code : " + dr["GATEPASS_EMPLOYEE_CODE"].ToString());
            sbMsg.AppendLine("Emloyee Name : " + dr["GATE_PASS_FOR"].ToString().Split(';')[1].Trim());
        }
        else
        {
            sbMsg.AppendLine("");
            sbMsg.AppendLine("Vendor Code : " + dr["VENDOR_CODE"].ToString());
            sbMsg.AppendLine("Vendor Name : " + dr["VENDOR_NAME"].ToString());
        }
        if (dr["ASSET_LOCATION"].ToString().Trim() == "")
            sbMsg.AppendLine("");
        else
            sbMsg.AppendLine("Asset Location : " + dr["ASSET_LOCATION"].ToString());
        sbMsg.AppendLine("");
        sbMsg.AppendLine("ASSET CODE          SERIAL No.          ASSET MAKE          MODEL TYPE          RETURNABLE DATE");
        for (int iCnt = 0; iCnt < dt.Rows.Count; iCnt++)
        {
            sbMsg.AppendLine(dt.Rows[iCnt]["ASSET_CODE"].ToString() + "  " + dt.Rows[iCnt]["SERIAL_CODE"].ToString() + "  " + dt.Rows[iCnt]["ASSET_MAKE"].ToString() + "  " + dt.Rows[iCnt]["MODEL_NAME"].ToString() + "  " + dt.Rows[iCnt]["EXP_RETURN_DATE"].ToString());
        }
        sbMsg.AppendLine("Total Assets : " + dr["TOTAL"].ToString());
        sbMsg.AppendLine("");
        sbMsg.AppendLine("");
        sbMsg.AppendLine("http://10.164.91.191/FIS_ATS/WEBPAGES/UserLogin.aspx");
        message.Body = sbMsg.ToString();
        smtpClient.Send(message);
    }

    /// <summary>
    /// Fetch category details to be populated in dropdownlist.
    /// </summary>
    private void PopulateCategory(string AssetType)
    {
        lblCatCode.Text = "0";
        lblCatLevel.Text = "1";
        ddlAssetCategory.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.PopulateCategory(AssetType.Trim(), "", 1);
        ddlAssetCategory.DataSource = dt;
        ddlAssetCategory.DataTextField = "CATEGORY_NAME";
        ddlAssetCategory.DataValueField = "CATEGORY_CODE";
        ddlAssetCategory.DataBind();
        ddlAssetCategory.Items.Insert(0, "-- Select Category --");
    }

    /// <summary>
    /// 
    /// </summary>
    private void PopulateAssetMake(string CategoryCode)
    {
        ddlAssetMake.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.PopulateAssetMake(CategoryCode, Session["COMPANY"].ToString());
        ddlAssetMake.DataSource = dt;
        ddlAssetMake.DataTextField = "ASSET_MAKE";
        ddlAssetMake.DataValueField = "ASSET_MAKE";
        ddlAssetMake.DataBind();
        ddlAssetMake.Items.Insert(0, "-- Select Make --");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="AssetMake"></param>
    private void PopulateModelName(string AssetMake, string CategoryCode)
    {
        lstModelName.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.PopulateModelName(AssetMake, CategoryCode, Session["COMPANY"].ToString());
        lstModelName.DataSource = dt;
        lstModelName.DataTextField = "MODEL_NAME";
        lstModelName.DataValueField = "MODEL_NAME";
        lstModelName.DataBind();
        lstModelName.Items.Insert(0, "-- Select Model --");
    }
    #endregion

    #region BUTTON EVENTS
    /// <summary>
    /// Refresh/reset category to top level.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnRefreshCategory_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            PopulateCategory(lblAssetType.Text);
            DataTable dtNull = new DataTable();
            ddlAssetMake.DataSource = dtNull;
            ddlAssetMake.DataBind();
            lstModelName.DataSource = dtNull;
            lstModelName.DataBind();
            dtNull = null;
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Save Gate Pass generation details.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            bool bAssetSelected = false;
            //oDAL.Transaction("BEGIN");
            string _LiveGPCode = "";
            if (clsGeneral._strRights[1] == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            if (lblLocCode.Text == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Please Note : Location cannot be blank.');", true);
                return;
            }
            if (ddlGatePassForName.SelectedIndex == 0)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Please Note : Gatepass for name cannot be blank.');", true);
                ddlGatePassForName.Focus();
                return;
            }
            for (int iCnt = 0; iCnt < gvAssets.Rows.Count; iCnt++)
            {
                if (((CheckBox)gvAssets.Rows[iCnt].FindControl("chkSelectAsset")).Checked == true)
                {
                    bAssetSelected = true;
                    break;
                }
            }
            if (!bAssetSelected)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Please Note : Click on search assets button to select assets.');", true);
                return;
            }
            oPRP.CompCode = Session["COMPANY"].ToString();
            oPRP.CreatedBy = Session["CURRENTUSER"].ToString();
            oPRP.BearerName = txtGPBearerName.Text.Trim();
            oPRP.CarrierName = txtGPCarrier.Text.Trim();
            oPRP.GatePassDate = Convert.ToDateTime(txtGatePassDate.Text.Trim());
            oPRP.GatePassType = ddlGatePassType.SelectedValue.ToString();

            oPRP.AssetLocation = lblLocCode.Text.Trim();
            oPRP.Remarks = txtGPRemarks.Text.Trim();
            if (ddlGatePassFor.SelectedValue.ToString() == "EMPLOYEE")
                oPRP.EmpCode = ddlGatePassForName.SelectedValue.ToString();
            else if (ddlGatePassFor.SelectedValue.ToString() == "VENDOR")
                oPRP.VendorCode = ddlGatePassForName.SelectedValue.ToString();
            oPRP.Approve_GatePass = false;

            int _iMaxACQId = oDAL.GetMaxRunningSrlNo(Session["COMPANY"].ToString());
            oPRP.GatePassCode = oPRP.CompCode + "-" + "GP" + "-" + _iMaxACQId.ToString().PadLeft(6, '0');
            bool bResp = oDAL.SaveGatePassDetails(oPRP);
            bool bRsp = false;
            foreach (GridViewRow gvRow in gvAssets.Rows)
            {
                if (((CheckBox)gvRow.FindControl("chkSelectAsset")).Checked)
                {
                    oPRP.AssetCode = ((Label)gvRow.FindControl("lblAssetCode")).Text.Trim();
                    _LiveGPCode = oDAL.ChkLiveGP(oPRP.AssetCode);
                    if (_LiveGPCode != "")
                    {
                        lblErrorMsg.Text = "Selected asset is already part of Gate Pass No: " + _LiveGPCode + " and is not returned yet.";
                        return;
                    }
                    if (txtReturnableDate.Text.Trim() != "")
                    {
                        oPRP.ExpReturnDate = Convert.ToDateTime(txtReturnableDate.Text.Trim());
                        if (oPRP.ExpReturnDate < Convert.ToDateTime(DateTime.Now.ToString("dd/MMM/yyyy")))
                        {
                            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Please Note : Expected return Date should be greater than current date.');", true);
                            return;
                        }
                    }
                    else
                        oPRP.ExpReturnDate = Convert.ToDateTime("01/Jan/1900");
                    bRsp = oDAL.SaveGatePassAssets(oPRP);
                }
            }
            if (!bRsp)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Please Note : Gate Pass details not saved successfully.);", true);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ClearFields", "ClearFields();", true);
                lblErrorMsg.Text = "Please Note : New GatePass Generated For Approval With GatePass No. As : " + oPRP.GatePassCode;
                txtGatePassNo.Text = oPRP.GatePassCode;
                btnPrintGatePass.Enabled = true;
                upSubmit.Update();
                try
                { MailGatepassDetails(oPRP.GatePassCode); }
                catch (Exception ex) { }
            }
            bTransOpen = true;
            if (bTransOpen)
            {
                //oDAL.Transaction("COMMIT");
                bTransOpen = false;
            }
            PopulateAssetDetails();
        }
        catch (Exception ex)
        {
            //oDAL.Transaction("ROLLBACK");
            bTransOpen = false;
            HandleExceptions(ex);
        }
    }

    /// <summary>
    /// Get Assets based on asset code, serial code, asset make, model name and location code criterian.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            PopulateAssetDetails();
        }
        catch (Exception ex)
        {
            HandleExceptions(ex);
        }
    }

    /// <summary>
    /// Reset/clear page fields.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnClear_Click(object sender, EventArgs e)
    {
        try
        {
            gvAssets.DataSource = null;
            gvAssets.DataBind();

            PopulateCategory(lblAssetType.Text);
            DataTable dtNull = new DataTable();
            ddlAssetMake.DataSource = dtNull;
            ddlAssetMake.DataBind();
            lstModelName.DataSource = dtNull;
            lstModelName.DataBind();
            dtNull = null;

            lblLocCode.Text = "0";
            lblAssetCount.Text = "Assets Count : 0";
            ddlGPLocation.DataSource = null;
            DataTable dt = oDAL.GetLocation(Session["COMPANY"].ToString(), "", 1);
            ddlGPLocation.DataSource = dt;
            ddlGPLocation.DataTextField = "LOC_NAME";
            ddlGPLocation.DataValueField = "LOC_CODE";
            ddlGPLocation.DataBind();
            ddlGPLocation.Items.Insert(0, "-- Select Location --");
            ddlGatePassForName.DataSource = null;
            btnPrintGatePass.Enabled = false;
            if (bTransOpen)
            {
                oDAL.Transaction("ROLLBACK", Session["DATABASE"].ToString());
                bTransOpen = false;
            }
        }
        catch (Exception ex)
        {
            HandleExceptions(ex);
        }
    }

    /// <summary>
    /// Refresh/reset location details.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnRefreshLocation_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            lblLocLevel.Text = "1";
            PopulateLocation();
        }
        catch (Exception ex)
        {
            HandleExceptions(ex);
        }
    }

    /// <summary>
    /// Navigate to print gate pass page.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnPrintGatePass_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtGatePassNo.Text != "")
            {
                string URL = "PrintGatePass.aspx?GPNO=" + txtGatePassNo.Text.Trim() + "&APPROVE_STATUS=" + clsGeneral.gStrApproveStatus.ToString();
                string fullURL = "window.open('" + URL + "', '_blank', 'height=800,width=832,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no,titlebar=no');";
                ScriptManager.RegisterStartupScript(this, typeof(string), "OPEN_WINDOW", fullURL, true);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Please Note : Gate Pass Code cannot be blank.);", true);
                return;
            }
        }
        catch (Exception ex)
        {
            HandleExceptions(ex);
        }
    }
    #endregion

    #region SELECTEDINDEXCHANGED EVENTS
    /// <summary>
    /// Fetch list of categories based on asset type selected.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlAssetType_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlAssetType.SelectedIndex != 0)
            {
                DataTable dtNull = new DataTable();
                ddlAssetCategory.DataSource = dtNull;
                ddlAssetCategory.DataBind();
                ddlAssetMake.DataSource = dtNull;
                ddlAssetMake.DataBind();
                lstModelName.DataSource = dtNull;
                lstModelName.DataBind();
                dtNull = null;

                lblAssetType.Text = ddlAssetType.SelectedValue.ToString();
                PopulateCategory(lblAssetType.Text);
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlAssetMake_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlAssetMake.SelectedIndex != 0)
                PopulateModelName(ddlAssetMake.SelectedValue.ToString(), lblCatCode.Text.Trim());
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlAssetCategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlAssetCategory.SelectedIndex > 0)
            {
                DataTable dtNull = new DataTable();
                lstModelName.DataSource = dtNull;
                lstModelName.DataBind();
                dtNull = null;

                PopulateAssetMake(ddlAssetCategory.SelectedValue.ToString());
                int CatLevel = int.Parse(lblCatLevel.Text.Trim());
                lblCatLevel.Text = (CatLevel + 1).ToString();
                int iCatLevel = int.Parse(lblCatLevel.Text.Trim());
                string sCatCode = ddlAssetCategory.SelectedValue.ToString();
                lblCatCode.Text = sCatCode;

                ddlAssetCategory.DataSource = null;
                DataTable dt = oDAL.PopulateCategory(lblAssetType.Text, sCatCode, iCatLevel);
                if (dt.Rows.Count > 0)
                {
                    ddlAssetCategory.DataSource = dt;
                    ddlAssetCategory.DataValueField = "CATEGORY_CODE";
                    ddlAssetCategory.DataTextField = "CATEGORY_NAME";
                    ddlAssetCategory.DataBind();
                    ddlAssetCategory.Items.Insert(0, "-- Select Category --");
                    ddlAssetCategory.Focus();
                }
                else
                {
                    iCatLevel = iCatLevel - 1;
                    lblCatLevel.Text = iCatLevel.ToString();
                    ddlAssetMake.Focus();
                }
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Get location code/name based on parent location name selection.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlGPLocation_SelectedIndexChanged(object sender,EventArgs e)
    {
        try
        {
            if (ddlGPLocation.SelectedIndex != 0)
            {
                int locLevel = int.Parse(lblLocLevel.Text.Trim());
                lblLocLevel.Text = (locLevel + 1).ToString();
                int iLocLevel = int.Parse(lblLocLevel.Text.Trim());
                string sLocCode = ddlGPLocation.SelectedValue.ToString();
                lblLocCode.Text = sLocCode;

                ddlGPLocation.DataSource = null;
                DataTable dt = oDAL.GetLocation(Session["COMPANY"].ToString(), sLocCode, iLocLevel);
                if (dt.Rows.Count > 0)
                {
                    ddlGPLocation.DataSource = dt;
                    ddlGPLocation.DataValueField = "LOC_CODE";
                    ddlGPLocation.DataTextField = "LOC_NAME";
                    ddlGPLocation.DataBind();
                    ddlGPLocation.Items.Insert(0, "-- Select Location --");
                    ddlGPLocation.Focus();
                }
                else
                {
                    iLocLevel = iLocLevel - 1;
                    lblLocLevel.Text = iLocLevel.ToString();
                    ddlGatePassFor.Focus();
                }
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Get employee/vendor code/name based on gate pass for selection.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlGatePassFor_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlGatePassFor.SelectedIndex != 0)
            {
                if (ddlGatePassFor.SelectedValue.ToString() == "EMPLOYEE")
                {
                    ddlGatePassForName.DataSource = null;
                    DataTable dt = new DataTable();
                    dt = oDAL.GetEmployee(Session["COMPANY"].ToString());
                    ddlGatePassForName.DataSource = dt;
                    ddlGatePassForName.DataTextField = "EMPLOYEE_NAME";
                    ddlGatePassForName.DataValueField = "EMPLOYEE_CODE";
                    ddlGatePassForName.DataBind();
                    ddlGatePassForName.Items.Insert(0, "-- Select Employee --");
                }
                else if (ddlGatePassFor.SelectedValue.ToString() == "VENDOR")
                {
                    ddlGatePassForName.DataSource = null;
                    DataTable dt = new DataTable();
                    dt = oDAL.GetVendor(Session["COMPANY"].ToString());
                    ddlGatePassForName.DataSource = dt;
                    ddlGatePassForName.DataTextField = "VENDOR_NAME";
                    ddlGatePassForName.DataValueField = "VENDOR_CODE";
                    ddlGatePassForName.DataBind();
                    ddlGatePassForName.Items.Insert(0, "-- Select Vendor --");
                }
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    #endregion

    #region GRIDVIEW EVENTS
    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvAssets_RowCreated(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow &&
               (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate))
            {
                CheckBox chkSelect = (CheckBox)e.Row.Cells[0].FindControl("chkSelectAsset");
                CheckBox chkHSelect = (CheckBox)this.gvAssets.HeaderRow.FindControl("chkHSelect");
                chkSelect.Attributes["onclick"] = string.Format("javascript:ChildClick(this,'{0}');", chkHSelect.ClientID);
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Asset details gridview page index changing event.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvAssets_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvAssets.PageIndex = e.NewPageIndex;
            PopulateAssetDetails();
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    #endregion
}