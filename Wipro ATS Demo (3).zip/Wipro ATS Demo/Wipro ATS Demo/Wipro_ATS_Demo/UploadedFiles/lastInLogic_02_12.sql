
DECLARE @Tbl Table  (ReadDate Date , NoOfRead int )

insert into @tbl (ReadDate , NoOfRead ) (SELECT GetDATE(),0)
insert into @tbl (ReadDate , NoOfRead ) (SELECT GetDATE()+5 ,1)
insert into @tbl (ReadDate , NoOfRead ) (SELECT GetDATE()+6, 2)
insert into @tbl (ReadDate , NoOfRead ) (SELECT GetDATE()+7,3)
insert into @tbl (ReadDate , NoOfRead ) (SELECT GetDATE()+8,4)
insert into @tbl (ReadDate , NoOfRead ) (SELECT GetDATE()+9,5)

insert into @tbl (ReadDate , NoOfRead ) (SELECT GetDATE()+10,6)
insert into @tbl (ReadDate , NoOfRead ) (SELECT GetDATE()+11,7)
insert into @tbl (ReadDate , NoOfRead ) (SELECT GetDATE()+12,8)
insert into @tbl (ReadDate , NoOfRead ) (SELECT GetDATE()+13,9)
insert into @tbl (ReadDate , NoOfRead ) (SELECT GetDATE()+14,10)
insert into @tbl (ReadDate , NoOfRead ) (SELECT GetDATE()+15,11);

SELECT MAX(ReadDate) as [LastRead] ,MAX(NoOfRead)%2  from @tbl  ;

SELECT 1%2

--With  X  AS 
--(
--SELECT ROW_NUMBER() over(Order by (SELECT 1)) AS [SNO] , * from @Tbl 
--)
--SELECT 
--T2.SNO [T2_SNO], T2.ReadDate AS [T2_ReadDate] ,  T1.SNO [T1_SNO], T1.ReadDate AS [T1_ReadDate] ,
--CASE When  DATEDIFF (DAY, T2.ReadDate , T1.ReadDate)>1 then 1 else 0  END as [IsSend] ,
--DATEDIFF (DAY, T2.ReadDate , T1.ReadDate) as [NoOFDAYS]
--    from X T1  Inner join X T2 on T1.SNO = T2.SNO+1
	
--	 ;
 

