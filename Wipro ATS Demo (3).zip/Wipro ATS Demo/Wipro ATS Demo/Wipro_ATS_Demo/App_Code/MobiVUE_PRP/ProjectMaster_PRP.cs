﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace MobiVUE_ATS.PRP
{
    /// <summary>
    /// Summary description for Process Master Properties
    /// </summary>
    public class ProjectMaster_PRP
    {
        #region PROJECT MASTER PROPERTIES
        public string CompCode { get; set; }
        public string DeptCode
        {
            get;
            set;
        }
        public string ProjectCode
        { get; set; }
        public string ProjectName
        { get; set; }
        public string ProjectOwner
        { get; set; }
        public string ProejctManagerName
        { get; set; }
        public string ProejctManagerEmailId
        { get; set; }
        public string CreatedBy
        { get; set; }
        public string LocCode
        { get; set; }
        public string Remarks
        { get; set; }
        public string ModifiedBy
        { get; set; }
        public bool Active
        { get; set; }

        #endregion
    }
}