﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Class1
/// </summary>
/// 
[Serializable]
public class UploadDocument
{
    public int DocumentDetailId { get; set; }
    public string FileName { get; set; }
    public string UploadFilePath { get; set; }
    public string UploadDBFilePath { get; set; }
    public string IsValid { get; set; }
    public UploadDocType DocumentType { get; set; }
    public string Remark { get; set; }
}

[Serializable]
public class AssetDetails
{
    public int AssetDetailId { get; set; }
    public string AssetCode { get; set; }
    public int Quantity { get; set; }
    public string FamsID { get; set; }
    public string CategoryCode { get; set; }
    public string AssetMake { get; set; }
    public string[] AssetModel { get; set; }
    public bool IsUploaded { get; set; }
    public string AssetDBFileName { get; set; }
    public AssetDetails()
    {
        this.AssetModel = new String[1];
    }
}
[Serializable]
public enum AssetRequestStage
{
    None = 0,
    Raised = 1,
    PMApproved = 2,
    CMFApproved = 3,
    ClearanceApproved = 4,
    GatePassed = 5,
    Received = 6,
    ClearanceReceived = 7,
    PMReject = 8,
    CMFReject = 9,
    ClearanceReject = 10,
    ClearanceRecReject = 11

}
[Serializable]
public enum UploadDocType
{
    None = 0,
    REQ = 1,
    PM = 2,
    CMF = 3,
    CLRREQ = 4,
    REC = 5,
    CLRREC = 6
}
[Serializable]
public class AssetRequest
{
    public AssetRequest()
    {
        this.AssetDetails = new List<AssetDetails>();
        this.Documents = new List<UploadDocument>();
        this.RequestId = string.Empty;
        this.LocationCode = string.Empty;
        this.IsPermanent = default(bool);
        this.TransferTo = string.Empty;
        this.IsInterUnit = default(bool);
        this.LocationTo = string.Empty;
        this.ProjectCode = string.Empty;
        this.ReceiverEmail = string.Empty;
        this.GstNo = string.Empty;
        this.ProjectCostCentre = string.Empty;
        this.PMApprove = default(bool);
        this.PMRemark = string.Empty;
        this.CMFApprove = default(bool);
        this.CMFRemark = string.Empty;
        this.IsClerance = default(bool);
        this.IsReceived = default(bool);
        this.IsReceivedClearance = default(bool);
        this.Stage = AssetRequestStage.None;
        this.CreatedOn = default(DateTime?);
        this.CreatedBY = string.Empty;
        this.PMApprovedOn = default(DateTime?);
        this.PMApprovedBy = string.Empty;

        this.CMFApprovedOn = default(DateTime?);
        this.CMFApprovedBy = string.Empty;

        this.ClearanceOn = default(DateTime?);
        this.ClearanceBy = string.Empty;
        this.ReceivedBy = string.Empty;
        this.ReceivedOn = default(DateTime?);
        this.ReceivedClearanceOn = default(DateTime?);
        this.ReceivedClearanceBy = string.Empty;

        this.RequestedLocName = string.Empty;
        this.RequestedToLocName = string.Empty;

    }

    public string RequestId { get; set; }
    public List<AssetDetails> AssetDetails { get; set; }
    public List<UploadDocument> Documents { get; set; }

    public string LocationCode { get; set; }
    public bool IsPermanent { get; set; }
    public string TransferTo { get; set; }
    public bool IsInterUnit { get; set; }
    public string LocationTo { get; set; }
    public string ProjectCode { get; set; }
    public string ReceiverEmail { get; set; }
    public string GstNo { get; set; }
    public string ProjectCostCentre { get; set; }
    public bool PMApprove { get; set; }
    public string PMRemark { get; set; }
    public bool CMFApprove { get; set; }
    public string CMFRemark { get; set; }
    public bool IsClerance { get; set; }
    public bool IsReceived { get; set; }
    public bool IsReceivedClearance { get; set; }

    public AssetRequestStage Stage { get; set; }

    public DateTime? CreatedOn { get; set; }
    public string CreatedBY { get; set; }
    public DateTime? PMApprovedOn { get; set; }
    public string PMApprovedBy { get; set; }

    public DateTime? CMFApprovedOn { get; set; }
    public string CMFApprovedBy { get; set; }

    public DateTime? ClearanceOn { get; set; }
    public string ClearanceBy { get; set; }

    public DateTime? ReceivedOn { get; set; }
    public string ReceivedBy { get; set; }

    public DateTime? ReceivedClearanceOn { get; set; }
    public string ReceivedClearanceBy { get; set; }

    public int AssetDetailId { get; set; }
    public string AssetCode { get; set; }
    public int Quantity { get; set; }
    public string FamsID { get; set; }
    public string CategoryCode { get; set; }
    public string AssetMake { get; set; }
    public string[] AssetModel { get; set; }
    public bool IsUploaded { get; set; }
    public string AssetDBFileName { get; set; }

    // only for view location code.

    public string RequestedLocName { get; set; }
    public string RequestedToLocName { get; set; }

}

public class AssetSearchCriteria
{
    public string RequestId { get; set; }
    public string LocationCode { get; set; }
    public AssetRequestStage RequestStage { get; set; }
    public UploadDocType DocumentType { get; set; }

    // new property Added 29 NOV 2018 for view request
    public DateTime? RequestFrom { get; set; }
    public DateTime? RequestTo { get; set; }
    public string AssetCode { get; set; }

    public AssetSearchCriteria()
    {
        this.RequestId = string.Empty;
        this.LocationCode = string.Empty;
        this.RequestStage = AssetRequestStage.None;
        this.RequestFrom = default(DateTime?);
        this.RequestTo = default(DateTime?);
        this.DocumentType = UploadDocType.None;
    }

}
public class AssetViewSearchCriteria
{
    public string RequestId { get; set; }
    public string LocationCode { get; set; }
    public AssetRequestStage RequestStage { get; set; }
    public DateTime RequestFrom { get; set; }
    public DateTime RequestTo { get; set; }
    public string AssetCode { get; set; }
    public UploadDocType DocumentType { get; set; }
    public AssetViewSearchCriteria()
    {
        this.RequestId = string.Empty;
        this.LocationCode = string.Empty;
        this.RequestStage = AssetRequestStage.None;
        this.RequestFrom = default(DateTime);
        this.RequestTo = default(DateTime);
        this.DocumentType = UploadDocType.None;
    }
}



public class AssetRequestDTO
{
    public AssetRequestDTO()
    {
        //this.AssetDetails = new List<AssetDetails>();
        this.Documents = new List<UploadDocument>();
        this.RequestId = string.Empty;
        this.LocationCode = string.Empty;
        this.IsPermanent = string.Empty;
        this.TransferTo = string.Empty;
        this.IsInterUnit = string.Empty;
        this.LocationTo = string.Empty;
        this.ProjectCode = string.Empty;
        this.ReceiverEmail = string.Empty;
        this.GstNo = string.Empty;
        this.ProjectCostCentre = string.Empty;
        this.PMApprove = string.Empty;
        this.PMRemark = string.Empty;
        this.CMFApprove = string.Empty;
        this.CMFRemark = string.Empty;
        this.IsClerance = string.Empty;
        this.IsReceivedClearance = string.Empty;
        this.Stage = AssetRequestStage.None;
        this.CreatedOn = string.Empty;
        this.CreatedBY = string.Empty;
        this.PMApprovedOn = string.Empty;
        this.PMApprovedBy = string.Empty;

        this.CMFApprovedOn = string.Empty;
        this.CMFApprovedBy = string.Empty;

        this.ClearanceOn = string.Empty;
        this.ClearanceBy = string.Empty;
        this.ReceivedBy = string.Empty;
        this.ReceivedOn = string.Empty;
        this.ReceivedClearanceOn = string.Empty;
        this.ReceivedClearanceBy = string.Empty;
        this.AssetModel = new String[1];

    }

    public string RequestId { get; set; }

    // public List<AssetDetails> AssetDetails { get; set; }
    public List<UploadDocument> Documents { get; set; }


    public string LocationCode { get; set; }
    public string IsPermanent { get; set; }
    public string TransferTo { get; set; }
    public string IsInterUnit { get; set; }
    public string LocationTo { get; set; }
    public string ProjectCode { get; set; }
    public string ReceiverEmail { get; set; }
    public string GstNo { get; set; }
    public string ProjectCostCentre { get; set; }
    public string PMApprove { get; set; }
    public string PMRemark { get; set; }
    public string CMFApprove { get; set; }
    public string CMFRemark { get; set; }
    public string IsClerance { get; set; }
    public string IsReceivedClearance { get; set; }

    public AssetRequestStage Stage { get; set; }

    public string CreatedOn { get; set; }
    public string CreatedBY { get; set; }
    public string PMApprovedOn { get; set; }
    public string PMApprovedBy { get; set; }

    public string CMFApprovedOn { get; set; }
    public string CMFApprovedBy { get; set; }

    public string ClearanceOn { get; set; }
    public string ClearanceBy { get; set; }

    public string ReceivedOn { get; set; }
    public string ReceivedBy { get; set; }

    public string ReceivedClearanceOn { get; set; }
    public string ReceivedClearanceBy { get; set; }


    // Asset Details.

    public int AssetDetailId { get; set; }
    public string AssetCode { get; set; }
    public int Quantity { get; set; }
    public string FamsID { get; set; }
    public string CategoryCode { get; set; }
    public string AssetMake { get; set; }
    public string[] AssetModel { get; set; }
    public bool IsUploaded { get; set; }
    public string AssetDBFileName { get; set; }

    // location Name 

    public string RequestedLocationName { get; set; }
    public string RequestToLocationName { get; set; }
}

public class ViewAssetLocation
{
    public string AssetCode { get; set; }
    public string Location { get; set; }
    public string RequestId { get; set; }
    public AssetRequestStage Stage { get; set; }
    public ViewAssetLocation()
    {
        this.AssetCode = string.Empty;
        this.Location = string.Empty;
        this.RequestId = string.Empty;
        this.Stage = AssetRequestStage.None;
    }

}


