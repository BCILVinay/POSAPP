﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

/// <summary>
/// Summary description for EmployeeMaster_PRP
/// </summary>
public class EmployeeMaster_PRP
{
    #region EMPLOYEE MASTER PROPERTIES

    public string CompCode
    { get; set; }
    public string EmpCode
    { get; set; }
    public string EmpName
    { get; set; }
    public string EmpLocCode
    { get; set; }
    public string EmpProjCode
    { get; set; }
    public string EmpReprotTo
    { get; set; }
    public string EmpEmail
    { get; set; }
    public string EmpDOJ
    { get; set; }
    public string EmpDOL
    { get; set; }
    public string EmpPhone
    { get; set; }
    public string LocCode
    { get; set; }
    public bool Active
    { get; set; }
    public string EmpRemarks
    { get; set; }
    public string CreatedBy
    { get; set; }
    public string ModifiedBy
    { get; set; }
    #endregion
}