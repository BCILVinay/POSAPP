﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Text;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MobiVUE_ATS.PRP;

namespace MobiVUE_ATS.DAL
{
    /// <summary>
    /// Summary description for Asset Allocation Data Access Layer
    /// </summary>
    public class AssetAllocation_DAL
    {
        clsDb oDb;
        StringBuilder sbQuery;
        public AssetAllocation_DAL(string DatabaseType)
        {
            oDb = new clsDb();
            if (DatabaseType != "")
                oDb.Connect(DatabaseType);
        }
        ~AssetAllocation_DAL()
        {
            oDb.Disconnect();
            oDb = null;
            sbQuery = null;
        }

        /// <summary>
        /// Fetch Locations details for mapping with user id
        /// </summary>
        /// <param name="_ParentLocCode"></param>
        /// <param name="_LocLevel"></param>
        /// <returns>DataTable</returns>
        public DataTable GetLocation(string _CompCode, string STORAGE_LOC_CODE, string _ParentLocCode, int _LocLevel)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("SELECT LOC_CODE, LOC_NAME FROM LOCATION_MASTER");
            sbQuery.Append(" WHERE PARENT_LOC_CODE LIKE '" + _ParentLocCode + "%' AND LOC_LEVEL=" + _LocLevel + "");
            sbQuery.Append(" AND COMP_CODE='" + _CompCode + "'AND STORAGE_LOC_CODE ='" + STORAGE_LOC_CODE + "'  AND ACTIVE=1");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Fetch all department name within a location.
        /// </summary>
        /// <param name="CompCode"></param>
        /// <returns></returns>
        public DataTable GetDepartment(string CompCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("SELECT DEPT_CODE,DEPT_NAME FROM DEPARTMENT_MASTER WHERE ACTIVE='1' AND COMP_CODE='" + CompCode + "' ORDER BY DEPT_NAME");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Fetch all department code/name from department master.
        /// </summary>
        /// <returns></returns>
        public DataTable GetProject(string DeptCode, string CompCode)
        {
            sbQuery = new StringBuilder();
         //   sbQuery.Append("SELECT PROCESS_CODE,PROCESS_NAME FROM PROCESS_MASTER WHERE ACTIVE='1' AND DEPT_CODE='" + DeptCode + "' AND COMP_CODE='" + CompCode + "' ORDER BY PROCESS_NAME");
            sbQuery.Append("SELECT PROJECT_CODE  , PROJECT_NAME FROM Project_Master WHERE ACTIVE='1' AND DEPT_CODE='" + DeptCode + "' AND COMP_CODE='" + CompCode + "' ORDER BY PROJECT_NAME");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Fetch category code/name details to be populated into dropdownlist.
        /// </summary>
        /// <returns></returns>
        public DataTable PopulateCategory(string _AssetType, string _ParentCategory, int _CatLevel)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("SELECT CATEGORY_CODE,CATEGORY_NAME FROM CATEGORY_MASTER");
            sbQuery.Append(" WHERE ASSET_TYPE='" + _AssetType + "' AND PARENT_CATEGORY='" + _ParentCategory + "'");
            sbQuery.Append(" AND CATEGORY_LEVEL=" + _CatLevel + " AND ACTIVE=1");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Get asset make list when asset category is provided.
        /// </summary>
        /// <param name="CompCode"></param>
        /// <returns></returns>
        public DataTable PopulateAssetMake(string CategoryCode, string CompCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("SELECT DISTINCT [ASSET_MAKE] FROM [ASSET_ACQUISITION] WHERE [CATEGORY_CODE] = '" + CategoryCode + "' AND [COMP_CODE] = '" + CompCode + "'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Get asset model name list when asset make and category is provided.
        /// </summary>
        /// <param name="CompCode"></param>
        /// <returns></returns>
        public DataTable PopulateModelName(string AssetMake, string CategoryCode, string CompCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("SELECT DISTINCT [MODEL_NAME] FROM [ASSET_ACQUISITION] WHERE [ASSET_MAKE]='" + AssetMake + "'");
            sbQuery.Append(" AND [CATEGORY_CODE]='" + CategoryCode + "' AND [COMP_CODE]='" + CompCode + "'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Fetch all employee code/name from employee master based on 
        /// department selected.
        /// </summary>
        /// <param name="_DeptCode"></param>
        /// <returns></returns>
        public DataTable GetDeptEmployee(string _DeptCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("SELECT EMPLOYEE_CODE,EMPLOYEE_NAME FROM EMPLOYEE_MASTER");
            sbQuery.Append(" WHERE EMP_DEPT_CODE='" + _DeptCode + "' AND ACTIVE=1");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Get employee code/name within a process.
        /// </summary>
        /// <param name="_DeptCode"></param>
        /// <returns></returns>
        public DataTable GetProcessEmployee(string ProcessCode,string CompCode)
        {
            sbQuery = new StringBuilder(); //EMP_PROCESS_CODE
            sbQuery.Append("SELECT EMPLOYEE_CODE,EMPLOYEE_NAME FROM EMPLOYEE_MASTER");
            sbQuery.Append(" WHERE EMP_PROJECT_CODE ='" + ProcessCode + "' AND COMP_CODE='" + CompCode + "' AND ACTIVE=1");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Get employee code/name from employee master.
        /// </summary>
        /// <param name="CompCode"></param>
        /// <returns></returns>
        public DataTable GetEmployee(string CompCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("SELECT EMPLOYEE_CODE,EMPLOYEE_NAME FROM EMPLOYEE_MASTER");
            sbQuery.Append(" WHERE COMP_CODE='" + CompCode + "' AND ACTIVE='1'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable GetAssetCode()
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("SELECT ASSET_CODE FROM ASSET_ACQUISITION");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Get asset serial no when asset code is provided.
        /// </summary>
        /// <param name="_AssetCode"></param>
        /// <returns></returns>
        public DataTable GetSerialCode(string _AssetCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("SELECT SERIAL_CODE FROM ASSET_ACQUISITION WHERE ASSET_CODE = '" + _AssetCode.Trim() + "'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Get assets from asset acquisition table for assets to be allocated.
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        public DataTable GetAssets(AssetAllocation_PRP oPRP)
        {
            sbQuery = new StringBuilder();  // replaced ASSET_PROCESS to Project_Name 
            sbQuery.Append("SELECT ASSET_CODE,ASSET_ID,SERIAL_CODE,ASSET_MAKE,MODEL_NAME,ASSET_PROCESS,ASSET_LOCATION,PORT_NO FROM ASSET_ACQUISITION");
            sbQuery.Append(" WHERE ASSET_TYPE LIKE '" + oPRP.AssetType + "%' AND ASSET_CODE LIKE '" + oPRP.AssetCode + "%' AND SERIAL_CODE LIKE '" + oPRP.SerialCode + "%'");
            sbQuery.Append(" AND ASSET_MAKE LIKE '" + oPRP.AssetMake + "%' AND Project_Name LIKE '" + oPRP.FromProcessCode + "%' AND CATEGORY_CODE LIKE '" + oPRP.CategoryCode + "%'");
            if (oPRP.ModelName != "")
                sbQuery.Append(" AND MODEL_NAME IN (" + oPRP.ModelName + ")");
            else
                sbQuery.Append(" AND MODEL_NAME LIKE '" + oPRP.ModelName + "%'");
            sbQuery.Append(" AND ASSET_ALLOCATED = '" + oPRP.AssetAllocated + "' AND COMP_CODE='" + oPRP.CompCode + "' AND ASSET_APPROVED = 'True' AND SOLD_SCRAPPED_STATUS IS NULL");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Get asset details which are to be returned.
        /// </summary>
        /// <param name="_AssetCode"></param>
        /// <returns></returns>
        public DataTable GetAssetToReturnReAllocate(AssetAllocation_PRP oPRP)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("SELECT ACQ.ASSET_CODE,ACQ.ASSET_ID,ACQ.SERIAL_CODE,ACQ.ASSET_MAKE,ACQ.MODEL_NAME,ACQ.ASSET_PROCESS,ACQ.ASSET_LOCATION,AAL.WORKSTATION_NO,");
            sbQuery.Append(" AAL.ASSET_ALLOCATION_DATE,AAL.REQUESTED_BY_ID,");
            sbQuery.Append(" AAL.APPROVED_BY_ID,AAL.ASSET_ALLOCATED_EMP,AAL.ALLOCATED_EMP_ID,NULLIF(AAL.EXPECTED_RTN_DATE,'') AS EXPECTED_RTN_DATE,AAL.PORT_NO,AAL.VLAN,");
            sbQuery.Append(" AAL.TICKET_NO,AAL.GATEPASS_NO");
            sbQuery.Append(" FROM ASSET_ACQUISITION ACQ INNER JOIN ASSET_ALLOCATION AAL ON ACQ.ASSET_CODE = AAL.ASSET_CODE");
            sbQuery.Append(" WHERE ACQ.ASSET_TYPE LIKE '" + oPRP.AssetType + "%' AND ACQ.CATEGORY_CODE LIKE '" + oPRP.CategoryCode + "%'");
            sbQuery.Append(" AND ACQ.ASSET_CODE LIKE '" + oPRP.AssetCode + "%' AND ACQ.SERIAL_CODE LIKE '" + oPRP.SerialCode + "%'");
            sbQuery.Append(" AND ACQ.ASSET_MAKE LIKE '" + oPRP.AssetMake + "%' AND AAL.ALLOCATED_PROCESS LIKE '" + oPRP.FromProcessCode + "%'");    //-- AND AAL.ALLOCATED_EMP_ID LIKE '" + oPRP.AllocatedToId + "%'
            if (oPRP.ModelName != "")
                sbQuery.Append(" AND ACQ.[MODEL_NAME] IN (" + oPRP.ModelName + ")");
            else
                sbQuery.Append(" AND ACQ.[MODEL_NAME] LIKE '" + oPRP.ModelName + "%'");
            sbQuery.Append(" AND AAL.ACTUAL_RTN_DATE IS NULL AND ACQ.ASSET_ALLOCATED = '" + oPRP.AssetAllocated + "' AND AAL.COMP_CODE='" + oPRP.CompCode + "' AND ASSET_APPROVED = 'True' AND SOLD_SCRAPPED_STATUS IS NULL");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Get live gate pass asset code if found any.
        /// </summary>
        /// <param name="_AssetCode"></param>
        /// <returns></returns>
        public string ChkLiveGP(string _AssetCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("SELECT GG.GATEPASS_CODE FROM GATEPASS_GENERATION GG INNER JOIN GATEPASS_ASSETS GA ON GG.GATEPASS_CODE=GA.GATEPASS_CODE");
            sbQuery.Append(" WHERE GA.ASSET_CODE='" + _AssetCode + "' AND GA.GATEPASS_IN_DATE IS NULL");
            DataTable dt = oDb.GetDataTable(sbQuery.ToString());
            if (dt.Rows.Count > 0)
                return dt.Rows[0]["GATEPASS_CODE"].ToString();
            else return "";
        }

        /// <summary>
        /// Save/update asset allocation/return/re-allocation details.
        /// </summary>
        /// <param name="OpType"></param>
        /// <param name="oPRP"></param>
        /// <returns>bResult</returns>
        public bool SaveAssetAllocation(string OpType, AssetAllocation_PRP oPRP)
        {
            bool bResult = false;
            if (OpType == "ALLOCATE")
            {
               
                sbQuery = new StringBuilder();
                sbQuery.Append("INSERT INTO [ASSET_ALLOCATION] ([ASSET_CODE],[ASSET_ALLOCATION_DATE],[REQUESTED_BY],[REQUESTED_BY_ID],");
                sbQuery.Append(" [APPROVED_BY],[APPROVED_BY_ID],[ASSET_ALLOCATED_EMP],[ALLOCATED_EMP_ID],[ALLOCATED_DEPARTMENT],[ALLOCATED_PROCESS],");
                sbQuery.Append(" [ASSET_LOCATION],[EXPECTED_RTN_DATE],[COMP_CODE],[PORT_NO],[VLAN],");
                sbQuery.Append(" [TICKET_NO],[GATEPASS_NO],[WORKSTATION_NO],[CREATED_BY],[CREATED_ON],[REMARKS])");
                sbQuery.Append(" VALUES ");
                sbQuery.Append("('" + oPRP.AssetCode + "','" + oPRP.AllocationDate + "','" + oPRP.RequestedBy + "','" + oPRP.RequestedById + "',");
                sbQuery.Append(" '" + oPRP.ApprovedBy + "','" + oPRP.ApprovedById + "','" + oPRP.AllocatedTo + "','" + oPRP.AllocatedToId + "','" + oPRP.ToDeptCode + "','" + oPRP.ToProcessCode + "',");
                sbQuery.Append(" '" + oPRP.AssetLocation + "','" + oPRP.ExpReturnDate + "','" + oPRP.CompCode + "','" + oPRP.PortNo + "','" + oPRP.Vlan + "',");
                sbQuery.Append(" '" + oPRP.TicketNo + "','" + oPRP.GatePassNo + "','" + oPRP.WorkStationNo + "','" + oPRP.CreatedBy + "',GETDATE(),'" + oPRP.AllocationRemarks + "')");
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;

                sbQuery = new StringBuilder();   // replace ASSET_PROCESS to  Project_Name
                sbQuery.Append("UPDATE ASSET_ACQUISITION SET ASSET_ALLOCATED='" + oPRP.AssetAllocated + "',ASSET_LOCATION='" + oPRP.AssetLocation + "',Project_Name='" + oPRP.ToProcessCode + "',DEPARTMENT='" + oPRP.ToDeptCode + "',");
                sbQuery.Append(" PORT_NO='" + oPRP.PortNo + "' WHERE ASSET_CODE='" + oPRP.AssetCode + "' AND COMP_CODE='" + oPRP.CompCode + "'");
                int iRs = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRs > 0)
                    bResult = true;
            }
            if (OpType == "RETURN")
            {
                sbQuery = new StringBuilder();
                sbQuery.Append("UPDATE ASSET_ALLOCATION SET ACTUAL_RTN_DATE='" + oPRP.ActualReturnDate + "',ALLOCATED_DEPARTMENT='" + oPRP.ToDeptCode + "',ALLOCATED_PROCESS='STOCK',MODIFIED_BY='" + oPRP.ModifiedBy + "'");
                sbQuery.Append(",MODIFIED_ON=GETDATE() WHERE ASSET_CODE='" + oPRP.AssetCode + "' AND COMP_CODE='" + oPRP.CompCode + "'");
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;

                sbQuery = new StringBuilder();
                sbQuery.Append("UPDATE ASSET_ACQUISITION SET ASSET_ALLOCATED='" + oPRP.AssetAllocated + "',ASSET_LOCATION='" + oPRP.AssetLocation + "',DEPARTMENT='" + oPRP.ToDeptCode + "',Project_Name='STOCK',");
                sbQuery.Append(" PORT_NO='" + oPRP.PortNo + "' WHERE ASSET_CODE='" + oPRP.AssetCode + "' AND COMP_CODE='" + oPRP.CompCode + "'");
                int iRs = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRs > 0)
                    bResult = true;
            }
            if (OpType == "REALLOCATE")
            {
                sbQuery = new StringBuilder();
                sbQuery.Append("UPDATE [ASSET_ALLOCATION] SET [ASSET_ALLOCATION_DATE] = '" + oPRP.AllocationDate + "',[REQUESTED_BY] = '" + oPRP.RequestedBy + "',[REQUESTED_BY_ID] = '" + oPRP.RequestedById + "'");
                sbQuery.Append(",[APPROVED_BY] = '" + oPRP.ApprovedBy + "',[APPROVED_BY_ID] = '" + oPRP.ApprovedById + "',[ASSET_ALLOCATED_EMP] = '" + oPRP.AllocatedTo + "',[ALLOCATED_EMP_ID] = '" + oPRP.AllocatedToId + "',[ALLOCATED_DEPARTMENT] = '" + oPRP.ToDeptCode + "'");
                sbQuery.Append(",[ALLOCATED_PROCESS] = '" + oPRP.ToProcessCode + "',[ASSET_LOCATION] = '" + oPRP.AssetLocation + "',[EXPECTED_RTN_DATE] = '" + oPRP.ExpReturnDate + "'");
                sbQuery.Append(",[PORT_NO] = '" + oPRP.PortNo + "',[VLAN] = '" + oPRP.Vlan + "',[TICKET_NO] = '" + oPRP.TicketNo + "',[GATEPASS_NO] = '" + oPRP.GatePassNo + "',[WORKSTATION_NO] = '" + oPRP.WorkStationNo + "',[MODIFIED_BY] = '" + oPRP.ModifiedBy + "',[MODIFIED_ON] = GETDATE()");
                sbQuery.Append(",[REMARKS] = '" + oPRP.AllocationRemarks + "' WHERE [ASSET_CODE] = '" + oPRP.AssetCode + "' AND [COMP_CODE] = '" + oPRP.CompCode + "'");
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;

                sbQuery = new StringBuilder();
                sbQuery.Append("UPDATE ASSET_ACQUISITION SET ASSET_ALLOCATED='" + oPRP.AssetAllocated + "',ASSET_LOCATION='" + oPRP.AssetLocation + "',DEPARTMENT='" + oPRP.ToDeptCode + "',Project_Name='" + oPRP.ToProcessCode + "',");
                sbQuery.Append(" PORT_NO='" + oPRP.PortNo + "' WHERE ASSET_CODE='" + oPRP.AssetCode + "' AND COMP_CODE='" + oPRP.CompCode + "'");
                int iRs = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRs > 0)
                    bResult = true;
            }
            return bResult;
        }

        /// <summary>
        /// Re-allocate assets to another employee/process.
        /// </summary>
        /// <param name="OpType"></param>
        /// <param name="oPRP"></param>
        /// <returns></returns>
        public bool UpdateAssetAllocation(string OpType, AssetAllocation_PRP oPRP)
        {
            bool bResult = false;
            if (OpType == "REALLOCATE")
            {
                sbQuery = new StringBuilder();
                sbQuery.Append("UPDATE [ASSET_ALLOCATION] SET [ASSET_ALLOCATION_DATE] = '" + oPRP.AllocationDate + "',[REQUESTED_BY] = '" + oPRP.RequestedBy + "',[REQUESTED_BY_ID] = '" + oPRP.RequestedById + "'");
                sbQuery.Append(",[APPROVED_BY] = '" + oPRP.ApprovedBy + "',[APPROVED_BY_ID] = '" + oPRP.ApprovedById + "',[ASSET_ALLOCATED_EMP] = '" + oPRP.AllocatedTo + "',[ALLOCATED_EMP_ID] = '" + oPRP.AllocatedToId + "',[ALLOCATED_PROCESS] = '" + oPRP.ToProcessCode + "'");
                sbQuery.Append(",[ASSET_LOCATION] = '" + oPRP.AssetLocation + "',[EXPECTED_RTN_DATE] = '" + oPRP.ExpReturnDate + "',[ACTUAL_RTN_DATE] = '" + oPRP.ActualReturnDate + "',[COMP_CODE] = '" + oPRP.CompCode + "',[PORT_NO] = '" + oPRP.PortNo + "'");
                sbQuery.Append(",[VLAN] = '" + oPRP.Vlan + "',[TICKET_NO] = '" + oPRP.TicketNo + "',[GATEPASS_NO] = '" + oPRP.GatePassNo + "',[WORKSTATION_NO] = '" + oPRP.WorkStationNo + "',[CREATED_BY] = '" + oPRP.CreatedBy + "',[CREATED_ON] = GETDATE()");
                sbQuery.Append(",[REMARKS] = '" + oPRP.AllocationRemarks + "'");
                sbQuery.Append(" WHERE [ASSET_CODE] = '" + oPRP.AssetCode + "'");
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
            }
            return bResult;
        }

        /// <summary>
        /// Get asset allocation details.
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable GetAssetAllocationDetails(string CompCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("SELECT AAL.ASSET_CODE,CONVERT(VARCHAR,NULLIF(AAL.ASSET_ALLOCATION_DATE,''),105) AS ASSET_ALLOCATION_DATE,AAL.WORKSTATION_NO,AAL.PORT_NO,EM.EMPLOYEE_NAME,DM.DEPT_NAME,PM.PROCESS_NAME,LM.LOC_NAME,");
            sbQuery.Append("CONVERT(VARCHAR,NULLIF(AAL.EXPECTED_RTN_DATE,''),105) AS EXPECTED_RTN_DATE,CONVERT(VARCHAR,NULLIF(AAL.ACTUAL_RTN_DATE,''),105) AS ACTUAL_RTN_DATE");
            sbQuery.Append(" FROM ASSET_ALLOCATION AAL INNER JOIN ASSET_ACQUISITION AA ON AAL.ASSET_CODE = AA.ASSET_CODE AND AAL.COMP_CODE = AA.COMP_CODE");
            sbQuery.Append(" INNER JOIN CATEGORY_MASTER CM ON AA.CATEGORY_CODE = CM.CATEGORY_CODE INNER JOIN EMPLOYEE_MASTER EM");
            sbQuery.Append(" ON AAL.ALLOCATED_EMP_ID = EM.EMPLOYEE_CODE AND AAL.COMP_CODE = EM.COMP_CODE");
            sbQuery.Append(" INNER JOIN DEPARTMENT_MASTER DM ON AAL.ALLOCATED_DEPARTMENT = DM.DEPT_CODE");
            sbQuery.Append(" AND AAL.COMP_CODE = DM.COMP_CODE INNER JOIN PROCESS_MASTER PM ");
            sbQuery.Append(" ON AAL.ALLOCATED_PROCESS = PM.PROCESS_CODE INNER JOIN LOCATION_MASTER LM ON AAL.ASSET_LOCATION = LM.LOC_CODE");
            sbQuery.Append(" AND AAL.COMP_CODE = LM.COMP_CODE WHERE AAL.COMP_CODE='" + CompCode + "'");
            sbQuery.Append(" AND AAL.COMP_CODE = EM.COMP_CODE AND AAL.COMP_CODE = PM.COMP_CODE ORDER BY AAL.MODIFIED_ON DESC");
            return oDb.GetDataTable(sbQuery.ToString());
        }
        
        /// <summary>
        /// Get asset other details based on asset code provided.
        /// </summary>
        /// <param name="_AssetCode"></param>
        /// <returns></returns>
        public DataTable GetAssetDetails(string _AssetCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("SELECT ASSET_ID,ASSET_MAKE,SERIAL_CODE,MODEL_NAME,ASSET_TYPE FROM ASSET_ACQUISITION");
            sbQuery.Append(" WHERE ASSET_CODE='" + _AssetCode + "'");
            return oDb.GetDataTable(sbQuery.ToString());
        }
    }
}