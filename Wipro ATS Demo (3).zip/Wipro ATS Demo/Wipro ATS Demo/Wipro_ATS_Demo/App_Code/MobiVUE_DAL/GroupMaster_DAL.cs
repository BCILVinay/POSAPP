﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Text;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MobiVUE_ATS.PRP;

namespace MobiVUE_ATS.DAL
{
    /// <summary>
    /// Summary description for GroupMaster_DAL
    /// </summary>
    public class GroupMaster_DAL
    {
        clsDb oDb;
        StringBuilder sbQuery;
        public GroupMaster_DAL(string DatabaseType)
        {
            oDb = new clsDb();
            if (DatabaseType != "")
                oDb.Connect(DatabaseType);
        }
        ~GroupMaster_DAL()
        {
            oDb.Disconnect();
            oDb = null;
            sbQuery = null;
        }

        /// <summary>
        /// Checking duplicate group name in a company.
        /// </summary>
        /// <param name="_GroupCode"></param>
        /// <returns></returns>
        private bool CheckDuplicateGroup(string _GroupCode, string _CompCode)
        {
            try
            {
                bool bDup = false;
                sbQuery = new StringBuilder();
                sbQuery.Append("SELECT * FROM GROUP_MASTER WHERE GROUP_CODE='" + _GroupCode.Trim().Replace("'", "''") + "' AND COMP_CODE='" + _CompCode + "'");
                DataTable dt = oDb.GetDataTable(sbQuery.ToString());
                if (dt.Rows.Count > 0)
                    bDup = true;
                return bDup;
            }
            catch (Exception ex)
            { throw ex; }
        }

        /// <summary>
        /// Save/update group details into group master table.
        /// </summary>
        /// <param name="OpType"></param>
        /// <param name="oPRP"></param>
        /// <returns></returns>
        public bool SaveUpdateGroup(string OpType, GroupMaster_PRP oPRP)
        {
            try
            {
                bool bResult = false;
               // oDb.BeginTrans();

                if (OpType == "SAVE")
                {
                    if (!CheckDuplicateGroup(oPRP.GroupCode, oPRP.CompCode))
                    {
                        //Add new Group...
                        sbQuery = new StringBuilder();
                        sbQuery.Append("INSERT INTO [GROUP_MASTER]([GROUP_CODE],[GROUP_NAME],[REMARKS],[ACTIVE],[COMP_CODE],[CREATED_BY],[CREATED_ON])");
                        sbQuery.Append(" VALUES ('" + oPRP.GroupCode.Trim() + "','" + oPRP.GroupName.Trim() + "','" + oPRP.Remarks.Trim() + "','" + oPRP.Active + "', ");
                        sbQuery.Append(" '" + oPRP.CompCode + "','" + oPRP.CreatedBy + "',GETDATE());");
                    }
                }
                if (OpType == "UPDATE")
                {
                    //Update Group Information...
                    sbQuery = new StringBuilder();
                    sbQuery.Append("UPDATE [GROUP_MASTER] SET [GROUP_NAME] = '" + oPRP.GroupName + "',[REMARKS] = '" + oPRP.Remarks + "',[ACTIVE] = '" + oPRP.Active + "', ");
                    sbQuery.Append("[MODIFIED_BY] = '" + oPRP.ModifiedBy + "',[MODIFIED_ON] = GETDATE()");
                    sbQuery.Append(" WHERE [GROUP_CODE] = '" + oPRP.GroupCode + "' AND [COMP_CODE] = '" + oPRP.CompCode + "'");
                }
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0 && OpType == "SAVE")
                {
                    sbQuery = null;
                    sbQuery = new StringBuilder();
                    sbQuery.Append("INSERT INTO GROUP_RIGHTS");
                    sbQuery.Append(" SELECT '" + oPRP.CompCode + "' AS CMP_CODE, '" + oPRP.GroupCode + "' AS GCODE,PAGE_CODE,PAGE_NAME,0,0,0,0,0 FROM PAGE_MASTER");
                    oDb.ExecuteQuery(sbQuery.ToString());
                }
                //oDb.CommitTrans();
                bResult = true;
                return bResult;
            }
            catch (Exception ex)
            {
               // oDb.RollBack();
                throw ex;
            }
        }

        /// <summary>
        /// Get group master details to be populated for being viewed.
        /// </summary>
        /// <param name="CompCode"></param>
        /// <returns></returns>
        public DataTable GetGroup(string CompCode)
        {
            try
            {
                sbQuery = new StringBuilder();
                sbQuery.Append("SELECT GROUP_CODE,GROUP_NAME,REMARKS,ACTIVE,CREATED_BY,CONVERT(VARCHAR,CREATED_ON,105) AS CREATED_ON FROM GROUP_MASTER");
                sbQuery.Append(" WHERE COMP_CODE = '" + CompCode + "'");
                return oDb.GetDataTable(sbQuery.ToString());
            }
            catch (Exception ex)
            { throw ex; }
        }

        /// <summary>
        /// Delete group master details based on certain conditions.
        /// </summary>
        /// <param name="_GroupCode"></param>
        /// <param name="_CompCode"></param>
        /// <returns></returns>
        public string DeleteGroup(string _GroupCode, string _CompCode)
        {
            try
            {
                string DelRslt = "";
                sbQuery = new StringBuilder();
                sbQuery.Append("SELECT COUNT(*) AS GRP FROM USER_ACCOUNTS WHERE GROUP_CODE='" + _GroupCode + "' AND COMP_CODE='" + _CompCode + "'");
                DataTable dtRefChk = oDb.GetDataTable(sbQuery.ToString());
                if (dtRefChk.Rows[0]["GRP"].ToString() != "0")
                {
                    DelRslt = "GROUP_IN_USE";
                    return DelRslt;
                }
                sbQuery = new StringBuilder();
                sbQuery.Append("DELETE FROM GROUP_MASTER WHERE GROUP_CODE='" + _GroupCode + "' AND COMP_CODE='" + _CompCode + "'");
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                {
                    sbQuery = null;
                    sbQuery = new StringBuilder();
                    sbQuery.Append("DELETE FROM GROUP_RIGHTS WHERE GROUP_CODE='" + _GroupCode + "' AND COMP_CODE='" + _CompCode + "'");
                    oDb.ExecuteQuery(sbQuery.ToString());
                    DelRslt = "SUCCESS";
                }
                return DelRslt;
            }
            catch (Exception ex)
            { throw ex; }
        }

        /// <summary>
        /// Get page master details.
        /// </summary>
        /// <returns></returns>
        public DataTable GetAllPages()
        {
            try
            {
                sbQuery = new StringBuilder();
                sbQuery.Append("SELECT PAGE_CODE,PAGE_NAME FROM PAGE_MASTER");
                return oDb.GetDataTable(sbQuery.ToString());
            }
            catch (Exception ex)
            { throw ex; }
        }
    }
}