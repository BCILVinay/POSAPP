﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Text;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MobiVUE_ATS.PRP;

namespace MobiVUE_ATS.DAL
{
    /// <summary>
    /// Summary description for CompanyMaster_DAL
    /// </summary>
    public class CountryMaster_DAL
    {
        clsDb oDb;
        StringBuilder sbQuery;
        public CountryMaster_DAL(string DatabaseType)
        {
            oDb = new clsDb();
            if (DatabaseType != "")
                oDb.Connect(DatabaseType);
        }
        ~CountryMaster_DAL()
        {
            oDb.Disconnect();
            oDb = null;
            sbQuery = null;
        }

        private bool CheckDuplicateCountry(string _CountryCode)
        {
            try
            {
                bool bDup = false;
                sbQuery = new StringBuilder();
                sbQuery.Append("EXEC sp_CountryMaster @TYPE='CHECKDUPLICATECOUNTRY', @COUNTRY_CODE= '" + _CountryCode + "'");
                DataTable dt = oDb.GetDataTable(sbQuery.ToString());
                if (dt.Rows.Count > 0)
                    bDup = true;
                return bDup;
            }
            catch (Exception ex)
            { throw ex; }
        }

        public bool SaveCountry(CountryMaster_PRP oPRP)
        {
            try
            {
                bool bResult = false;
                sbQuery = new StringBuilder();
                if (!CheckDuplicateCountry(oPRP.CountryCode))
                {                    
                    sbQuery.Append("EXEC sp_CountryMaster @TYPE='SAVECOUNTRY',@COUNTRY_CODE='" + oPRP.CountryCode.Trim().Replace("'", "''") + "',@COUNTRY_NAME='" + oPRP.CountryName.Trim().Replace("'", "''") + "',");
                    sbQuery.Append(" @REMARKS='" + oPRP.Remarks.Trim() + "',@ACTIVE='" + oPRP.Active + "',@CREATED_BY='" + oPRP.CreatedBy + "'");                    
                }

                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }

        public bool UpdateCountry(CountryMaster_PRP oPRP)
        {
            try
            {
                bool bResult = false;
                sbQuery = new StringBuilder();
                sbQuery.Append("EXEC sp_CountryMaster @TYPE='UPDATECOUNTRY', @COUNTRY_NAME= '" + oPRP.CountryName + "',@ACTIVE='" + oPRP.Active + "',");
                sbQuery.Append(" @REMARKS='" + oPRP.Remarks + "',@MODIFIED_BY='" + oPRP.ModifiedBy + "',@COUNTRY_CODE='" + oPRP.CountryCode + "'");
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }

        public DataTable GetCountryDetails()
        {
            try
            {
                sbQuery = new StringBuilder();
                sbQuery.Append("EXEC sp_CountryMaster @TYPE='GETCOUNTRYDETAILS'");                
                return oDb.GetDataTable(sbQuery.ToString());
            }
            catch (Exception ex)
            { throw ex; }
        }


        /// <summary>
        /// Delete entire details of the company from database based on company location master.
        /// </summary>       
        public bool DeleteCounrty(string _CountryCode)
        {
            try
            {
                bool bResult = false;
                sbQuery = new StringBuilder();
                sbQuery.Append("EXEC sp_CountryMaster @TYPE='DELETECOUNTRY',@COUNTRY_CODE='" + _CountryCode + "'");
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }
    }
}