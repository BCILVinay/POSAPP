﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using DataAccess;
using System.Data.SqlClient;
using BCILLogger;
using System.Configuration;

namespace ATS_MailService
{
    public enum MovementType
    {
        RFIDMoveMent = 0,
        AssetMovement = 1,
        RFIDApprovalMovement = 2, // After asset approval then first time enter in storage location
        MovementAlert = 3,
        RFIDUnAuthriseLaptop = 4,
        ReceivingMovement=5 
    }
    public class UpdateRequest
    {
        public MovementType MovementType { get; set; }
        public AssetRequest AssetRequestMovement { get; set; }
        public AssetRFIDMovement AssetRFIDMovement { get; set; }
    }
    public class MailService
    {
        private const int threadWaitTime = 1000;
        private bool _isRunningService = default(bool);
        private delegate void MailSend(ATSMail obj, UpdateRequest request);
        public delegate void MailSended(string message);
        public event MailSended OnSendedMail;
        private event MailSend OnSend;
        private ATSMail mail;
        private ATSMail RFIDMail;
        private ATSMail MovementAlertMail;
        private ATSMail UnauthriseLaptopMail;
        private List<AssetRequest> _requests;
        private List<AssetRFIDMovement> _rFIDMovementRequests;
        private List<AssetRFIDMovement> _rfIDUnauthrizeLaptop;
        private List<AssetRequest> _MovementAlert;
        private Thread th = default(Thread);
        private Thread RFIDMovementThread = default(Thread);
        private Thread MovementAlertThread = default(Thread);
        private Thread UnAuthriseLaptopThread = default(Thread);


        private string HostName;
        private int Port;
        private string SenderEmail;
        private string UserId;
        private string SenderPassword;
        private static readonly object RFIDMOVEMENT = new object();

        private static readonly object ASSETMOVEMENT = new object();

        public List<AlertDisableCategory> DisableCategory { get; set; }

        private AssetRequestMailSearchCriteria MailSearchCriteria { get; set; }

        private AssetRequestMailSearchCriteria MovementAlertSearchCriteria { get; set; }

        public Logger logWrite { get; set; }

        public MailService(string HostName, int Port, string SenderEmail, string UserId, string SenderPassword)
        {
            this._requests = new List<AssetRequest>();
            this._rFIDMovementRequests = new List<AssetRFIDMovement>();
            this._rfIDUnauthrizeLaptop = new List<AssetRFIDMovement>();
            this._MovementAlert = new List<AssetRequest>();
            this.HostName = HostName;
            this.Port = Port;
            this.SenderEmail = SenderEmail;
            this.SenderPassword = SenderPassword;
            this.UserId = UserId;
            this.mail = new ATSMail(HostName, Port, SenderEmail, UserId, SenderPassword);
            this.RFIDMail = new ATSMail(HostName, Port, SenderEmail, UserId, SenderPassword);
            this.MovementAlertMail = new ATSMail(HostName, Port, SenderEmail, UserId, SenderPassword);
            this.UnauthriseLaptopMail = new ATSMail(HostName, Port, SenderEmail, UserId, SenderPassword);
            this.DisableCategory = new List<AlertDisableCategory>();
            OnSend += MailService_OnSend;
            MailSearchCriteria = new AssetRequestMailSearchCriteria();
            this.MovementAlertSearchCriteria = new AssetRequestMailSearchCriteria();
            logWrite = new Logger();
            logWrite.AppPath = ConfigurationManager.AppSettings["LogFilePath"];
            logWrite.EnableLogging = true;
            logWrite.ErrorFileName = "RTSMailLog";
            logWrite.FileType = "DEBUG";
            logWrite.MaxFileSize = 5;
            logWrite.NoOfDaysToDeleteFile = 2;


        }

        private void RunningService()
        {
            while (_isRunningService)
            {
                try
                {
                    MailSearchCriteria.MailStatus = false;
                    MailSearchCriteria.RequestType = "ASSETREQUEST";
                    GetRequest(MailSearchCriteria);


                    if (this._requests.Count > 0)
                    {
                        logWrite.WriteLog("RTS Request Movement Total  Data Found." + this._requests.Count);
                        IEnumerable<string> requestids = _requests.Select(p => p.RequestId).Distinct();

                        foreach (var requestId in requestids)
                        {
                            AssetRequest request = this._requests.Find(p => p.RequestId == requestId);

                            try
                            {

                                if (request != default(AssetRequest) && request.MailStatus == false)
                                {
                                    var _assetCodes = request.AssetCode; //string.Join(",", this._requests.FindAll(p => p.RequestId == requestId && p.MailStatus == false).Select(s => s.AssetCode));
                                    var Recipients = request.ReceiverEmail;
                                    var MailContent = "Request Id:" + request.RequestId + " Request Status:" + Enum.GetName(typeof(AssetRequestStage), request.Stage) + "\n MIN CODE :" + _assetCodes;
                                    var Subject = "RTS Request";
                                    var CCRecipients = "";
                                    this.mail = CreateMail(_assetCodes, MailContent, Recipients, Subject, CCRecipients);
                                    if (OnSend != null)
                                    {
                                        var UpdateRequest = new UpdateRequest();
                                        UpdateRequest.MovementType = MovementType.AssetMovement;
                                        UpdateRequest.AssetRequestMovement = request;
                                        OnSend(mail, UpdateRequest);
                                    }
                                }

                                //if (request != default(AssetMailer) && this._requests.Find(p => p.RequestId == requestId && p.ISRFIDEmailSend == false && p.MoveTagId != default(long)) != default(AssetMailer))
                                //{
                                //    var _assetCodes = string.Join(",", this._requests.FindAll(p => p.RequestId == requestId && p.ISRFIDEmailSend == false && p.MoveTagId != default(long)).Select(s => s.AssetCode));
                                //    var Recipients = request.ReceiverCMFEmail;
                                //    var MailContent = "Request Id:" + request.RequestId + " Request Status:" + Enum.GetName(typeof(AssetRequestStage), request.Stage) + "\n Asset :" + _assetCodes;
                                //    var Subject = "Asset Request For RFID Movement";
                                //    this.mail = CreateMail(_assetCodes, mail.MailContent, mail.Recipients, mail.Subject);
                                //    if (OnSend != null)
                                //    {
                                //        var UpdateRequest = new UpdateRequest();
                                //        UpdateRequest.MovementType = MovementType.AssetMovement;
                                //        UpdateRequest.AssetRequestMovement = request;
                                //        OnSend(mail, UpdateRequest);
                                //    }
                                //}

                            }
                            catch (Exception ex)
                            {
                                logWrite.WriteLog(ex);
                            }
                        }

                        this._requests.Clear();

                    }
                    else
                    {
                        logWrite.WriteLog("No Data Found.");
                    }


                }
                catch (Exception ex)
                {
                    logWrite.WriteLog(ex);
                }
            }

        }



        private void MovementAlertRunningService()
        {
            while (_isRunningService)
            {
                try
                {
                    this.MovementAlertSearchCriteria.RequestType = "MOVEMENT_DELAY_NOTIFICATION";

                    GetRequestAlert(this.MovementAlertSearchCriteria);


                    if (this._MovementAlert.Count > 0)
                    {
                        logWrite.WriteLog("RTS Request Movement Alert Total  Data Found." + this._MovementAlert.Count);

                        var locationCodes = _MovementAlert.Where(p => string.IsNullOrEmpty(p.LocationCode) == false)
                          .Select(p => p.LocationCode).Distinct();

                        foreach (var locationCode in locationCodes)
                        {


                            IEnumerable<string> requestids = _MovementAlert
                                .Where(p => p.LocationCode == locationCode)
                                .Select(p => p.RequestId).Distinct();

                            foreach (var requestId in requestids)
                            {
                                AssetRequest request = this._MovementAlert.Find(p => p.RequestId == requestId);
                                var IsSendAlertNotification = IsSendAlert(requestId, "IS_SEND_ALERT");
                                try
                                {

                                    if (request != default(AssetRequest) && IsSendAlertNotification)
                                    {
                                        var _assetCodes = request.AssetCode; //string.Join(",", this._requests.FindAll(p => p.RequestId == requestId && p.MailStatus == false).Select(s => s.AssetCode));
                                        var Recipients = request.LocationDetails.CMFEmail;
                                        var MailContent = "Request Id:" + request.RequestId + " Request Status:" + Enum.GetName(typeof(AssetRequestStage), request.Stage) + "\n MIN CODE :" + _assetCodes;
                                        var Subject = "RTS Movement Request Notification Alert Mail ";
                                        var CCRecipients = "";
                                        this.MovementAlertMail = CreateMail(_assetCodes, MailContent, Recipients, Subject, CCRecipients);
                                        if (OnSend != null)
                                        {
                                            var UpdateRequest = new UpdateRequest();
                                            UpdateRequest.MovementType = MovementType.MovementAlert;
                                            UpdateRequest.AssetRequestMovement = request;
                                            OnSend(this.MovementAlertMail, UpdateRequest);
                                        }
                                    }

                                    //if (request != default(AssetMailer) && this._requests.Find(p => p.RequestId == requestId && p.ISRFIDEmailSend == false && p.MoveTagId != default(long)) != default(AssetMailer))
                                    //{
                                    //    var _assetCodes = string.Join(",", this._requests.FindAll(p => p.RequestId == requestId && p.ISRFIDEmailSend == false && p.MoveTagId != default(long)).Select(s => s.AssetCode));
                                    //    var Recipients = request.ReceiverCMFEmail;
                                    //    var MailContent = "Request Id:" + request.RequestId + " Request Status:" + Enum.GetName(typeof(AssetRequestStage), request.Stage) + "\n Asset :" + _assetCodes;
                                    //    var Subject = "Asset Request For RFID Movement";
                                    //    this.mail = CreateMail(_assetCodes, mail.MailContent, mail.Recipients, mail.Subject);
                                    //    if (OnSend != null)
                                    //    {
                                    //        var UpdateRequest = new UpdateRequest();
                                    //        UpdateRequest.MovementType = MovementType.AssetMovement;
                                    //        UpdateRequest.AssetRequestMovement = request;
                                    //        OnSend(mail, UpdateRequest);
                                    //    }
                                    //}

                                }
                                catch (Exception ex)
                                {
                                    logWrite.WriteLog(ex);
                                }
                            }
                        }
                        this._MovementAlert.Clear();
                    }
                    else
                    {
                        logWrite.WriteLog(" RTS Notification Alert No Data Found.");
                    }


                }
                catch (Exception ex)
                {
                    logWrite.WriteLog(ex);
                }
            }

        }



        private bool IsSendAlert(string RequestId, string Type)
        {

            DBManager dbManager = new DlCommon().DBProvider;
            bool IsAlertMail = default(bool);
            try
            {
                dbManager.CreateParameters(2);
                dbManager.AddParameters(0, "@type", Type);
                dbManager.AddParameters(1, "@RequestId", RequestId);

                dbManager.Open();

                SqlDataReader reader = (SqlDataReader)dbManager.ExecuteReader(System.Data.CommandType.StoredProcedure, "USP_MailAlert");
                if (reader.HasRows)
                {
                    if (reader.Read())
                    {
                        IsAlertMail = reader["IsSendAlert"] == DBNull.Value ? default(bool) : Convert.ToBoolean(reader["IsSendAlert"]);
                    }
                }
                return IsAlertMail;
            }
            catch (Exception)
            {
                return IsAlertMail;
            }
        }

        /// <summary>
        /// RFID Movement
        /// </summary>
        /// 
        private void RFIDMovementRunningService()
        {
            while (_isRunningService)
            {
                try
                {

                    GetRFIDMovementRequest();



                    if (this._rFIDMovementRequests.Count > 0)
                    {
                        logWrite.WriteLog("RTS Movement Total  Data Found." + this._rFIDMovementRequests.Count);
                        var locationCodes = _rFIDMovementRequests.Where(p =>
                            string.IsNullOrEmpty(p.ASSET_LOCATION) == false)
                           .Select(p => p.RequestFromLocation).Distinct();
                        foreach (var locationCode in locationCodes)
                        {
                            logWrite.WriteLog(@"RTS Movement Total  Data Found location Code(" + locationCode + ")." +
                                (this._rFIDMovementRequests.FindAll(p => p.RequestFromLocation == locationCode).Count));

                            var AuthrizeRequest = this._rFIDMovementRequests
                                .FindAll(p => p.IsAuthrozeAssset
                                && !string.IsNullOrEmpty(p.RequestId)
                                && !p.IsEmailSend && p.IsRFIDApproved
                                && p.RequestFromLocation == locationCode
                                && p.ReaderLocationCode == p.RequestFromLocation
                                );


                            var UnAuthrizeRequest = this._rFIDMovementRequests.FindAll(p =>
                                !p.IsAuthrozeAssset && string.IsNullOrEmpty(p.RequestId) && !p.IsEmailSend
                                && p.IsRFIDApproved && p.RequestFromLocation == locationCode
                                && !this.DisableCategory.
                                Select(dc => dc.CategoryName.ToUpper()).Contains(p.CategoryName.ToUpper()));

                            var RFIDApprRequest = this._rFIDMovementRequests
                                .FindAll(p => p.IsRFIDApproved == false
                                && p.RequestFromLocation == locationCode
                                && p.RequestFromLocation == p.ReaderLocationCode
                                );

                            // added new logic for unauthrize request when request raised for
                            // location  1 but asset moved to location 2.

                            var UnAuthrizeLocationRequest = this._rFIDMovementRequests
                                .FindAll(p => p.IsAuthrozeAssset
                               && !string.IsNullOrEmpty(p.RequestId)
                               && !p.IsEmailSend && p.IsRFIDApproved
                               && p.RequestFromLocation == locationCode
                               && p.ReaderLocationCode != p.RequestFromLocation
                               && ((p.RequestStage == AssetRequestStage.Raised)
                               || (p.RequestStage == AssetRequestStage.PMApproved)
                               || (p.RequestStage == AssetRequestStage.CMFApproved)
                               || (p.RequestStage == AssetRequestStage.ClearanceApproved && ( p.ReaderLocationCode !=p.RequestToLocation))
                               )
                               );

                            // added new logic for asset received 


                            var AssetForReceived = this._rFIDMovementRequests
                                .FindAll(p => p.IsAuthrozeAssset
                               && !string.IsNullOrEmpty(p.RequestId)
                               && !p.IsEmailSend && p.IsRFIDApproved
                               && p.RequestFromLocation == locationCode
                               && p.ReaderLocationCode == p.RequestToLocation
                               && (p.RequestStage == AssetRequestStage.ClearanceApproved)
                               );



                            logWrite.WriteLog("RTS Movement Authrize Data Count." + AuthrizeRequest.Count);
                            logWrite.WriteLog("RTS Movement Unauthrize Data Count." + UnAuthrizeRequest.Count);
                            logWrite.WriteLog("RTS Movement RFID Approval Data Count." + RFIDApprRequest.Count);
                            logWrite.WriteLog("RTS Movement Unauthrize location read Data Count." + UnAuthrizeLocationRequest.Count);
                            logWrite.WriteLog("RTS Movement For Receiving  Data Count." + AssetForReceived.Count);

                            
                            UnAuthriseLocation(UnAuthrizeLocationRequest);

                            this.ReceiveingAsset(AssetForReceived);
                            
                            this.RFIDApprovalRequest(RFIDApprRequest);

                            if (AuthrizeRequest != null && AuthrizeRequest.Count > 0)
                            {
                                var requestids = AuthrizeRequest.Select(p => p.RequestId).Distinct();
                                foreach (var requestId in requestids)
                                {
                                    var cmfEmaild = string.Join(";", this._rFIDMovementRequests
                                        .FindAll(p => p.RequestId == requestId && p.RequestFromLocation == locationCode)
                                        .Select(c => c.CMFEmail).Distinct());

                                    var gsgEmail = string.Join(";", this._rFIDMovementRequests
                                        .FindAll(p => p.RequestId == requestId
                                            && p.RequestFromLocation == locationCode)
                                        .Select(c => c.GSGEmail).Distinct());

                                    var request = this._rFIDMovementRequests
                                        .FindAll(p => p.RequestId == requestId
                                        && p.RequestFromLocation == locationCode);

                                    var requestedLocation =
                                        this._rFIDMovementRequests
                                        .FindAll(p => p.RequestId == requestId
                                            && p.ReaderLocationCode == locationCode)
                                        .Select(c => c.ReaderLocationCode + "-" + c.ReaderLocationName).FirstOrDefault();

                                    var _assetCodes = string.Join(",", request.Select(s => s.AssetCode));
                                    var Recipients = cmfEmaild + ";" + gsgEmail;
                                    var MailContent = AuthrizeMailContent(AuthrizeRequest);
                                    var CCRecipients = string.Empty;

                                    var Subject = "RTS - Authorized Material Movement " + requestedLocation;

                                    this.RFIDMail = CreateMail(_assetCodes, MailContent, Recipients, Subject, CCRecipients);
                                    if (OnSend != null)
                                    {
                                        var Updaterequest = new UpdateRequest();
                                        Updaterequest.MovementType = MovementType.RFIDMoveMent;
                                        Updaterequest.AssetRFIDMovement = new AssetRFIDMovement();
                                        Updaterequest.AssetRFIDMovement.AssetCode = _assetCodes;
                                        Updaterequest.AssetRFIDMovement.IsEmailSend = true;
                                        OnSend(RFIDMail, Updaterequest);
                                    }
                                }
                            }

                            //
                            if (UnAuthrizeRequest != null && UnAuthrizeRequest.Count > 0)
                            {
                                var ProjectManagerEmail = UnAuthrizeRequest.Where(p => string.IsNullOrEmpty(p.ProjectManagerEmail) == false).Select(p => p.ProjectManagerEmail).Distinct();

                                foreach (var PMEmail in ProjectManagerEmail)
                                {
                                    var Assets = UnAuthrizeRequest.FindAll(p => p.ProjectManagerEmail == PMEmail).Select(q => q.AssetCode);
                                    var AssetCodes = String.Join(",", Assets);
                                    var CMFEmailId = UnAuthrizeRequest.FindAll(p => Assets.Contains(p.AssetCode) && string.IsNullOrEmpty(p.CMFEmail) == false).Select(C => C.CMFEmail).Distinct();
                                    var GSGEmailId = UnAuthrizeRequest.FindAll(p => Assets.Contains(p.AssetCode) && string.IsNullOrEmpty(p.GSGEmail) == false).Select(C => C.GSGEmail).Distinct();
                                    var requestedFromLocation = UnAuthrizeRequest.FindAll(p => Assets.Contains(p.AssetCode) && string.IsNullOrEmpty(p.AssetLocationName) == false).Select(C => C.AssetLocationName).Distinct();
                                    var _assetCodes = AssetCodes;

                                    var UnAuthrizeRequestProjectwise = UnAuthrizeRequest.FindAll(p => p.ProjectManagerEmail == PMEmail);
                                    var ReaderLocation = UnAuthrizeRequest.FindAll(p =>
                                                         Assets.Contains(p.AssetCode)
                                                         && string.IsNullOrEmpty(p.AssetLocationName) == false)
                                                         .Select(C => C.ReaderLocationCode + "-" + C.ReaderLocationName)
                                                         .Distinct().FirstOrDefault();

                                    var Recipients = PMEmail;
                                    var CCRecipients = string.Join(";", CMFEmailId) + ';' + string.Join(";", GSGEmailId);

                                    var MailContent = UNAuthrizeMailContent(UnAuthrizeRequestProjectwise);//" Unauthrized RTS movement: " + _assetCodes;
                                    string Subject = string.Empty;
                                    if (ReaderLocation != null)
                                    {
                                        Subject = "RTS - Unauthorized Material Movement " + ReaderLocation;
                                    }
                                    else
                                    {
                                        Subject = "RTS - Unauthorized Material Movement ";
                                    }

                                    this.RFIDMail = CreateMail(_assetCodes, MailContent, Recipients, Subject, CCRecipients);
                                    if (OnSend != null)
                                    {
                                        var Updaterequest = new UpdateRequest();
                                        Updaterequest.MovementType = MovementType.RFIDMoveMent;
                                        Updaterequest.AssetRFIDMovement = new AssetRFIDMovement();
                                        Updaterequest.AssetRFIDMovement.AssetCode = _assetCodes;
                                        Updaterequest.AssetRFIDMovement.IsEmailSend = true;
                                        OnSend(RFIDMail, Updaterequest);
                                    }
                                }
                            }
                        }

                        this._rFIDMovementRequests.Clear();

                    }
                    else
                    {
                        logWrite.WriteLog("No Data Found.");
                    }
                }

                catch (Exception ex)
                {
                    logWrite.WriteLog(ex);
                }

                Thread.Sleep(threadWaitTime);
            }



        }

        private void RFIDMovementUnauthriseLaptop()
        {
            while (_isRunningService)
            {
                try
                {
                    GetRFIDMovementUnAuthriseLaptop();

                    if (this._rfIDUnauthrizeLaptop.Count > 0)
                    {
                        var locationCodes = _rfIDUnauthrizeLaptop.Where(p => string.IsNullOrEmpty(p.ASSET_LOCATION) == false)
                            .Select(p => p.RequestFromLocation).Distinct();

                        foreach (var locationCode in locationCodes)
                        {


                            var ProjectManagerEmail = _rfIDUnauthrizeLaptop.Where(p =>
                                string.IsNullOrEmpty(p.ProjectManagerEmail) == false
                                && p.RequestFromLocation == locationCode)
                                .Select(p => p.ProjectManagerEmail).Distinct();

                            foreach (var PMEmail in ProjectManagerEmail)
                            {
                                var Assets = _rfIDUnauthrizeLaptop.FindAll(p => p.ProjectManagerEmail == PMEmail).Select(q => q.AssetCode);
                                var movementTagId = _rfIDUnauthrizeLaptop.FindAll(p => p.ProjectManagerEmail == PMEmail).Select(q => q.RFIDTagMovementId).Distinct();
                                var AssetCodes = String.Join(",", Assets);
                                var movementTagIds = string.Join(",", movementTagId);
                                var CMFEmailId = _rfIDUnauthrizeLaptop.FindAll(p => Assets.Contains(p.AssetCode) && string.IsNullOrEmpty(p.CMFEmail) == false).Select(C => C.CMFEmail).Distinct();
                                var GSGEmailId = _rfIDUnauthrizeLaptop.FindAll(p => Assets.Contains(p.AssetCode) && string.IsNullOrEmpty(p.GSGEmail) == false).Select(C => C.GSGEmail).Distinct();
                                var requestedFromLocation = _rfIDUnauthrizeLaptop.FindAll(p => Assets.Contains(p.AssetCode) && string.IsNullOrEmpty(p.AssetLocationName) == false).Select(C => C.AssetLocationName).Distinct();
                                var _assetCodes = AssetCodes;

                                var Recipients = PMEmail;
                                var CCRecipients = string.Join(";", CMFEmailId) + ';' + string.Join(";", GSGEmailId);

                                var MailContent = UNAuthrizeMailContent(_rfIDUnauthrizeLaptop);//" Unauthrized RTS movement: " + _assetCodes;
                                string Subject = string.Empty;
                                if (requestedFromLocation != null)
                                {
                                    Subject = "RTS - Unauthorized Material Movement " + string.Join(";", requestedFromLocation);
                                }
                                else
                                {
                                    Subject = "RTS - Unauthorized Material Movement ";
                                }

                                this.UnauthriseLaptopMail = CreateMail(_assetCodes, MailContent, Recipients, Subject, CCRecipients);
                                if (OnSend != null)
                                {
                                    var Updaterequest = new UpdateRequest();
                                    Updaterequest.MovementType = MovementType.RFIDUnAuthriseLaptop;
                                    Updaterequest.AssetRFIDMovement = new AssetRFIDMovement();
                                    Updaterequest.AssetRFIDMovement.AssetCode = _assetCodes;
                                    Updaterequest.AssetRFIDMovement.RFIDTagMovementId = movementTagIds;
                                    Updaterequest.AssetRFIDMovement.RequestFromLocation = locationCode;
                                    Updaterequest.AssetRFIDMovement.IsEmailSend = true;

                                    OnSend(UnauthriseLaptopMail, Updaterequest);
                                }
                            }
                        }

                        this._rfIDUnauthrizeLaptop.Clear();
                    }
                    else
                    {
                        logWrite.WriteLog("No Unauthrize Laptop Data Found.");
                    }
                }

                catch (Exception ex)
                {
                    logWrite.WriteLog(ex);
                }

                Thread.Sleep(threadWaitTime);
            }



        }


        private void RFIDApprovalRequest(List<AssetRFIDMovement> RFIDApprovalRequests)
        {
            try
            {
                var locationCodes = RFIDApprovalRequests.Select(p => p.RequestFromLocation).Distinct();

                foreach (var stLOC in locationCodes)
                {
                    var request = RFIDApprovalRequests.FindAll(p => p.RequestFromLocation == stLOC);
                    var stLocationName = request.Select(p => p.AssetLocationName).FirstOrDefault();
                    var cmf = string.Join(";", request.Select(p => p.CMFEmail).Distinct());

                    var assets = string.Join(",", request.Select(p => p.AssetCode).Distinct());

                    var mailContent = "Dear CMF Team , RFID MIN has been approved <br/>" + " Location: " + stLocationName + "<br/> Min Code :" + assets;
                    var subject = "RFID MIN Approval  ";
                    var ccRecepeint = string.Empty;

                    var mail = this.CreateMail(assets, mailContent, cmf, subject, ccRecepeint);

                    if (OnSend != null)
                    {
                        var Updaterequest = new UpdateRequest();
                        Updaterequest.MovementType = MovementType.RFIDApprovalMovement;
                        Updaterequest.AssetRFIDMovement = new AssetRFIDMovement();
                        Updaterequest.AssetRFIDMovement.AssetCode = assets;
                        Updaterequest.AssetRFIDMovement.IsEmailSend = true;
                        Updaterequest.AssetRFIDMovement.IsRFIDApproved = true;

                        OnSend(mail, Updaterequest);
                    }
                }
            }
            catch (Exception ex)
            {
                logWrite.WriteLog(ex.Message);
            }
        }

        private string AuthrizeMailContent(List<AssetRFIDMovement> AuthrizeRequest)
        {
            string content = string.Empty;
            try
            {
                string RequestNo = AuthrizeRequest.First().RequestId;
                string RequestStage = Enum.GetName(typeof(AssetRequestStage), AuthrizeRequest.First().RequestStage);
                StringBuilder sbMsg = new StringBuilder();
                sbMsg.Append(@"<html><body>Dear Project Manager ,<br/><br/>");
                sbMsg.AppendLine(@"System Identified authorized movement. Mentioned Material identification number ( MIN ) belongs to your project moved out from ODC.<br/><br/>");
                sbMsg.AppendLine(@"Request No." + RequestNo + " Request status :" + RequestStage + "<br/><br/>");

                sbMsg.Append(@" <table border='1'><tr><th>SNO </th><th>MIN Code </th><th>Project </th></tr>");
                int rno = 1;
                foreach (var request in AuthrizeRequest)
                {
                    sbMsg.Append(@"<tr><td>" + rno + " </td> <td>" + request.AssetCode + "</td><td>" + request.ProjectName + "</td></tr>");
                    rno = rno + 1;
                }
                sbMsg.Append(@"</table><br/>");
                sbMsg.AppendLine(@"Please connect to Central Material Function SPOC / Global Security Group SPOC of your location immediately [marked in mail CC]. <br/><br/>");

                sbMsg.AppendLine(@"Regards,<br/>");

                // sbMsg.AppendLine(@"<br/>");

                sbMsg.AppendLine(@"CMF – RF ID Tracking System <br/><br/>");
                content = sbMsg.ToString();
            }
            catch (Exception)
            {

            }
            return content;
        }

        private string UNAuthrizeMailContent(List<AssetRFIDMovement> UnAuthrizeRequest)
        {
            string content = string.Empty;
            try
            {
                var Assets = UnAuthrizeRequest.Select(q => q.AssetCode);
                var AssetCodes = String.Join(",", Assets);
                var requestedFromLocation = UnAuthrizeRequest.FindAll(p => Assets.Contains(p.AssetCode)
                    && string.IsNullOrEmpty(p.AssetLocationName) == false)
                    .Select(C => C.AssetLocationName).Distinct();
                string locationName = string.Join(",", requestedFromLocation);

                StringBuilder sbMsg = new StringBuilder();
                sbMsg.Append(@"<html><body>Dear Project Manager ,<br/><br/>");
                //System Identified unauthorized movement. Mentioned Material Identification Number ( MIN ) 
                //belongs to your project moved out from ODC without Customs approval

                sbMsg.AppendLine(@"System Identified unauthorized movement. Mentioned Material identification number ");
                sbMsg.AppendLine(@"(MIN ) belongs to your project moved out from ODC without Customs approval. <br/>");

                sbMsg.AppendLine(@" MIN Location:" + locationName + "<br/><br/>");

                sbMsg.AppendLine(@"Customs approval is critical for any movement. Request you to take appropriate action including raising MMR in MyWipro Portal”.<br/><br/>");

                sbMsg.Append(@" <table border='1'><tr><th>MIN </th><th>Asset</th><th>Project</th></tr>");
                int rno = 1;
                foreach (var request in UnAuthrizeRequest)
                {
                    sbMsg.Append(@"<tr><td>" + rno + " </td> <td>" + request.AssetCode + "</td><td>" + request.ProjectName + "</td></tr>");
                    rno = rno + 1;
                }
                sbMsg.Append(@"</table><br/>");
                sbMsg.AppendLine(@"Please connect to Global Security Group SPOC of your location immediately [marked in mail CC]. <br/><br/>");

                sbMsg.AppendLine(@"Regards,<br/>");

                // sbMsg.AppendLine(@"<br/>");

                sbMsg.AppendLine(@"CMF – RF ID Tracking System <br/><br/>");
                content = sbMsg.ToString();
            }
            catch (Exception)
            {

            }
            return content;
        }










        private void ReceiveingAsset(List<AssetRFIDMovement> ReceiveingAsset)
        {
            try
            {
                if (ReceiveingAsset != null && ReceiveingAsset.Count > 0)
                {
                    var requestids = ReceiveingAsset.Select(p => p.RequestId).Distinct();
                    foreach (var requestId in requestids)
                    {
                        var cmfEmaild = string.Join(";", ReceiveingAsset
                            .FindAll(p => p.RequestId == requestId)
                            .Select(c => c.CMFEmail).Distinct());

                        var gsgEmail = string.Join(";", ReceiveingAsset
                            .FindAll(p => p.RequestId == requestId)
                            .Select(c => c.GSGEmail).Distinct());

                        var request = ReceiveingAsset
                            .FindAll(p => p.RequestId == requestId);


                        var ReaderLocation =
                           ReceiveingAsset
                            .FindAll(p => p.RequestId == requestId)
                            .Select(c => c.ReaderLocationCode + "-" + c.ReaderLocationName).FirstOrDefault();

                        var _assetCodes = string.Join(",", request.Select(s => s.AssetCode).Distinct());



                        var _toCmfEmaild = string.Join(";", ReceiveingAsset
                          .FindAll(p => p.RequestId == requestId)
                          .Select(c => c.ReaderLocationCMF).Distinct());

                        var _toGsgEmail = string.Join(";", ReceiveingAsset
                            .FindAll(p => p.RequestId == requestId)
                            .Select(c => c.ReaderLocationGSG).Distinct());


                        var Recipients = _toCmfEmaild + ";" + _toGsgEmail;

                        var _requestForReceiving = ReceiveingAsset.FindAll(p => p.RequestId == requestId);
                        var MailContent = ReceiveingMailContent(_requestForReceiving);
                        
                        var CCRecipients = cmfEmaild + ";" + gsgEmail;
                        
                        var Subject = "RTS - Receiveing  Material Movement " + ReaderLocation;

                        var mail = CreateMail(_assetCodes, MailContent, Recipients, Subject, CCRecipients);
                        if (OnSend != null)
                        {
                            var Updaterequest = new UpdateRequest();
                            Updaterequest.MovementType = MovementType.ReceivingMovement;
                            Updaterequest.AssetRFIDMovement = new AssetRFIDMovement();
                            Updaterequest.AssetRFIDMovement.AssetCode = _assetCodes;
                            Updaterequest.AssetRFIDMovement.IsEmailSend = true;
                            OnSend(mail, Updaterequest);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                logWrite.WriteLog(ex);
            }
        }





        private void UnAuthriseLocation(List<AssetRFIDMovement> UnAuthrizeLocation)
        {
            try
            {
                if (UnAuthrizeLocation != null && UnAuthrizeLocation.Count > 0)
                {
                    var requestids = UnAuthrizeLocation.Select(p => p.RequestId).Distinct();
                    foreach (var requestId in requestids)
                    {
                        var cmfEmaild = string.Join(";", UnAuthrizeLocation
                            .FindAll(p => p.RequestId == requestId)
                            .Select(c => c.CMFEmail).Distinct());

                        var gsgEmail = string.Join(";", UnAuthrizeLocation
                            .FindAll(p => p.RequestId == requestId)
                            .Select(c => c.GSGEmail).Distinct());

                        var request = UnAuthrizeLocation
                            .FindAll(p => p.RequestId == requestId);


                        var requestedLocation =
                           UnAuthrizeLocation
                            .FindAll(p => p.RequestId == requestId)
                            .Select(c => c.ReaderLocationCode + "-" + c.ReaderLocationName).FirstOrDefault();

                        var _assetCodes = string.Join(",", request.Select(s => s.AssetCode).Distinct());
                        var Recipients = cmfEmaild + ";" + gsgEmail;
                        var UnAuthrizeLocationx = UnAuthrizeLocation.FindAll(p => p.RequestId == requestId);
                        var MailContent = UnAuthrizeLocationMailContent(UnAuthrizeLocationx);


                        var _cCcmfEmaild = string.Join(";", UnAuthrizeLocation
                            .FindAll(p => p.RequestId == requestId)
                            .Select(c => c.ReaderLocationCMF).Distinct());

                        var _cCgsgEmail = string.Join(";", UnAuthrizeLocation
                            .FindAll(p => p.RequestId == requestId)
                            .Select(c => c.ReaderLocationGSG).Distinct());

                        var CCRecipients = _cCcmfEmaild + ";" + _cCgsgEmail;

                        var Subject = "RTS - Unauthorized Material Movement " + requestedLocation;

                        var mail = CreateMail(_assetCodes, MailContent, Recipients, Subject, CCRecipients);
                        if (OnSend != null)
                        {
                            var Updaterequest = new UpdateRequest();
                            Updaterequest.MovementType = MovementType.RFIDMoveMent;
                            Updaterequest.AssetRFIDMovement = new AssetRFIDMovement();
                            Updaterequest.AssetRFIDMovement.AssetCode = _assetCodes;
                            Updaterequest.AssetRFIDMovement.IsEmailSend = true;
                            OnSend(mail, Updaterequest);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                logWrite.WriteLog(ex);
            }
        }

        private string UnAuthrizeLocationMailContent(List<AssetRFIDMovement> AuthrizeRequest)
        {
            string content = string.Empty;
            try
            {
                string RequestNo = AuthrizeRequest.First().RequestId;
                string RequestStage = Enum.GetName(typeof(AssetRequestStage), AuthrizeRequest.First().RequestStage);
                string ReaderLocation = AuthrizeRequest.First().ReaderLocationCode + "-" + AuthrizeRequest.First().ReaderLocationName;
                string RequestLocationFrom = AuthrizeRequest.First().RequestFromLocation + "-" + AuthrizeRequest.First().AssetLocationName;
                string RequestToLocation = AuthrizeRequest.First().RequestToLocation + "-" + AuthrizeRequest.First().RequestToLocationName;

                StringBuilder sbMsg = new StringBuilder();
                sbMsg.Append(@"<html><body>Dear Project Manager ,<br/><br/>");
                sbMsg.AppendLine(@"System Identified Unauthorized movement. Mentioned Material identification number ( MIN ) belongs to your project moved out from ODC.<br/><br/>");

                sbMsg.AppendLine(@"Request No." + RequestNo + " Request status :" + RequestStage + "<br/>");

                sbMsg.AppendLine(@" Request From Location" + RequestLocationFrom + " Request To Location :" + RequestToLocation + "<br/>");

                sbMsg.AppendLine(@" MIN Read Location" + ReaderLocation + "<br/>");


                sbMsg.Append(@" <table border='1'><tr><th>SNO </th><th>MIN Code </th><th>Project </th></tr>");
                int rno = 1;
                foreach (var request in AuthrizeRequest)
                {
                    sbMsg.Append(@"<tr><td>" + rno + " </td> <td>" + request.AssetCode + "</td><td>" + request.ProjectName + "</td></tr>");
                    rno = rno + 1;
                }
                sbMsg.Append(@"</table><br/>");
                sbMsg.AppendLine(@"Please connect to Central Material Function SPOC / Global Security Group SPOC of your location immediately [marked in mail CC]. <br/><br/>");

                sbMsg.AppendLine(@"Regards,<br/>");

                // sbMsg.AppendLine(@"<br/>");

                sbMsg.AppendLine(@"CMF – RF ID Tracking System <br/><br/>");
                content = sbMsg.ToString();
            }
            catch (Exception)
            {

            }
            return content;
        }




        private string ReceiveingMailContent(List<AssetRFIDMovement> AuthrizeRequest)
        {
            string content = string.Empty;
            try
            {
                string RequestNo = AuthrizeRequest.First().RequestId;
                string RequestStage = Enum.GetName(typeof(AssetRequestStage), AuthrizeRequest.First().RequestStage);
                string ReaderLocation = AuthrizeRequest.First().ReaderLocationCode + "-" + AuthrizeRequest.First().ReaderLocationName;
                string RequestLocationFrom = AuthrizeRequest.First().RequestFromLocation + "-" + AuthrizeRequest.First().AssetLocationName;
                string RequestToLocation = AuthrizeRequest.First().RequestToLocation + "-" + AuthrizeRequest.First().RequestToLocationName;


                StringBuilder sbMsg = new StringBuilder();
                sbMsg.Append(@"<html><body>Dear CMF ,<br/><br/>");
                sbMsg.AppendLine(@"System Identified authorized movement for receiveing. Mentioned Material identification number ( MIN ) belongs to your project moved out from ODC.<br/><br/>");

                sbMsg.AppendLine(@"Request No." + RequestNo + " Request status :" + RequestStage + "<br/>");

                sbMsg.AppendLine(@" Request From Location" + RequestLocationFrom + " Request To Location :" + RequestToLocation + "<br/>");

                sbMsg.AppendLine(@" MIN Read Location" + ReaderLocation + "<br/>");


                sbMsg.Append(@" <table border='1'><tr><th>SNO </th><th>MIN Code </th><th>Project </th></tr>");
                int rno = 1;
                foreach (var request in AuthrizeRequest)
                {
                    sbMsg.Append(@"<tr><td>" + rno + " </td> <td>" + request.AssetCode + "</td><td>" + request.ProjectName + "</td></tr>");
                    rno = rno + 1;
                }
                sbMsg.Append(@"</table><br/>");
                sbMsg.AppendLine(@"Please connect to Central Material Function SPOC / Global Security Group SPOC of your location immediately [marked in mail CC]. <br/><br/>");

                sbMsg.AppendLine(@"Regards,<br/>");

                // sbMsg.AppendLine(@"<br/>");

                sbMsg.AppendLine(@"CMF – RF ID Tracking System <br/><br/>");
                content = sbMsg.ToString();
            }
            catch (Exception)
            {

            }
            return content;
        }






        public void StartService()
        {
            try
            {
                GetDisableCategoryConfig();
                this._isRunningService = true;
                ThreadStart ts = new ThreadStart(this.RunningService);
                this.th = new Thread(ts);
                this.th.Start();

                ThreadStart RfidThreadStart = new ThreadStart(this.RFIDMovementRunningService);
                this.RFIDMovementThread = new Thread(RfidThreadStart);
                this.RFIDMovementThread.Start();

                ThreadStart MovementAlertThreadStart = new ThreadStart(this.MovementAlertRunningService);
                this.MovementAlertThread = new Thread(MovementAlertThreadStart);
                this.MovementAlertThread.Start();

                ThreadStart UnAuthriseLaptop = new ThreadStart(RFIDMovementUnauthriseLaptop);
                this.UnAuthriseLaptopThread = new Thread(UnAuthriseLaptop);
                this.UnAuthriseLaptopThread.Start();


            }
            catch (Exception ex)
            {
                logWrite.WriteLog(ex);
            }
        }

        public void StopService()
        {
            try
            {
                this._isRunningService = false;
                this.OnSend -= this.MailService_OnSend;
                this.th.Abort();
                this.RFIDMovementThread.Abort();
                this.MovementAlertThread.Abort();
                this.UnAuthriseLaptopThread.Abort();
            }
            catch (Exception ex)
            {
                logWrite.WriteLog(ex);
            }
        }


        private void GetDisableCategoryConfig()
        {
            DBManager dbManager = new DlCommon().DBProvider;
            try
            {
                dbManager.Open();
                SqlDataReader reader = (SqlDataReader)dbManager.ExecuteReader(System.Data.CommandType.Text, "USP_CategoryConfig");
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        AlertDisableCategory obj = new AlertDisableCategory();
                        obj.CategoryName = reader["MinCategoryName"] == DBNull.Value ? string.Empty : Convert.ToString(reader["MinCategoryName"]);
                        obj.IsDisable = reader["IsDisable"] == DBNull.Value ? default(bool) : Convert.ToBoolean(reader["IsDisable"]);
                        this.DisableCategory.Add(obj);
                    }
                }
            }
            catch (Exception ex)
            {
                logWrite.WriteLog(ex);
            }
            finally
            {
                dbManager.Close();
            }
        }

        private void MailService_OnSend(ATSMail obj, UpdateRequest request)
        {
            try
            {
                string responseMessage = string.Empty;
                bool x = default(bool);
                try
                {


                    x = this.SendMail(obj);
                    //  x = obj.Send();
                    if (x == true)
                    {
                        UpdateMailStatus(request);
                        responseMessage = "Mail Send Successfully : Mail To- " + obj.Recipients + " Mail CC- " + obj.CCRecipients + " Mail Subject- " + obj.Subject + ", Request Type:" + Enum.GetName(typeof(MovementType), request.MovementType);
                        logWrite.WriteLog(responseMessage);
                    }
                    else
                    {
                        responseMessage = "Sending mail fail: ";
                        logWrite.WriteLog(responseMessage);
                    }
                }
                catch (Exception ex)
                {
                    responseMessage = "Sending Mail Fails: Mail To- " + obj.Recipients + " Mail CC- " + obj.CCRecipients + " Mail Subject- " + obj.Subject + "  Request Type:" + Enum.GetName(typeof(MovementType), request.MovementType)
                        + "\n" + ex.Message;
                    logWrite.WriteLog(responseMessage);
                }

                if (OnSendedMail != null)
                {

                    responseMessage = x == true ? "Send Mail Successfully" : responseMessage;
                    if (request.MovementType == MovementType.AssetMovement)
                    {
                        responseMessage = responseMessage + "\n AssetMovement Request Requestid : " + request.AssetRequestMovement.RequestId + " \n AssetCode :" + request.AssetRequestMovement.AssetCode;
                    }
                    else if ((request.MovementType == MovementType.RFIDMoveMent) || (request.MovementType == MovementType.ReceivingMovement))
                    {
                        responseMessage = responseMessage + "\n RFID Movement Request AssetCode: " + request.AssetRFIDMovement.AssetCode;
                    }
                    else if (request.MovementType == MovementType.RFIDUnAuthriseLaptop)
                    {
                        responseMessage = responseMessage + "\n RFID Unauthrize Laptop Movement Request AssetCode: " + request.AssetRFIDMovement.AssetCode;
                    }

                    OnSendedMail(responseMessage);
                }
            }
            catch (Exception ex)
            {
                logWrite.WriteLog(ex);
            }

        }

        private ATSMail CreateMail(string AssetCode, string MailContent, string Recipients, string Subject, string CCRecipients)
        {
            try
            {
                ATSMail mail = new ATSMail(this.HostName, this.Port, this.SenderEmail, this.UserId, this.SenderPassword);
                mail.Recipients = Recipients;
                mail.MailContent = MailContent;
                mail.Subject = Subject;
                mail.CCRecipients = CCRecipients;
                return mail;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        private void GetRequest(AssetRequestMailSearchCriteria criteria)
        {
            DBManager dbManager = new DlCommon().DBProvider;

            try
            {
                dbManager.CreateParameters(2);
                dbManager.AddParameters(0, "@EmailStatus", criteria.MailStatus);
                dbManager.AddParameters(1, "@type", criteria.RequestType);
                dbManager.Open();
                SqlDataReader reader = (SqlDataReader)dbManager.ExecuteReader(System.Data.CommandType.StoredProcedure, "USP_MailerAssetMovement");
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        AssetRequest _request = new AssetRequest();
                        _request.LocationCode = reader["LOCATION_CODE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["LOCATION_CODE"]);
                        _request.RequestId = reader["REQUEST_HDR_ID"] == DBNull.Value ? string.Empty : Convert.ToString(reader["REQUEST_HDR_ID"]);
                        _request.IsPermanent = reader["IS_PERMANENT"] == DBNull.Value ? false : Convert.ToBoolean(reader["IS_PERMANENT"]);
                        _request.TransferTo = reader["TRANSFER_TO"] == DBNull.Value ? string.Empty : Convert.ToString(reader["TRANSFER_TO"]);
                        _request.IsInterUnit = reader["IS_INTERUNIT"] == DBNull.Value ? false : Convert.ToBoolean(reader["IS_INTERUNIT"]);
                        _request.LocationTo = reader["LOCATION_TO"] == DBNull.Value ? string.Empty : Convert.ToString(reader["LOCATION_TO"]);
                        _request.ProjectCode = reader["PROJECT_CODE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["PROJECT_CODE"]);
                        _request.ReceiverEmail = reader["RECEIVER_EMAIL"] == DBNull.Value ? string.Empty : Convert.ToString(reader["RECEIVER_EMAIL"]);
                        _request.GstNo = reader["GST_NO"] == DBNull.Value ? string.Empty : Convert.ToString(reader["GST_NO"]);
                        _request.ProjectCostCentre = reader["PROJECT_COST_CENTRE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["PROJECT_COST_CENTRE"]);
                        _request.PMApprove = reader["PM_APPROVE"] == DBNull.Value ? false : Convert.ToBoolean(reader["PM_APPROVE"]);
                        _request.PMRemark = reader["PM_REMARKS"] == DBNull.Value ? string.Empty : Convert.ToString(reader["PM_REMARKS"]);
                        _request.CMFApprove = reader["CMF_APPROVE"] == DBNull.Value ? false : Convert.ToBoolean(reader["CMF_APPROVE"]);
                        _request.CMFRemark = reader["CMF_REMARKS"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CMF_REMARKS"]);
                        _request.IsClerance = reader["IS_CLEARANCE"] == DBNull.Value ? false : Convert.ToBoolean(reader["IS_CLEARANCE"]);
                        _request.Stage = reader["STAGE"] == DBNull.Value ? AssetRequestStage.None : (AssetRequestStage)(reader["STAGE"]);
                        _request.CreatedOn = reader["CREATED_ON"] == DBNull.Value ? null : (DateTime?)(reader["CREATED_ON"]);
                        _request.CreatedBY = reader["CREATED_BY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CREATED_BY"]);
                        _request.PMApprovedOn = reader["PM_APPROVED_ON"] == DBNull.Value ? null : (DateTime?)(reader["PM_APPROVED_ON"]);
                        _request.PMApprovedBy = reader["PM_APPROVED_BY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["PM_APPROVED_BY"]);
                        _request.CMFApprovedOn = reader["CMF_APPROVED_ON"] == DBNull.Value ? null : (DateTime?)(reader["CMF_APPROVED_ON"]);
                        _request.CMFApprovedBy = reader["CMF_APPROVED_BY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CMF_APPROVED_BY"]);
                        _request.ClearanceOn = reader["CLEARANCE_ON"] == DBNull.Value ? null : (DateTime?)(reader["CLEARANCE_ON"]);
                        _request.ClearanceBy = reader["CLEARANCE_BY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CLEARANCE_BY"]);
                        _request.ReceivedOn = reader["RECEIVED_ON"] == DBNull.Value ? default(DateTime?) : (DateTime?)(reader["RECEIVED_ON"]);
                        _request.ReceivedBy = reader["RECEIVED_BY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["RECEIVED_BY"]);
                        _request.MailStatus = reader["MAIL_STATUS"] == DBNull.Value ? default(bool) : Convert.ToBoolean(reader["MAIL_STATUS"]);
                        _request.AssetCode = reader["AssetCode"] == DBNull.Value ? string.Empty : Convert.ToString(reader["AssetCode"]);
                        //_request.ISRFIDEmailSend = reader["Email_Flag"] == DBNull.Value ? default(bool) : Convert.ToBoolean(reader["Email_Flag"]);
                        //_request.MoveTagId = reader["Move_Tag_ID"] == DBNull.Value ? default(long) : Convert.ToInt64(reader["Move_Tag_ID"]);
                        //_request.ReceiverCMFEmail = reader["CMF_GROUP_EMAIL"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CMF_GROUP_EMAIL"]);
                        this._requests.Add(_request);
                    }
                    Thread.Sleep(threadWaitTime);
                }

            }
            catch (Exception ex)
            {
                logWrite.WriteLog(ex);
            }
            finally
            {
                dbManager.Close();
                dbManager.Dispose();
            }
        }

        private void GetRequestAlert(AssetRequestMailSearchCriteria criteria)
        {
            DBManager dbManager = new DlCommon().DBProvider;

            try
            {
                dbManager.CreateParameters(1);

                dbManager.AddParameters(0, "@type", criteria.RequestType);
                dbManager.Open();
                SqlDataReader reader = (SqlDataReader)dbManager.ExecuteReader(System.Data.CommandType.StoredProcedure, "USP_MailerAssetMovement");
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        AssetRequest _request = new AssetRequest();
                        _request.LocationCode = reader["LOCATION_CODE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["LOCATION_CODE"]);
                        _request.RequestId = reader["REQUEST_HDR_ID"] == DBNull.Value ? string.Empty : Convert.ToString(reader["REQUEST_HDR_ID"]);
                        _request.IsPermanent = reader["IS_PERMANENT"] == DBNull.Value ? false : Convert.ToBoolean(reader["IS_PERMANENT"]);
                        _request.TransferTo = reader["TRANSFER_TO"] == DBNull.Value ? string.Empty : Convert.ToString(reader["TRANSFER_TO"]);
                        _request.IsInterUnit = reader["IS_INTERUNIT"] == DBNull.Value ? false : Convert.ToBoolean(reader["IS_INTERUNIT"]);
                        _request.LocationTo = reader["LOCATION_TO"] == DBNull.Value ? string.Empty : Convert.ToString(reader["LOCATION_TO"]);
                        _request.ProjectCode = reader["PROJECT_CODE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["PROJECT_CODE"]);
                        _request.ReceiverEmail = reader["RECEIVER_EMAIL"] == DBNull.Value ? string.Empty : Convert.ToString(reader["RECEIVER_EMAIL"]);
                        _request.GstNo = reader["GST_NO"] == DBNull.Value ? string.Empty : Convert.ToString(reader["GST_NO"]);
                        _request.ProjectCostCentre = reader["PROJECT_COST_CENTRE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["PROJECT_COST_CENTRE"]);
                        _request.PMApprove = reader["PM_APPROVE"] == DBNull.Value ? false : Convert.ToBoolean(reader["PM_APPROVE"]);
                        _request.PMRemark = reader["PM_REMARKS"] == DBNull.Value ? string.Empty : Convert.ToString(reader["PM_REMARKS"]);
                        _request.CMFApprove = reader["CMF_APPROVE"] == DBNull.Value ? false : Convert.ToBoolean(reader["CMF_APPROVE"]);
                        _request.CMFRemark = reader["CMF_REMARKS"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CMF_REMARKS"]);
                        _request.IsClerance = reader["IS_CLEARANCE"] == DBNull.Value ? false : Convert.ToBoolean(reader["IS_CLEARANCE"]);
                        _request.Stage = reader["STAGE"] == DBNull.Value ? AssetRequestStage.None : (AssetRequestStage)(reader["STAGE"]);
                        _request.CreatedOn = reader["CREATED_ON"] == DBNull.Value ? null : (DateTime?)(reader["CREATED_ON"]);
                        _request.CreatedBY = reader["CREATED_BY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CREATED_BY"]);
                        _request.PMApprovedOn = reader["PM_APPROVED_ON"] == DBNull.Value ? null : (DateTime?)(reader["PM_APPROVED_ON"]);
                        _request.PMApprovedBy = reader["PM_APPROVED_BY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["PM_APPROVED_BY"]);
                        _request.CMFApprovedOn = reader["CMF_APPROVED_ON"] == DBNull.Value ? null : (DateTime?)(reader["CMF_APPROVED_ON"]);
                        _request.CMFApprovedBy = reader["CMF_APPROVED_BY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CMF_APPROVED_BY"]);
                        _request.ClearanceOn = reader["CLEARANCE_ON"] == DBNull.Value ? null : (DateTime?)(reader["CLEARANCE_ON"]);
                        _request.ClearanceBy = reader["CLEARANCE_BY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CLEARANCE_BY"]);
                        _request.ReceivedOn = reader["RECEIVED_ON"] == DBNull.Value ? default(DateTime?) : (DateTime?)(reader["RECEIVED_ON"]);
                        _request.ReceivedBy = reader["RECEIVED_BY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["RECEIVED_BY"]);
                        _request.MailStatus = reader["MAIL_STATUS"] == DBNull.Value ? default(bool) : Convert.ToBoolean(reader["MAIL_STATUS"]);
                        _request.AssetCode = reader["AssetCode"] == DBNull.Value ? string.Empty : Convert.ToString(reader["AssetCode"]);

                        _request.LocationDetails.LocationCode = reader["LOCATION_CODE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["LOCATION_CODE"]);
                        _request.LocationDetails.LocationName = reader["LocationName"] == DBNull.Value ? string.Empty : Convert.ToString(reader["LocationName"]);
                        _request.LocationDetails.CMFEmail = reader["CMF_Group_Email"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CMF_Group_Email"]);
                        _request.LocationDetails.GSGEmail = reader["GSG_GROUP_EMAIL"] == DBNull.Value ? string.Empty : Convert.ToString(reader["GSG_GROUP_EMAIL"]);

                        //_request.ISRFIDEmailSend = reader["Email_Flag"] == DBNull.Value ? default(bool) : Convert.ToBoolean(reader["Email_Flag"]);
                        //_request.MoveTagId = reader["Move_Tag_ID"] == DBNull.Value ? default(long) : Convert.ToInt64(reader["Move_Tag_ID"]);
                        //_request.ReceiverCMFEmail = reader["CMF_GROUP_EMAIL"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CMF_GROUP_EMAIL"]);
                        this._MovementAlert.Add(_request);
                    }
                    Thread.Sleep(threadWaitTime);
                }

            }
            catch (Exception ex)
            {
                logWrite.WriteLog(ex);
            }
            finally
            {
                dbManager.Close();
                dbManager.Dispose();
            }
        }


        private void GetRFIDMovementRequest()
        {
            DBManager dbManager = new DlCommon().DBProvider;
            try
            {
                dbManager.CreateParameters(2);
                dbManager.AddParameters(0, "@EmailStatus", false);
                dbManager.AddParameters(1, "@Type", "RFIDMOVEMENT");
                dbManager.Open();
                SqlDataReader reader = (SqlDataReader)dbManager.ExecuteReader(System.Data.CommandType.StoredProcedure, "USP_MailerAssetMovement");
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        AssetRFIDMovement _request = new AssetRFIDMovement();
                        _request.RequestFromLocation = reader["Location_Code"] == DBNull.Value ? string.Empty : Convert.ToString(reader["Location_Code"]);
                        _request.RFIDTagMovementId = reader["Move_Tag_ID"] == DBNull.Value ? string.Empty : Convert.ToString(reader["Move_Tag_ID"]);
                        _request.AssetCode = reader["ASSET_CODE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["ASSET_CODE"]);
                        _request.RequestToLocation = reader["LOCATION_TO"] == DBNull.Value ? string.Empty : Convert.ToString(reader["LOCATION_TO"]);
                        _request.IsAuthrozeAssset = reader["STATUS"] == DBNull.Value ? false : Convert.ToBoolean(reader["STATUS"]);
                        _request.IsEmailSend = reader["EMAIL_FLAG"] == DBNull.Value ? false : Convert.ToBoolean(reader["EMAIL_FLAG"]);
                        _request.CreatedOn = reader["CREATED_ON"] == DBNull.Value ? null : (DateTime?)reader["CREATED_ON"];
                        _request.CreatedBy = reader["CREATED_BY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CREATED_BY"]);
                        _request.ModifiedOn = reader["MODIFIED_ON"] == DBNull.Value ? null : (DateTime?)(reader["MODIFIED_ON"]);
                        _request.ProjectName = reader["Project_Name"] == DBNull.Value ? string.Empty : Convert.ToString(reader["Project_Name"]);
                        _request.ProjectManagerEmail = reader["PM_EMAIL"] == DBNull.Value ? string.Empty : Convert.ToString(reader["PM_EMAIL"]);
                        _request.ProjectManagerName = reader["PROJECT_MANAGER"] == DBNull.Value ? string.Empty : Convert.ToString(reader["PROJECT_MANAGER"]);
                        _request.RequestId = reader["REQUEST_HDR_ID"] == DBNull.Value ? string.Empty : Convert.ToString(reader["REQUEST_HDR_ID"]);
                        _request.CMFEmail = reader["CMF_GROUP_EMAIL"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CMF_GROUP_EMAIL"]);
                        _request.GSGEmail = reader["GSG_GROUP_EMAIL"] == DBNull.Value ? string.Empty : Convert.ToString(reader["GSG_GROUP_EMAIL"]);


                        //Added feild on 23 NOV 2018

                        _request.SerialCode = reader["SERIAL_CODE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["SERIAL_CODE"]);
                        _request.AssetLocationName = reader["STORAGE_LOC_NAME"] == DBNull.Value ? string.Empty : Convert.ToString(reader["STORAGE_LOC_NAME"]);
                        _request.ASSET_ALLOCATED = reader["ASSET_ALLOCATED"] == DBNull.Value ? default(bool) : Convert.ToBoolean(reader["ASSET_ALLOCATED"]);
                        _request.ACQUISITION_ID = reader["ACQUISITION_ID"] == DBNull.Value ? default(int) : Convert.ToInt32(reader["ACQUISITION_ID"]);


                        _request.AMC_WARRANTY = reader["AMC_WARRANTY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["AMC_WARRANTY"]);
                        _request.AMC_WARRANTY_END_DATE = reader["AMC_WARRANTY_END_DATE"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(reader["AMC_WARRANTY_END_DATE"]);
                        _request.AMC_WARRANTY_START_DATE = reader["AMC_WARRANTY_START_DATE"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(reader["AMC_WARRANTY_START_DATE"]);
                        _request.ASSET_ALLOCATED = reader["ASSET_ALLOCATED"] == DBNull.Value ? default(bool) : Convert.ToBoolean(reader["ASSET_ALLOCATED"]);

                        _request.ASSET_APPROVED = reader["ASSET_APPROVED"] == DBNull.Value ? default(bool) : Convert.ToBoolean(reader["ASSET_APPROVED"]);
                        _request.ASSET_BOE = reader["ASSET_BOE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["ASSET_BOE"]);
                        _request.ASSET_DESCRIPTION = reader["ASSET_DESCRIPTION"] == DBNull.Value ? string.Empty : Convert.ToString(reader["ASSET_DESCRIPTION"]);
                        _request.ASSET_ID = reader["ASSET_ID"] == DBNull.Value ? string.Empty : Convert.ToString(reader["ASSET_ID"]);


                        _request.ASSET_LOCATION = reader["ASSET_LOCATION"] == DBNull.Value ? string.Empty : Convert.ToString(reader["ASSET_LOCATION"]);
                        _request.ASSET_MAKE = reader["ASSET_MAKE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["ASSET_MAKE"]);
                        _request.ASSET_TYPE = reader["ASSET_TYPE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["ASSET_TYPE"]);
                        _request.BONDED_TYPE = reader["BONDED_TYPE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["BONDED_TYPE"]);

                        _request.PROJECT_NAME = reader["PROJECT_NAME"] == DBNull.Value ? string.Empty : Convert.ToString(reader["PROJECT_NAME"]);
                        _request.CategoryCode = reader["CATEGORY_CODE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CATEGORY_CODE"]);
                        _request.CategoryName = reader["CATEGORY_NAME"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CATEGORY_NAME"]);
                        _request.IsRFIDApproved = reader["IsRFIDApproved"] == DBNull.Value ? default(bool) : Convert.ToBoolean(reader["IsRFIDApproved"]);

                        // added new feild for reader details 

                        _request.ReaderLocationCode = reader["ReaderLocationCode"] == DBNull.Value ? string.Empty : Convert.ToString(reader["ReaderLocationCode"]);
                        _request.ReaderLocationName = reader["ReaderLocationName"] == DBNull.Value ? string.Empty : Convert.ToString(reader["ReaderLocationName"]);
                        _request.ReaderLocationCMF = reader["ReaderLocationCMF"] == DBNull.Value ? string.Empty : Convert.ToString(reader["ReaderLocationCMF"]);
                        _request.ReaderLocationGSG = reader["ReaderLocationGSG"] == DBNull.Value ? string.Empty : Convert.ToString(reader["ReaderLocationGSG"]);
                        _request.RequestStage = reader["STAGE"] == DBNull.Value ? AssetRequestStage.None : (AssetRequestStage)(reader["STAGE"]);
                        _request.RequestToLocationName = reader["ToLocationName"] == DBNull.Value ? string.Empty: Convert.ToString(reader["ToLocationName"]);
                        
                        this._rFIDMovementRequests.Add(_request);
                    }
                }

            }
            catch (Exception ex)
            {
                logWrite.WriteLog(ex);
            }
            finally
            {
                dbManager.Close();
                dbManager.Dispose();
            }
        }


        private void GetRFIDMovementUnAuthriseLaptop()
        {
            DBManager dbManager = new DlCommon().DBProvider;
            try
            {
                dbManager.CreateParameters(2);
                dbManager.AddParameters(0, "@EmailStatus", false);
                dbManager.AddParameters(1, "@Type", "UNAUTHRISE_LAPTOP");
                dbManager.Open();
                SqlDataReader reader = (SqlDataReader)dbManager.ExecuteReader(System.Data.CommandType.StoredProcedure, "USP_MailerAssetMovement");
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        AssetRFIDMovement _request = new AssetRFIDMovement();
                        _request.RequestFromLocation = reader["Location_Code"] == DBNull.Value ? string.Empty : Convert.ToString(reader["Location_Code"]);
                        _request.RFIDTagMovementId = reader["Move_Tag_ID"] == DBNull.Value ? string.Empty : Convert.ToString(reader["Move_Tag_ID"]);
                        _request.AssetCode = reader["ASSET_CODE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["ASSET_CODE"]);
                        _request.RequestToLocation = reader["LOCATION_TO"] == DBNull.Value ? string.Empty : Convert.ToString(reader["LOCATION_TO"]);
                        _request.IsAuthrozeAssset = reader["STATUS"] == DBNull.Value ? false : Convert.ToBoolean(reader["STATUS"]);
                        _request.IsEmailSend = reader["EMAIL_FLAG"] == DBNull.Value ? false : Convert.ToBoolean(reader["EMAIL_FLAG"]);
                        _request.CreatedOn = reader["CREATED_ON"] == DBNull.Value ? null : (DateTime?)reader["CREATED_ON"];
                        _request.CreatedBy = reader["CREATED_BY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CREATED_BY"]);
                        _request.ModifiedOn = reader["MODIFIED_ON"] == DBNull.Value ? null : (DateTime?)(reader["MODIFIED_ON"]);
                        _request.ProjectName = reader["Project_Name"] == DBNull.Value ? string.Empty : Convert.ToString(reader["Project_Name"]);
                        _request.ProjectManagerEmail = reader["PM_EMAIL"] == DBNull.Value ? string.Empty : Convert.ToString(reader["PM_EMAIL"]);
                        _request.ProjectManagerName = reader["PROJECT_MANAGER"] == DBNull.Value ? string.Empty : Convert.ToString(reader["PROJECT_MANAGER"]);
                        //               _request.RequestId = reader["REQUEST_HDR_ID"] == DBNull.Value ? string.Empty : Convert.ToString(reader["REQUEST_HDR_ID"]);
                        _request.CMFEmail = reader["CMF_GROUP_EMAIL"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CMF_GROUP_EMAIL"]);
                        _request.GSGEmail = reader["GSG_GROUP_EMAIL"] == DBNull.Value ? string.Empty : Convert.ToString(reader["GSG_GROUP_EMAIL"]);


                        //Added feild on 23 NOV 2018

                        _request.SerialCode = reader["SERIAL_CODE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["SERIAL_CODE"]);
                        _request.AssetLocationName = reader["STORAGE_LOC_NAME"] == DBNull.Value ? string.Empty : Convert.ToString(reader["STORAGE_LOC_NAME"]);
                        _request.ASSET_ALLOCATED = reader["ASSET_ALLOCATED"] == DBNull.Value ? default(bool) : Convert.ToBoolean(reader["ASSET_ALLOCATED"]);
                        _request.ACQUISITION_ID = reader["ACQUISITION_ID"] == DBNull.Value ? default(int) : Convert.ToInt32(reader["ACQUISITION_ID"]);


                        _request.AMC_WARRANTY = reader["AMC_WARRANTY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["AMC_WARRANTY"]);
                        _request.AMC_WARRANTY_END_DATE = reader["AMC_WARRANTY_END_DATE"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(reader["AMC_WARRANTY_END_DATE"]);
                        _request.AMC_WARRANTY_START_DATE = reader["AMC_WARRANTY_START_DATE"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(reader["AMC_WARRANTY_START_DATE"]);
                        _request.ASSET_ALLOCATED = reader["ASSET_ALLOCATED"] == DBNull.Value ? default(bool) : Convert.ToBoolean(reader["ASSET_ALLOCATED"]);

                        _request.ASSET_APPROVED = reader["ASSET_APPROVED"] == DBNull.Value ? default(bool) : Convert.ToBoolean(reader["ASSET_APPROVED"]);
                        _request.ASSET_BOE = reader["ASSET_BOE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["ASSET_BOE"]);
                        _request.ASSET_DESCRIPTION = reader["ASSET_DESCRIPTION"] == DBNull.Value ? string.Empty : Convert.ToString(reader["ASSET_DESCRIPTION"]);
                        _request.ASSET_ID = reader["ASSET_ID"] == DBNull.Value ? string.Empty : Convert.ToString(reader["ASSET_ID"]);


                        _request.ASSET_LOCATION = reader["ASSET_LOCATION"] == DBNull.Value ? string.Empty : Convert.ToString(reader["ASSET_LOCATION"]);
                        _request.ASSET_MAKE = reader["ASSET_MAKE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["ASSET_MAKE"]);
                        _request.ASSET_TYPE = reader["ASSET_TYPE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["ASSET_TYPE"]);
                        _request.BONDED_TYPE = reader["BONDED_TYPE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["BONDED_TYPE"]);

                        _request.PROJECT_NAME = reader["PROJECT_NAME"] == DBNull.Value ? string.Empty : Convert.ToString(reader["PROJECT_NAME"]);
                        _request.CategoryCode = reader["CATEGORY_CODE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CATEGORY_CODE"]);
                        _request.CategoryName = reader["CATEGORY_NAME"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CATEGORY_NAME"]);
                        _request.IsRFIDApproved = reader["IsRFIDApproved"] == DBNull.Value ? default(bool) : Convert.ToBoolean(reader["IsRFIDApproved"]);


                        this._rfIDUnauthrizeLaptop.Add(_request);
                    }
                }

            }
            catch (Exception ex)
            {
                logWrite.WriteLog(ex);
            }
            finally
            {
                dbManager.Close();
                dbManager.Dispose();
            }
        }


        private bool SendMail(ATSMail obj)
        {
            DBManager dbManager = null;
            try
            {
                dbManager = new DlCommon().DBProvider;
                dbManager.ParametersList.Clear();
                dbManager.CreateParameters(4);
                //dbManager.AddParameters(0, "@HOSTNAME", obj.HostName);
                //dbManager.AddParameters(1, "@PORT",obj.Port);
                //dbManager.AddParameters(2, "@USERID",obj.UserId);
                //dbManager.AddParameters(3, "@PASSWORD",obj.SenderPassword);
                //dbManager.AddParameters(4, "@SENDEREMAIL", obj.From);

                dbManager.AddParameters(0, "@Recipients", obj.Recipients);
                dbManager.AddParameters(1, "@SUBJECT", obj.Subject);
                dbManager.AddParameters(2, "@BODY", obj.MailContent);
                dbManager.AddParameters(3, "@CCRecipients", obj.CCRecipients);


                dbManager.Open();

                var sendMailStatus = dbManager.ExecuteScalar(System.Data.CommandType.StoredProcedure, "USP_SendMailConfiguration");
                dbManager.Close();


                if (sendMailStatus == null)
                {
                    return false;
                }
                if (Convert.ToString(sendMailStatus) == "Sent")
                {
                    return true;
                }

                else if (Convert.ToString(sendMailStatus) == "Unsent")
                {
                    return true;
                }

                else if (Convert.ToString(sendMailStatus) == "Retrying")
                {
                    return true;
                }

                else if (Convert.ToString(sendMailStatus) == "Failed")
                {
                    return true;
                }
                else
                {
                    return false;
                }



            }
            catch (Exception ex)
            {
                if (dbManager != null)
                {
                    dbManager.Close();
                }
                throw ex;
            }
        }

        private int UpdateMailStatus(UpdateRequest request)
        {
            DBManager dbManager = new DlCommon().DBProvider;
            int x = default(int);
            if (request.MovementType == MovementType.AssetMovement)
            {

                try
                {

                    //if (request.AssetRequestMovement.MoveTagId != default(long) && request.AssetRequestMovement.ISRFIDEmailSend == false)
                    //{
                    //    request.AssetRequestMovement.ISRFIDEmailSend = true;
                    //    dbManager.CreateParameters(2);
                    //    dbManager.AddParameters(0, "@RequestId", request.AssetRequestMovement.RequestId);
                    //    dbManager.AddParameters(0, "@MailStatus", request.AssetRequestMovement.ISRFIDEmailSend);
                    //    dbManager.Open();
                    //    x = dbManager.ExecuteNonQuery(System.Data.CommandType.Text, GetSqlQuery());
                    //    dbManager.Close();
                    //}
                    if (request.AssetRequestMovement.MailStatus == false)
                    {
                        request.AssetRequestMovement.MailStatus = true;
                        dbManager.ParametersList.Clear();
                        dbManager.CreateParameters(2);
                        dbManager.AddParameters(0, "@RequestId", request.AssetRequestMovement.RequestId);
                        dbManager.AddParameters(1, "@MailStatus", request.AssetRequestMovement.MailStatus);
                        dbManager.Open();

                        x = x + dbManager.ExecuteNonQuery(System.Data.CommandType.Text, GetSqlQueryAssetMovement());

                        dbManager.Close();
                    }


                }
                catch
                {
                    throw;
                }
                finally
                {
                    dbManager.Dispose();
                }
            }
            else if (request.MovementType == MovementType.RFIDMoveMent || request.MovementType == MovementType.ReceivingMovement)
            {
                dbManager.ParametersList.Clear();
                dbManager.CreateParameters(2);
                // dbManager.AddParameters(0, "@AssetCode", ("'" + request.AssetRFIDMovement.AssetCode.Replace(",", "','") + "'"));
                dbManager.AddParameters(0, "@MailStatus", request.AssetRFIDMovement.IsEmailSend);
                dbManager.AddParameters(1, "@Email_FLAG", false);

                string sql = string.Format(" UPDATE MOVEMENT_TAG_CHECK set Email_Flag =@MailStatus Where isnull(Email_Flag ,0) = @Email_FLAG  AND  Asset_Code in ({0}) ", ("'" + request.AssetRFIDMovement.AssetCode.Replace(",", "','") + "'"));
                dbManager.Open();
                x = x + dbManager.ExecuteNonQuery(System.Data.CommandType.Text, sql);
                dbManager.Close();
            }
            else if (request.MovementType == MovementType.RFIDApprovalMovement)
            {
                var db = dbManager;
                try
                {

                    db.ParametersList.Clear();
                    db.CreateParameters(3);
                    // dbManager.AddParameters(0, "@AssetCode", ("'" + request.AssetRFIDMovement.AssetCode.Replace(",", "','") + "'"));
                    db.AddParameters(0, "@MailStatus", request.AssetRFIDMovement.IsEmailSend);
                    db.AddParameters(1, "@Email_Flag", false);
                    db.AddParameters(2, "@IsRFIDApproved", request.AssetRFIDMovement.IsRFIDApproved);

                    string sql = string.Format(" UPDATE MOVEMENT_TAG_CHECK set Email_Flag =@MailStatus Where ISNULL(Email_Flag,0)=@Email_Flag AND  Asset_Code in ({0}) ", ("'" + request.AssetRFIDMovement.AssetCode.Replace(",", "','") + "'"));
                    string sql1 = GetSQLQueryRFIDApproval(request.AssetRFIDMovement.AssetCode);
                    string finalQuery = sql + ";" + sql1;
                    db.Open();
                    x = x + db.ExecuteNonQuery(System.Data.CommandType.Text, finalQuery);


                }
                catch (Exception)
                {
                    //db.RollBackTransaction();
                    throw;
                }
                finally
                {
                    db.Close();
                }
            }
            else if (request.MovementType == MovementType.MovementAlert)
            {
                x = x + UpdateAlert(request, dbManager);
            }
            else if (request.MovementType == MovementType.RFIDUnAuthriseLaptop)
            {
                x = x + UpdateUnAuthriseLaptopMovement(request, dbManager);
            }
            return x;
        }

        private int UpdateAlert(UpdateRequest request, DBManager dbManager)
        {
            int x = default(int);
            try
            {
                dbManager.ParametersList.Clear();
                dbManager.CreateParameters(3);
                // dbManager.AddParameters(0, "@AssetCode", ("'" + request.AssetRFIDMovement.AssetCode.Replace(",", "','") + "'"));
                dbManager.AddParameters(0, "@RequestId", request.AssetRequestMovement.RequestId);
                dbManager.AddParameters(1, "@ReqStage", request.AssetRequestMovement.Stage);
                dbManager.AddParameters(2, "@TYPE", "ALERTMail");

                dbManager.Open();
                x = x + dbManager.ExecuteNonQuery(System.Data.CommandType.StoredProcedure, "USP_MailAlert");
                return x;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                dbManager.Close();
                dbManager.Dispose();
            }
        }


        private int UpdateUnAuthriseLaptopMovement(UpdateRequest request, DBManager dbManager)
        {
            int x = default(int);
            try
            {
                dbManager.ParametersList.Clear();
                dbManager.CreateParameters(2);
                //// dbManager.AddParameters(0, "@AssetCode", ("'" + request.AssetRFIDMovement.AssetCode.Replace(",", "','") + "'"));
                //dbManager.AddParameters(0, "@RequestId", request.AssetRequestMovement.RequestId);
                //dbManager.AddParameters(1, "@ReqStage", request.AssetRequestMovement.Stage);
                dbManager.AddParameters(0, "@EmailFlag", request.AssetRFIDMovement.IsEmailSend);
                dbManager.AddParameters(1, "@locationCode", request.AssetRFIDMovement.RequestFromLocation);
                //
                var sqlQuery = UpdateSQLQueryUnauthriseLaptop(request.AssetRFIDMovement.RFIDTagMovementId);

                dbManager.Open();
                x = x + dbManager.ExecuteNonQuery(System.Data.CommandType.Text, sqlQuery);
                return x;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                dbManager.Close();
                dbManager.Dispose();
            }
        }


        private string GetSqlQuery()
        {
            string sqlQuery = @"UPDATE MOVEMENT_TAG_CHECK 
SET Email_Flag =@MailStatus 
from movement_request_hdr  T1 INNER join  [MOVEMENT_REQUEST_DTL] T2 ON T1.REquest_HDR_ID = T2.REquest_HDR_ID
INNER JOIN MOVEMENT_TAG_CHECK T3 on T3.ASSET_CODE = T2.ASSET_CODE 
WHERE T1.REquest_HDR_ID =@RequestId";
            return sqlQuery;
        }

        private string GetSqlQueryAssetMovement()
        {
            string sqlQuery = "UPDATE  movement_request_hdr SET Mail_Status = @MailStatus WHERE  REquest_HDR_ID =@RequestId ";
            return sqlQuery;
        }

        private string GetSQLQueryRFIDApproval(string AssetCode)
        {
            string sqlQuery = string.Format("UPDATE  ASSET_ACQUISITION SET IsRFIDApproved = @IsRFIDApproved , RFIDApprovedOn = GetDate() Where Asset_Code in ({0}) ", ("'" + AssetCode.Replace(",", "','") + "'"));
            return sqlQuery;
        }

        private string UpdateSQLQueryUnauthriseLaptop(string MovementTagIds)
        {
            //SET EMAIL_FLAG =@EmailFlag
            string sqlQuery = string.Empty;  //string.Format("UPDATE  ASSET_ACQUISITION SET IsRFIDApproved = @IsRFIDApproved Where Asset_Code in ({0}) ", ("'" + AssetCode.Replace(",", "','") + "'"));

            sqlQuery = string.Format(@"
INSERT INTO UnAuthrizeLaptopSendMailHistory
SELECT T1.* ,GetDate() from MOVEMENT_TAG_CHECK_LapTop T1
WHERE T1.MOVE_TAG_ID in ({0})  AND LOCATION_CODE =@locationCode;

DELETE FROM  MOVEMENT_TAG_CHECK_LapTop  WHERE MOVE_TAG_ID in ({0})

", ("'" + MovementTagIds.Replace(",", "','") + "'"));

            return sqlQuery;
        }

    }
}
