﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using System.Threading;
using BCILLogger;
using System.Configuration;

namespace ATS_MailService
{
    class Program
    {
    static    Logger logFile;
        static void Main(string[] args)
        {

            try
            {
                logFile = new Logger();
                int PortNo = 80;

                var HostName = "host" ;//ConfigurationManager.AppSettings["HostName"];
                var Port = string.Empty;//ConfigurationManager.AppSettings["Port"];
                var SenderEmail ="dunny@dunny.com"; //ConfigurationManager.AppSettings["SenderEmail"];
                var UserId ="host"; //ConfigurationManager.AppSettings["UserId"];
                var SenderPassword = "host"; //ConfigurationManager.AppSettings["SenderPassword"];

                //logFile.AppPath = ConfigurationManager.AppSettings["LogFilePath"];
                //logFile.EnableLogging = true;
                //logFile.ErrorFileName = "LOCAL";
                //logFile.FileType = "DEBUG";
                //logFile.MaxFileSize = 10;
                //logFile.NoOfDaysToDeleteFile = 5;


                //bool validate = true;
                //if (string.IsNullOrEmpty(HostName))
                //{
                //    validate = false;
                //    logFile.WriteLog("Host Name is Blank !!! ");
                //}
                //if (!int.TryParse(Port, out PortNo))
                //{
                //    validate = false;
                //    logFile.WriteLog("Invalid Port Number !!! ");
                //}
                //if (string.IsNullOrEmpty(SenderEmail))
                //{
                //    validate = false;
                //    logFile.WriteLog("Sender Email is Blank !!! ");
                //}
                //if (string.IsNullOrEmpty(UserId))
                //{
                //    validate = false;
                //    logFile.WriteLog("Sender UserId is Blank !!! ");
                //}
                //if (string.IsNullOrEmpty(SenderPassword))
                //{
                //    validate = false;
                //    logFile.WriteLog("Sender Password is Blank !!! ");
                //}

                //if (validate == false)
                //{
                //    return;
                //}
                MailService service = new MailService(HostName, PortNo, SenderEmail, UserId, SenderPassword);
                //service.logWrite.AppPath = ConfigurationManager.AppSettings["LogFilePath"];
                //service.logWrite.EnableLogging = true;
                //service.logWrite.ErrorFileName = "LOCAL";
                //service.logWrite.FileType = "DEBUG";
                //service.logWrite.MaxFileSize = 10;
                //service.logWrite.NoOfDaysToDeleteFile = 5;
                service.OnSendedMail += service_OnSendedMail;
                service.StartService();
                logFile.WriteLog("Serive Strated At:" + DateTime.Now);
            }
            catch (Exception ex)
            {
                logFile.WriteLog(ex);
            }

        }

        private static void service_OnSendedMail(string message)
        {
            try
            {
                //  logFile.WriteLog(message);
            }
            catch (Exception ex)
            {
               //  logFile.WriteLog(ex);
            }
        }
       
    }

}
