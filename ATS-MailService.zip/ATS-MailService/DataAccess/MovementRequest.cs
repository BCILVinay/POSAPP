﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataAccess
{

   
   public class MovementRequest
    {
      private DBManager dbManager  =null;
       public MovementRequest()
       {
           this.dbManager = new DlCommon().DBProvider;
       }
       public List<AssetRequest> GetAssetRequest()
       {
           try
           {
               return null;
           }
           catch (Exception ex)
           {
               throw ex; 
           }
       }

     
    }



}
