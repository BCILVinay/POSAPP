﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace DataAccess
{
    /// <summary>
    /// Summary description for Class1
    /// </summary>
    /// 
    [Serializable]
    public class UploadDocument
    {
        public int DocumentDetailId { get; set; }
        public string FileName { get; set; }
        public string UploadFilePath { get; set; }
        public string UploadDBFilePath { get; set; }
        public string IsValid { get; set; }
        public UploadDocType DocumentType { get; set; }
    }

    [Serializable]
    public class AssetDetails
    {
        public int AssetDetailId { get; set; }
        public string AssetCode { get; set; }
        public int Quantity { get; set; }
        public string FamsID { get; set; }
        public string CategoryCode { get; set; }
        public string AssetMake { get; set; }
        public string[] AssetModel { get; set; }
        public bool IsUploaded { get; set; }
        public string AssetDBFileName { get; set; }
        public AssetDetails()
        {
            this.AssetModel = new String[1];
        }
    }
    [Serializable]
    public enum AssetRequestStage
    {
        None = 0,
        Raised = 1,
        PMApproved = 2,
        CMFApproved = 3,
        ClearanceApproved = 4,
        GatePassed = 5,
        Received = 6,
        ClearanceReceived = 7,
        PMReject = 8,
        CMFReject = 9,
        ClearanceReject = 10,
        ClearanceRecReject = 11

    }
    [Serializable]
    public enum UploadDocType
    {
        None = 0,
        REQ = 1,
        PM = 2,
        CMF = 3,
        CLRREQ = 4,
        REC = 5,
        CLRREC = 6
    }
    [Serializable]
    public class AssetRequest
    {
        public AssetRequest()
        {
            this.AssetDetails = new List<AssetDetails>();
            this.Documents = new List<UploadDocument>();
            this.LocationDetails = new StorageLocation();
            this.RequestId = string.Empty;
            this.LocationCode = string.Empty;
            this.IsPermanent = default(bool);
            this.TransferTo = string.Empty;
            this.IsInterUnit = default(bool);
            this.LocationTo = string.Empty;
            this.ProjectCode = string.Empty;
            this.ReceiverEmail = string.Empty;
            this.GstNo = string.Empty;
            this.ProjectCostCentre = string.Empty;
            this.PMApprove = default(bool);
            this.PMRemark = string.Empty;
            this.CMFApprove = default(bool);
            this.CMFRemark = string.Empty;
            this.IsClerance = default(bool);
            this.IsReceivedClearance = default(bool);
            this.Stage = AssetRequestStage.None;
            this.CreatedOn = default(DateTime?);

            this.CreatedBY = string.Empty;
            this.PMApprovedOn = default(DateTime?);
            this.PMApprovedBy = string.Empty;

            this.CMFApprovedOn = default(DateTime?);
            this.CMFApprovedBy = string.Empty;

            this.ClearanceOn = default(DateTime?);
            this.ClearanceBy = string.Empty;
            this.ReceivedBy = string.Empty;
            this.ReceivedOn = default(DateTime?);
            this.ReceivedClearanceOn = default(DateTime?);
            this.ReceivedClearanceBy = string.Empty;
            this.AssetCode = string.Empty;
            

        }

        public string RequestId { get; set; }
        public List<AssetDetails> AssetDetails { get; set; }
        public List<UploadDocument> Documents { get; set; }


        public StorageLocation LocationDetails { get; set; }
        public string LocationCode { get; set; }
        public bool IsPermanent { get; set; }
        public string TransferTo { get; set; }
        public bool IsInterUnit { get; set; }
        public string LocationTo { get; set; }
        public string ProjectCode { get; set; }
        public string ReceiverEmail { get; set; }
        public string GstNo { get; set; }
        public string ProjectCostCentre { get; set; }
        public bool PMApprove { get; set; }
        public string PMRemark { get; set; }
        public bool CMFApprove { get; set; }
        public string CMFRemark { get; set; }
        public bool IsClerance { get; set; }
        public bool IsReceivedClearance { get; set; }

        public AssetRequestStage Stage { get; set; }

        public DateTime? CreatedOn { get; set; }
        public string CreatedBY { get; set; }
        public DateTime? PMApprovedOn { get; set; }
        public string PMApprovedBy { get; set; }

        public DateTime? CMFApprovedOn { get; set; }
        public string CMFApprovedBy { get; set; }

        public DateTime? ClearanceOn { get; set; }
        public string ClearanceBy { get; set; }

        public DateTime? ReceivedOn { get; set; }
        public string ReceivedBy { get; set; }

        public DateTime? ReceivedClearanceOn { get; set; }
        public string ReceivedClearanceBy { get; set; }

        public bool MailStatus { get; set; }

        public string AssetCode { get; set; }

        
    }

    public class AssetSearchCriteria
    {
        public string RequestId { get; set; }
        public string LocationCode { get; set; }
        public AssetRequestStage RequestStage { get; set; }
        public UploadDocType DocumentType { get; set; }
    }

    public class AssetRequestMailSearchCriteria
    {
        public bool MailStatus { get; set; }

        public AssetRequestStage Stage { get; set; }

        public string RequestType { get; set; }

        public AssetRequestMailSearchCriteria()
        {
            this.MailStatus = default(bool);
            this.Stage = AssetRequestStage.None;
            this.RequestType = string.Empty;
        }

    }


    

}