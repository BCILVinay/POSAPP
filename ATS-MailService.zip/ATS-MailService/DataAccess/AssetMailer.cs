﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataAccess
{
    public class AssetMailer : AssetRequest
    {
        public string AssetCode { get; set; }
        public bool ISRFIDEmailSend { get; set; }
        public long MoveTagId { get; set; }
        public string ReceiverCMFEmail { get; set; }
    }

    public class AssetRFIDMovement
    {
        public string RequestFromLocation { get; set; }
        public string RFIDTagMovementId { get; set; }
        public string AssetCode { get; set; }
        public string RequestToLocation { get; set; }
        public bool IsAuthrozeAssset { get; set; }
        public bool IsEmailSend { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public string RequestId { get; set; }
        public string ProjectName { get; set; }
        public string ProjectManagerEmail { get; set; }
        public string ProjectManagerName { get; set; }
        public string CMFEmail { get; set; }
        public string GSGEmail { get; set; }

        // added new feils on 23 NOV 

        public string AssetLocationName { get; set; }
        public string SerialCode { get; set; }
        public bool AssetAllocated { get; set; }
        public int ACQUISITION_ID { get; set; }

        public string AMC_WARRANTY { get; set; }

        public DateTime AMC_WARRANTY_END_DATE { get; set; }
        public DateTime AMC_WARRANTY_START_DATE { get; set; }
        public bool ASSET_ALLOCATED { get; set; }
        public bool ASSET_APPROVED { get; set; }
        public string ASSET_BOE { get; set; }

        public string ASSET_DESCRIPTION { get; set; }
        public string ASSET_ID { get; set; }
        public string ASSET_LOCATION { get; set; }
        public string ASSET_MAKE { get; set; }
        public string ASSET_TYPE { get; set; }


        public string BONDED_TYPE { get; set; }
        public string PROJECT_NAME { get; set; }
        public bool IsRFIDApproved { get; set; }
        public string CategoryCode { get; set; }
        public string CategoryName { get; set; }
        
        // Added new property for getting reader location  on 4 dec 2018
        public string ReaderLocationCode { get; set; }
        public string ReaderLocationName { get; set; }

        public string ReaderLocationCMF { get; set; }
        public string ReaderLocationGSG { get; set; }

        public AssetRequestStage RequestStage { get; set; }

        public string RequestToLocationName { get; set; }
      

        // ,T6.STORAGE_LOC_NAME 
        //,T2.SERIAL_CODE 
        //,T2.ASSET_ALLOCATED
        //,T2.ACQUISITION_ID, T2.AMC_WARRANTY, T2.AMC_WARRANTY_END_DATE, T2.AMC_WARRANTY_START_DATE
        //,T2.ASSET_ALLOCATED,T2.ASSET_APPROVED,T2.ASSET_BOE,T2.ASSET_DESCRIPTION,T2.ASSET_ID
        //,T2.ASSET_LOCATION ,T2.ASSET_MAKE, T2.ASSET_TYPE, T2.BONDED_TYPE,T2.PROJECT_NAME
        //,T2.IsRFIDApproved 

    }
}
