﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataAccess
{
    public class StorageLocation
    {
        public string LocationCode { get; set; }
        public string LocationName { get; set; }
        public string CMFEmail { get; set; }
        public string GSGEmail { get; set; }
        public StorageLocation()
        {
            this.LocationCode = string.Empty;
            this.LocationName = string.Empty;
            this.CMFEmail = string.Empty;
            this.GSGEmail = string.Empty;
        }
    }
}
