﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Net.Mail;
using MobiVUE_ATS.DAL;
using MobiVUE_ATS.PRP;
using System.Windows.Forms;

public partial class AssetReplacement : System.Web.UI.Page
{
    AssetReplacement_DAL oDAL;
    AssetReplacement_PRP oPRP;
    
    public AssetReplacement()
    {
        oPRP = new AssetReplacement_PRP();
    }
    ~AssetReplacement()
    {
        oPRP = null; oDAL = null;
    }

    #region PAGE EVENTS
    /// <summary>
    /// Navigates to session expired page in case of user logs off/session expired.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Init(object sender, EventArgs e)
    {
        if (Session["CURRENTUSER"] == null)
        {
            Server.Transfer("SessionExpired.aspx");
        }
        oDAL = new AssetReplacement_DAL(Session["DATABASE"].ToString());
        txtActiveInAssetCode.Focus();
    }

    /// <summary>
    /// Checking user group rights for Asset replacement operation.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                string _strRights = clsGeneral.GetRights("ASSET_REPLACEMENT", (DataTable)Session["UserRights"]);
                clsGeneral._strRights = _strRights.Split('^');
                clsGeneral.LogUserOperationToLogFile(Session["CURRENTUSER"].ToString(), Session["COMP_NAME"].ToString(), "ASSET_REPLACEMENT");
                if (clsGeneral._strRights[0] == "0")
                {
                    Response.Redirect("UnauthorizedUser.aspx", false);
                }
                HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                HttpContext.Current.Response.Cache.SetAllowResponseInBrowserHistory(false);
                if (Session["GROUP"].ToString().ToUpper() == "SYSADMIN")
                {
                    txtSecurityGEDate.Text = DateTime.Now.ToString("dd/MMM/yyyy");
                    txtSecurityGEDate.Enabled = true;
                }
                else
                {
                    txtSecurityGEDate.Text = DateTime.Now.ToString("dd/MMM/yyyy");
                    txtSecurityGEDate.Enabled = false;
                }
                GetAssetReplacementDetails(Session["COMPANY"].ToString());
            }
        }
        catch (Exception ex)
        {
            HandleExceptions(ex);
        }
    }
    #endregion

    #region PRIVATE FUNCTIONS
    /// <summary>
    /// Catch unhandled exceptions.
    /// </summary>
    /// <param name="ex"></param>
    public void HandleExceptions(Exception ex)
    {
        clsGeneral.LogErrorToLogFile(ex, "Asset Replacement");
        if (!ex.Message.ToString().Contains("Thread was being aborted."))
        {
            //oBL_ClsLog.SaveLog(Convert.ToString(Session["CURRENTUSER"]).Trim(), "Exception", ex.Message.ToString(), "GROUP MASTER");
            clsGeneral.ErrMsg = ex.Message.ToString(); try { string[] arrErr = ex.Message.ToString().Split('\n'); Session["ErrMsg"] = arrErr[0].ToString().Trim(); }
            catch { } Server.Transfer("Error.aspx");
        }
    }

    /// <summary>
    /// Populate Asset replacement details into gridview for viewing.
    /// </summary>
    private void GetAssetReplacementDetails(string CompCode)
    {
        gvAssetReplacement.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.GetAssetReplacementDetails(CompCode);
        gvAssetReplacement.DataSource = Session["REPLACEMENT"] = dt;
        gvAssetReplacement.DataBind();
    }

    /// <summary>
    /// Send e-mail to concerned person for asset approval after replacement .
    /// </summary>
    /// <param name="ActiveInAssetCode"></param>
    /// <param name="FaultyOutSerialCode"></param>
    /// <param name="SerialCode"></param>
    private void SendMailForApproval(string ActiveInAssetCode, string FaultyOutSerialCode, string SerialCode)
    {
        SmtpClient smtpClient = new SmtpClient();
        MailMessage message = new MailMessage();
        MailAddress fromAddress = new MailAddress(ConfigurationManager.AppSettings["SENDER"].ToString(), "ATS");
        smtpClient.Host = ConfigurationManager.AppSettings["SMTP_HOST"].ToString();
        smtpClient.Port = int.Parse(ConfigurationManager.AppSettings["SMTP_PORT"].ToString());
        message.From = fromAddress;
        message.To.Add(Session["EMAIL"].ToString());
        message.Subject = "WIPRO : RTS - Approval For Asset Replacement";
        message.IsBodyHtml = false;
        StringBuilder sbMsg = new StringBuilder();
        sbMsg.AppendLine("Please Note,");
        sbMsg.AppendLine("");
        sbMsg.AppendLine("An asset has been replaced with asset code as : " + ActiveInAssetCode + ".");
        sbMsg.AppendLine("");
        sbMsg.AppendLine("Asset faulty out serial no. : " + FaultyOutSerialCode + ".");
        sbMsg.AppendLine("");
        sbMsg.AppendLine("Asset active in serial no. : " + SerialCode + ".");
        sbMsg.AppendLine("");
        sbMsg.AppendLine("Kindly approve through the link given below.");
        sbMsg.AppendLine("");
        sbMsg.AppendLine("");
        sbMsg.AppendLine("");
        sbMsg.AppendLine("http://10.164.91.191/FIS_ATS/WebPages/UserLogin.aspx");
        message.Body = sbMsg.ToString();
        smtpClient.Send(message);
    }
    #endregion

    #region SUBMIT EVENT
    /// <summary>
    /// Save Asset replacement details.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (clsGeneral._strRights[1] == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            if (txtSecurityGEDate.Text.Trim() != "")
            {
                int iDate = clsGeneral.CompareDate(txtSecurityGEDate.Text.Trim(), DateTime.Now.ToString("dd/MMM/yyyy"));
                if (iDate > 0)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Please Note : Active in entry date cannot be later than current date!');", true);
                    txtSecurityGEDate.Focus();
                    return;
                }
            }
            oPRP.CompCode = Session["COMPANY"].ToString();
            oPRP.CreatedBy = Session["CURRENTUSER"].ToString();
            oPRP.ActiveInAssetCode = txtActiveInAssetCode.Text.Trim();
            oPRP.SerialCode = txtSerialCode.Text.Trim();
            oPRP.ActiveSecurityGENo = txtSecurityGENo.Text.Trim();
            oPRP.ActiveSecurityGEDate = txtSecurityGEDate.Text.Trim();
            oPRP.FaultySecurityGENo = txtFaultySecGENo.Text.Trim();
            oPRP.FaultySecurityGEDate = txtFaultySecGEDate.Text.Trim();
            oPRP.FaultyOutSerialCode = txtFaultyOutSerialCode.Text.Trim();
            oPRP.BondedType = rdoCB.Checked ? "CBD" : "NCBD";
            oPRP.AssetMake = txtAssetMake.Text.Trim();
            oPRP.AssetModel = txtAssetModel.Text.Trim();
            oPRP.ReplaceRemarks = txtRemarks.Text.Trim().Replace("'", "`");
            
            bool bChk = false;
            if (oPRP.SerialCode != "")
                bChk = oDAL.ChkActiveSerialNoExists(oPRP.SerialCode, Session["COMPANY"].ToString());
            if (bChk)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Active Serial No. already exists in asset acquisition.');", true);
                return;
            }
            if (oPRP.FaultyOutSerialCode != "")
                bChk = oDAL.ChkFaultySerialNoExists(oPRP.FaultyOutSerialCode, Session["COMPANY"].ToString());
            if (bChk)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Faulty Serial No. already has been replaced.');", true);
                return;
            }
            bool bResp = oDAL.SaveUpdateAssetReplacementDetails(oPRP);
            if (!bResp)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Asset Replacement details not saved.');", true);
                return;
            }
            else
            {
                //try
                //{ SendMailForApproval(oPRP.ActiveInAssetCode, oPRP.FaultyOutSerialCode, oPRP.SerialCode); }
                //catch (Exception ex) { }
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ClearFields", "ClearFields();", true);
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Asset Replacement details saved successfully. Replaced assets need to be approved.');", true);
            }
            GetAssetReplacementDetails(Session["COMPANY"].ToString());
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Get asset serial no./model name/asset make based on asset code entered.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnGo_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtActiveInAssetCode.Text.Trim() != "")
            {
                DataTable dt = new DataTable();
                dt = oDAL.GetAssetDetails(txtActiveInAssetCode.Text.Trim(), Session["COMPANY"].ToString());
                if (dt.Rows.Count > 0)
                {
                    txtFaultyOutSerialCode.Text = dt.Rows[0]["SERIAL_CODE"].ToString();
                    txtAssetModel.Text = dt.Rows[0]["MODEL_NAME"].ToString();
                    txtAssetMake.Text = dt.Rows[0]["ASSET_MAKE"].ToString();
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Asset not found / Asset not approved.');", true);
                }
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Export asset replacement history into excel file.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnExport_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            if (clsGeneral._strRights[4] == "0")
            {
                Response.Redirect("UnauthorizedUser.aspx");
            }
            if (gvAssetReplacement.Rows.Count > 0)
            {
                Response.Clear();
                DataTable dt = (DataTable)Session["REPLACEMENT"];
                DataSet dsExport = new DataSet();
                System.IO.StringWriter tw = new System.IO.StringWriter();
                System.Web.UI.HtmlTextWriter hw = new System.Web.UI.HtmlTextWriter(tw);
                System.Web.UI.WebControls.DataGrid dgGrid = new System.Web.UI.WebControls.DataGrid();
                dgGrid.DataSource = dt;
                dgGrid.HeaderStyle.Font.Bold = true;
                dgGrid.DataBind();
                dgGrid.RenderControl(hw);
                Response.ContentType = "application/vnd.ms-excel";
                Response.AddHeader("Content-Disposition", "attachment;filename=AssetReplacement.xls");
                this.EnableViewState = false;
                Response.Write(tw.ToString());
                Response.End();
            }
            else
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('There is no data to export.');", true);
                return;
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    #endregion

    #region GRIDVIEW EVENTS
    /// <summary>
    /// Asset replacement details gridview page index changing event.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvAssetReplacement_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvAssetReplacement.PageIndex = e.NewPageIndex;
            GetAssetReplacementDetails(Session["COMPANY"].ToString());
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    #endregion
}