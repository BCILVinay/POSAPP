﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MobiVUE_ATS.DAL;
using MobiVUE_ATS.PRP;

public partial class CityMaster : System.Web.UI.Page
{
    CityMaster_DAL oDAL;
    CityMaster_PRP oPRP;
    public CityMaster()
    {
        oPRP = new CityMaster_PRP();
    }
    ~CityMaster()
    {
        oDAL = null; oPRP = null;
    }

    #region PAGE EVENTS
    /// <summary>
    /// Navigates to session expired page in case of user logs off/session expired.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Init(object sender, EventArgs e)
    {
        if (Session["CURRENTUSER"] == null)
        {
            Server.Transfer("SessionExpired.aspx");
        }
        oDAL = new CityMaster_DAL(Session["DATABASE"].ToString());
    }

    /// <summary>
    /// Checking user group rights for company master details 
    /// save/edit/update/delete operations.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                HttpContext.Current.Response.Cache.SetAllowResponseInBrowserHistory(false);
                string _strRights = clsGeneral.GetRights("COMPANY_MASTER", (DataTable)Session["USERRIGHTS"]);
                clsGeneral._strRights = _strRights.Split('^');
                clsGeneral.LogUserOperationToLogFile(Session["CURRENTUSER"].ToString(), Session["COMP_NAME"].ToString(), "COMPANY_MASTER");
                if (clsGeneral._strRights[0] == "0")
                {
                    Response.Redirect("UnauthorizedUser.aspx");
                }
                PopulateCountry();
                GetCityDetails();
                txtCityCode.Focus();
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    #endregion

    #region PRIVATE FUNCTIONS
    /// <summary>
    /// Catch unhandled exceptions.
    /// </summary>
    /// <param name="ex"></param>
    public void HandleExceptions(Exception ex)
    {
        clsGeneral.LogErrorToLogFile(ex, "Country Master");
        if (!ex.Message.ToString().Contains("Thread was being aborted."))
        {
            clsGeneral.ErrMsg = ex.Message.ToString(); try { string[] arrErr = ex.Message.ToString().Split('\n'); Session["ErrMsg"] = arrErr[0].ToString().Trim(); }
            catch { } Response.Redirect("Error.aspx", false);
        }
    }

    /// <summary>
    /// Populate city details into gridview for viewing.
    /// </summary>
    private void GetCityDetails()
    {
        DataTable dt = new DataTable();
        dt = oDAL.GetCityDetails();
        gvCity.DataSource = dt;
        gvCity.DataBind();
    }

    /// <summary>
    /// Populate city details into gridview for viewing.
    /// </summary>
    private void PopulateCountry()
    {
        DataTable dt = new DataTable();
        dt = oDAL.GetCountry();
        ddlCountryCode.DataSource = dt;
        ddlCountryCode.DataTextField = "COUNTRY_NAME";
        ddlCountryCode.DataValueField = "COUNTRY_CODE";
        ddlCountryCode.DataBind();
        ddlCountryCode.Items.Insert(0, "-- Select Country --");
    }
    #endregion

    #region GRIDVIEW EVENTS
    /// <summary>
    /// Company details deleting event.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvCityMaster_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            if (clsGeneral._strRights[3] == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            GridViewRow gvRow = (GridViewRow)gvCity.Rows[e.RowIndex];
            oPRP.CityCode = ((Label)gvRow.FindControl("lblCityCode")).Text.Trim();
            //oPRP.CountryCode = ((DropDownList)(gvRow.FindControl("ddlECountryCode"))).SelectedValue.ToString();
            bool DelRslt = oDAL.DeleteCity(oPRP.CityCode);
            if (DelRslt)
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Entire details of the city deleted successfully.');", true);
            GetCityDetails();
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Company details editing event.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvCityMaster_RowEditing(object sender, GridViewEditEventArgs e)
    {
        try
        {
            if (clsGeneral._strRights[2] == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            GridViewRow gvRow = (GridViewRow)gvCity.Rows[e.NewEditIndex];
            ViewState["COUNTRY"] = ((Label)gvRow.FindControl("lblCountryCode")).Text.Trim();
            gvCity.EditIndex = e.NewEditIndex;
            GetCityDetails();
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvCityMaster_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DropDownList ddlECountryCode = (DropDownList)e.Row.FindControl("ddlECountryCode");
                if (ddlECountryCode != null)
                {
                    ddlECountryCode.DataSource = oDAL.GetCountry();
                    ddlECountryCode.DataTextField = "COUNTRY_NAME";
                    ddlECountryCode.DataValueField = "COUNTRY_CODE";
                    ddlECountryCode.DataBind();
                    ddlECountryCode.Items.Insert(0, "-- Select Country --");
                    if (ViewState["COUNTRY"].ToString() != "")
                        ddlECountryCode.SelectedIndex = ddlECountryCode.Items.IndexOf(ddlECountryCode.Items.FindByText(ViewState["COUNTRY"].ToString()));
                    else
                    {
                        ddlECountryCode.SelectedIndex = ddlECountryCode.Items.IndexOf(ddlECountryCode.Items.FindByText("-- Select Country --"));
                    }
                }



                ImageButton imagebuttonEdit = (ImageButton)e.Row.FindControl("imagebuttonEdit");
                ImageButton imagebuttonDelete = (ImageButton)e.Row.FindControl("imagebuttonDelete");
                if (imagebuttonEdit != null)
                {
                    if (clsGeneral._strRights[2] == "0")
                        imagebuttonEdit.Enabled = false;
                    else
                        imagebuttonEdit.Enabled = true;
                }
                if (imagebuttonDelete != null)
                {
                    if (clsGeneral._strRights[3] == "0")
                        imagebuttonDelete.Enabled = false;
                    else
                        imagebuttonDelete.Enabled = true;
                }
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Company details updating event.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvCityMaster_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            if (clsGeneral._strRights[2] == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            GridViewRow gvRow = (GridViewRow)gvCity.Rows[e.RowIndex];
            oPRP.CountryCode = ((DropDownList)(gvRow.FindControl("ddlECountryCode"))).SelectedValue.ToString();           
            oPRP.CityCode = ((Label)gvRow.FindControl("lblEditCityCode")).Text.Trim(); 
            oPRP.CityName = ((Label)gvRow.FindControl("lblEditCityName")).Text.Trim();            
            oPRP.Remarks = ((TextBox)gvRow.FindControl("txtERemarks")).Text.Trim();
            oPRP.Active = ((CheckBox)gvRow.FindControl("chkEditActive")).Checked;
            oPRP.ModifiedBy = Session["CURRENTUSER"].ToString();
            oDAL.UpdateCity(oPRP);

            gvCity.EditIndex = -1;
            GetCityDetails();
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Company details edit/update cancelling event.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvCityMaster_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        try
        {
            gvCity.EditIndex = -1;
            GetCityDetails();
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Company master gridview page index changing event.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvCityMaster_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvCity.PageIndex = e.NewPageIndex;
            GetCityDetails();
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    #endregion

    #region SUBMIT EVENT
    /// <summary>
    /// Save new company details.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (clsGeneral._strRights[1] == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            oPRP.CityCode = txtCityCode.Text.Trim();
            oPRP.CityName = txtCityName.Text.Trim();
            if (ddlCountryCode.SelectedIndex != 0)
                oPRP.CountryCode = ddlCountryCode.SelectedValue.ToString();
            oPRP.Remarks = txtRemarks.Text.Trim().Replace("'", "`");
            oPRP.Active = chkSetStatus.Checked;
            oPRP.CreatedBy = Session["CURRENTUSER"].ToString();
            bool bResp = oDAL.SaveCity(oPRP);
            if (!bResp)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('City already exist !');", true);
                txtCityCode.Focus();
            }
            else
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ClearFields", "ClearFields();", true);
                upSubmit.Update();
            }
            GetCityDetails();
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    #endregion
}