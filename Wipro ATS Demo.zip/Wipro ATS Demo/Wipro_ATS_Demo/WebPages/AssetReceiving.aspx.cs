﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WebPages_AssetReceiving : System.Web.UI.Page
{

    private bool IsViewRight
    {
        get
        {
            return ViewState["IsViewRight"] == null ? false : (bool)ViewState["IsViewRight"];
        }
        set
        {
            ViewState["IsViewRight"] = value;
        }
    }
    private bool IsSaveRight
    {
        get
        {
            return ViewState["IsSaveRight"] == null ? false : (bool)ViewState["IsSaveRight"];
        }
        set
        {
            ViewState["IsSaveRight"] = value;
        }
    }
    private bool IsEditRight
    {
        get
        {
            return ViewState["IsEditRight"] == null ? false : (bool)ViewState["IsEditRight"];
        }
        set
        {
            ViewState["IsEditRight"] = value;
        }
    }
    private bool IsDeleteRight
    {

        get
        {
            return ViewState["IsDeleteRight"] == null ? false : (bool)ViewState["IsDeleteRight"];
        }
        set
        {
            ViewState["IsDeleteRight"] = value;
        }

    }
    private bool IsExportRight
    {
        get
        {
            return ViewState["IsExportRight"] == null ? false : (bool)ViewState["IsExportRight"];
        }
        set
        {
            ViewState["IsExportRight"] = value;
        }
    }

    AssetRquestDAL _assetRquestDAL = null;
    string strFilePath = string.Empty;
    private string LoggedInUser
    {
        get
        {
            return Session["CURRENTUSER"] == null ? string.Empty : Convert.ToString(Session["CURRENTUSER"]);
        }

    }
    private string LoggedInLocation
    {
        get
        {
            return Session["CurrentLocation"] == null ? string.Empty : Convert.ToString(Session["CurrentLocation"]);
        }
    }

    public string CurrentDBName
    {
        get
        {
            return Session["DATABASE"] == null ? string.Empty : Convert.ToString(Session["DATABASE"]);
        }
    }

    private AssetRequest AssetReceiveingRequest
    {
        get
        {
            return ViewState["AssetRequest"] == null ? null : (AssetRequest)ViewState["AssetRequest"];
        }
        set
        {
            ViewState["AssetRequest"] = value;
        }
    }



    private void SetPageRights()
    {
        try
        {
            string _strRights = clsGeneral.GetRights("MOVEMENT_RECEIVING", (DataTable)Session["UserRights"]);
            clsGeneral._strRights = _strRights.Split('^');
            this.IsViewRight = clsGeneral._strRights[0] == "0" ? false : true;
            this.IsSaveRight = clsGeneral._strRights[1] == "0" ? false : true;
            this.IsEditRight = clsGeneral._strRights[2] == "0" ? false : true;
            this.IsDeleteRight = clsGeneral._strRights[3] == "0" ? false : true;
            this.IsExportRight = clsGeneral._strRights[4] == "0" ? false : true;

            clsGeneral.LogUserOperationToLogFile(Session["CURRENTUSER"].ToString(), Session["COMP_NAME"].ToString(), "ASSET_ALLOCATION");
            if (!this.IsViewRight)
            {
                Response.Redirect("UnauthorizedUser.aspx", false);
                return;
            }
        }
        catch (Exception)
        {

            throw;
        }
    }

    protected void Page_Init(object sender, EventArgs e)
    {
        if (Session["CURRENTUSER"] == null)
        {
            Server.Transfer("SessionExpired.aspx");
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {

            //try
            //{
            //    string _strRights = clsGeneral.GetRights("ASSET_RECEIVING", (DataTable)Session["UserRights"]);
            //    clsGeneral._strRights = _strRights.Split('^');

            //    this.IsViewRight = clsGeneral._strRights[0] == "0" ? false : true;
            //    this.IsSaveRight = clsGeneral._strRights[1] == "0" ? false : true;
            //    this.IsEditRight = clsGeneral._strRights[2] == "0" ? false : true;
            //    this.IsDeleteRight = clsGeneral._strRights[3] == "0" ? false : true;
            //    this.IsExportRight = clsGeneral._strRights[4] == "0" ? false : true;

            //    clsGeneral.LogUserOperationToLogFile(Session["CURRENTUSER"].ToString(), Session["COMP_NAME"].ToString(), "ASSET_ALLOCATION");
            //    if (!this.IsViewRight)
            //    {
            //        Response.Redirect("UnauthorizedUser.aspx", false);
            //        return;
            //    }

            //}
            //catch (Exception ex)
            //{
            //    Response.Redirect("UnauthorizedUser.aspx", false);
            //}

            if (!Page.IsPostBack)
            {
                HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                HttpContext.Current.Response.Cache.SetAllowResponseInBrowserHistory(false);
                SetPageRights();
                Session["UploadDocument"] = null;

            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('" + ex.Message + "');", true);
            HandleExceptions(ex);

        }
    }


    protected void btnSearchRequest_Click(object sender, EventArgs e)
    {
        try
        {
            if (ddlAssetRequest.SelectedIndex > 0)
            {

                _assetRquestDAL = new AssetRquestDAL(this.CurrentDBName);

                var criteria = new AssetSearchCriteria()
                {
                    RequestId = ddlAssetRequest.SelectedValue,
                    DocumentType = UploadDocType.CLRREQ,
                    LocationCode = this.LoggedInLocation,
                    RequestStage = AssetRequestStage.ClearanceApproved
                };

                var _request = _assetRquestDAL.GetReceivingRequest(criteria);

                this.AssetReceiveingRequest = _request;

                lblStatus.Text = _request.Stage.ToString();
                lblRequestType.Text = _request.IsPermanent == true ? "Permanent-" + (_request.IsInterUnit ? " InterUnit" : " Wipro To Other") : "Temporary - " + _request.TransferTo;
                lblRequestedDate.Text = _request.CreatedOn == null ? string.Empty : ((DateTime)_request.CreatedOn).ToString("dd-MMM-yyyy");
                lblRequestedBy.Text = _request.CreatedBY.ToUpper();
                lblRequestedLocation.Text = _request.RequestedLocName;
                lblGSTNO.Text = _request.IsPermanent ? _request.RequestedToLocName : _request.RequestedToLocName;
                AssetDetailGrid.DataSource = _request.AssetDetails;
                AssetDetailGrid.DataBind();
                ReuestDetails.Style.Remove("display");

            }
            else
            {
                AssetDetailGrid.DataSource = null;
                AssetDetailGrid.DataBind();
                ReuestDetails.Style.Add("display", "none");
                lblErrorMsg.Text = "Please Select Request !!!";
            }
        }

        catch (Exception ex)
        {

            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('" + ex.Message + "');", true);
            HandleExceptions(ex);
        }
    }

    protected void btnViewUploadDocument_Click(object sender, EventArgs e)
    {
        try
        {
           
            if (this.AssetReceiveingRequest != null && (this.AssetReceiveingRequest.Documents != null && this.AssetReceiveingRequest.Documents.Count > 0))
            {
                ViewDocumentGrid.DataSource = this.AssetReceiveingRequest.Documents;
                ViewDocumentGrid.DataBind();
            }
        }
        catch (Exception ex)
        {

            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('" + ex.Message + "');", true);
            HandleExceptions(ex);
        }
    }




    private void BindPermanentRequest()
    {
        try
        {
            AssetRequestStage _stage = AssetRequestStage.ClearanceApproved;
            _assetRquestDAL = new AssetRquestDAL(this.CurrentDBName);
            List<string> _requests = _assetRquestDAL.GetReceiveingRequest(this.LoggedInLocation, _stage);
            ddlAssetRequest.DataSource = null;
            ddlAssetRequest.DataSource = _requests;
            ddlAssetRequest.DataBind();
            ddlAssetRequest.Items.Insert(0, new ListItem { Text = "SELECT", Value = "SELECT" });
        }
        catch (Exception)
        {

            throw;
        }
    }

    private void BindRGPRequest()
    {
        try
        {
            AssetRequestStage _stage = AssetRequestStage.ClearanceApproved;
            _assetRquestDAL = new AssetRquestDAL(this.CurrentDBName);
            List<string> _requests = _assetRquestDAL.GetRGPRequest(this.LoggedInLocation, _stage);
            ddlAssetRequest.DataSource = null;
            ddlAssetRequest.DataSource = _requests;
            ddlAssetRequest.DataBind();
            ddlAssetRequest.Items.Insert(0, new ListItem { Text = "SELECT", Value = "SELECT" });
        }
        catch (Exception)
        {

            throw;
        }
    }





    private void HandleExceptions(Exception ex)
    {
        clsGeneral.LogErrorToLogFile(ex, "Movement Request Received.");
        if (!ex.Message.ToString().Contains("Thread was being aborted."))
        {
            clsGeneral.ErrMsg = ex.Message.ToString(); try { string[] arrErr = ex.Message.ToString().Split('\n'); Session["ErrMsg"] = arrErr[0].ToString().Trim(); }
            catch { } Response.Redirect("Error.aspx");
        }
    }
    protected void btnReceived_Click(object sender, EventArgs e)
    {
        try
        {
            if (!this.IsSaveRight)
            {
               ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            if (this.AssetReceiveingRequest != null)
            {
                _assetRquestDAL = new AssetRquestDAL(this.CurrentDBName);
                this.AssetReceiveingRequest.Stage = AssetRequestStage.Received;
                this.AssetReceiveingRequest.ReceivedBy = this.LoggedInUser;
                this.AssetReceiveingRequest.ReceivedOn = DateTime.Now;
                this.AssetReceiveingRequest.IsReceived = true;
                if (Session["UploadDocument"] != null)
                {
                    this.AssetReceiveingRequest.Documents = (List<UploadDocument>)Session["UploadDocument"];
                }
                var _affectedRecord = _assetRquestDAL.ReceivedAssetRequest(this.AssetReceiveingRequest);
               
                //try
                //{
                //    _assetRquestDAL.SendMailOnReceivedAsset(this.AssetReceiveingRequest.RequestId);
                //}
                //catch (Exception){}
                

                if (_affectedRecord > 0)
                {
                    lblErrorMsg.Text = "Request Received Successfully";
                    RefreshForm();
                    BindPermanentRequest();
                }
            }
            else
            {
                lblErrorMsg.Text = "Please Select Request !!! ";
            }
        }
        catch (Exception ex)
        {

            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('" + ex.Message + "');", true);
            HandleExceptions(ex);
        }
    }


    private void RefreshForm()
    {
        ddlAssetRequest.DataSource = null;
        ddlAssetRequest.DataBind();
        ddlAssetRequest.Items.Clear();
        //  txtRemark.Text = string.Empty;
        // lblLocationTo.Text = string.Empty;
        lblRequestedBy.Text = string.Empty;
        lblRequestedDate.Text = string.Empty;
        lblRequestedLocation.Text = string.Empty;
        lblRequestType.Text = string.Empty;
        lblStatus.Text = string.Empty;
        lblGSTNO.Text = string.Empty;
        this.AssetReceiveingRequest = null;
        // Session["UploadDocument"] = null;
        //   UploadedDocumentGrid.DataSource = null;
        //  UploadedDocumentGrid.DataBind();
        AssetDetailGrid.DataSource = null;
        AssetDetailGrid.DataBind();
        ReuestDetails.Style.Add("display", "none");

        Session["UploadDocument"] = null;
        UploadedDocumentGrid.DataSource = null;
        UploadedDocumentGrid.DataBind();
        ViewDocumentGrid.DataSource = null;
        ViewDocumentGrid.DataBind();
    }
    protected void rdoPermanent_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            if (rdoPermanent.Checked)
            {
                RefreshForm();
                BindPermanentRequest();
            }
        }
        catch (Exception ex)
        {

            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('" + ex.Message + "');", true);
            HandleExceptions(ex);
        }
    }
    protected void rdoRPG_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            if (rdoRPG.Checked)
            {
                RefreshForm();
                BindRGPRequest();
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('" + ex.Message + "');", true);
            HandleExceptions(ex);
        }
    }


    #region Upload Docuent Code

    protected void btnDocumentUpload_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            if (!this.IsSaveRight)
            {
               ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            List<UploadDocument> UploadFiles = new List<UploadDocument>();
            List<string> ValidFile = new List<string>();

            var files = Request.Files;
            if (files.Count > 0)
            {

                for (int i = 0; i < files.Count; i++)
                {
                    HttpPostedFile userPostedFile = files[i];
                    var fileExt = System.IO.Path.GetExtension(userPostedFile.FileName);
                    if (!string.IsNullOrEmpty(userPostedFile.FileName))
                    {

                        if (fileExt.ToLower() != ".xls".ToLower() && fileExt.ToLower() != ".XLS".ToLower() && fileExt.ToLower() != ".xlsx".ToLower())
                        {
                            var ext = Path.GetExtension(userPostedFile.FileName);
                            var fileNameWithoutExt = Path.GetFileName(userPostedFile.FileName).Replace(ext, "").Trim();
                            strFilePath = Request.PhysicalApplicationPath + "UploadedFiles\\TempDocument\\" + fileNameWithoutExt + DateTime.Now.ToString("yyyyMMddHHmmss") + ext;


                            if (File.Exists(strFilePath))
                            {
                                File.Delete(strFilePath);
                            }

                            AssetDocumentUpload.SaveAs(strFilePath);
                            UploadFiles.Add(new UploadDocument { FileName = userPostedFile.FileName, UploadFilePath = strFilePath, DocumentType = UploadDocType.REC, IsValid = "YES" , Remark =txtUploadRemarks.Text });
                        }
                        //else
                        //{
                        //    UploadFiles.Add(new UploadDocument { FileName = userPostedFile.FileName, IsValid = "NO" });
                        //}
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('Please Seelct File !!!');", true);
                    }
                }
                if (UploadFiles.Count > 0)
                {
                    if (Session["UploadDocument"] != null)
                    {
                        var FilesUploaded = Session["UploadDocument"] as List<UploadDocument>;
                        UploadFiles.AddRange(FilesUploaded);
                    }
                    UploadedDocumentGrid.DataSource = UploadFiles;
                    UploadedDocumentGrid.DataBind();
                    Session["UploadDocument"] = UploadFiles;
                    dvUploadedDocumentGrid.Style.Add("display", "block ;");
                    txtUploadRemarks.Text = string.Empty;
                }

            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('" + ex.Message + "');", true);
            HandleExceptions(ex);
        }
    }

    protected void UploadedDocumentGrid_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        GridViewRow row = e.Row;
        if (row.RowType == DataControlRowType.DataRow)
        {
            Label lblIsValid = (Label)row.FindControl("lblIsValid");
            if (lblIsValid != null && lblIsValid.Text == "NO")
            {
                row.Style.Add("background-color", "#ff531a");
                row.Attributes.Add("tooltip", "Invalid File format");
            }
            else
            {
                row.Style.Add("background-color", "#59b300");
                row.Attributes.Add("tooltip", "Valid File format");
            }
        }
    }


    protected void ImgDelete_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            if (!this.IsDeleteRight)
            {
               ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            ImageButton btn = (ImageButton)sender;
            GridViewRow row = (GridViewRow)btn.NamingContainer;
            Label lblFileName = (Label)row.FindControl("lblFileName");
            if (Session["UploadDocument"] != null)
            {
                List<UploadDocument> documents = Session["UploadDocument"] as List<UploadDocument>;
                var tempfilePath = documents.FindAll(p => p.FileName.Equals(lblFileName.Text)).Select(S => S.UploadFilePath).ToList<string>();
                documents.RemoveAll(p => p.FileName.Equals(lblFileName.Text));
                RemoveTempUploadFile(tempfilePath);
                Session["UploadDocument"] = documents;
                UploadedDocumentGrid.DataSource = documents;
                UploadedDocumentGrid.DataBind();

                if (documents.Count == 0)
                {
                    dvUploadedDocumentGrid.Style.Add("display", "none;");
                }
                else
                {
                    dvUploadedDocumentGrid.Style.Add("display", "block ;");
                }
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('" + ex.Message + "');", true);
            HandleExceptions(ex);
        }
    }

    private void RemoveTempUploadFile(List<string> fileNames)
    {


        foreach (var fileName in fileNames)
        {
            try
            {
                if (File.Exists(fileName))
                {
                    File.Delete(fileName);
                }
            }
            catch (Exception)
            {

            }

        }


    }

    #endregion


    protected void ViewDocumentGrid_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            GridViewRow row = e.Row;
            if (row.RowType == DataControlRowType.DataRow)
            {
                Label lblFileName = (Label)row.FindControl("lblUploadFileName");
                if (lblFileName != null)
                {
                    var fileName = lblFileName.Text;
                    lblFileName.Text = lblFileName.Text.Split('_')[0] + Path.GetExtension(fileName);
                }
            }
        }
        catch (Exception)
        {


        }
    }
    protected void ImgDownload_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            if (!this.IsExportRight)
            {
               ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            ImageButton btn = (ImageButton)sender;
            GridViewRow row = (GridViewRow)btn.NamingContainer;
            Label lblDocumentId = (Label)row.FindControl("lblViewDocumentId");

            if (this.AssetReceiveingRequest != null && this.AssetReceiveingRequest.Documents != null && this.AssetReceiveingRequest.Documents.Count > 0)
            {
                List<UploadDocument> documents = ((AssetRequest)ViewState["AssetRequest"]).Documents;
                var tempfilePath = documents.Find(p => Convert.ToInt32(p.DocumentDetailId) == Convert.ToInt32(lblDocumentId.Text)).UploadDBFilePath;

                var _downloadFilePath = Server.MapPath("~/UploadedFiles/" + tempfilePath);

                if (File.Exists(_downloadFilePath))
                {
                    Response.Redirect("Download.aspx?FileName=" + _downloadFilePath, false);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('Uploaded document is removed !!!');", true);

                }

            }
        }
        catch (Exception ex)
        {


        }
    }



}