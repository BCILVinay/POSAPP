﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MobiVUE_ATS.DAL;
using MobiVUE_ATS.PRP;

public partial class AssetAllocation : System.Web.UI.Page
{
    string _CompCode = "";
    AssetAllocation_DAL oDAL;
    AssetAllocation_PRP oPRP;
    public AssetAllocation()
    {
        oPRP = new AssetAllocation_PRP();
    }
    ~AssetAllocation()
    {
        oDAL = null; oPRP = null;
    }

    #region PAGE EVENTS
    /// <summary>
    /// Navigates to session expired page in case of user logs off/session expired.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Init(object sender, EventArgs e)
    {
        if (Session["CURRENTUSER"] == null)
        {
            Server.Transfer("SessionExpired.aspx");
        }
        oDAL = new AssetAllocation_DAL(Session["DATABASE"].ToString());
        _CompCode = Session["COMPANY"].ToString();
    }

    /// <summary>
    /// Checking user group rights for add new asset allocation operation.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
          
            if (!IsPostBack)
            {
                HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                HttpContext.Current.Response.Cache.SetAllowResponseInBrowserHistory(false);
                string _strRights = clsGeneral.GetRights("ASSET_ALLOCATION", (DataTable)Session["UserRights"]);
                clsGeneral._strRights = _strRights.Split('^');
                clsGeneral.LogUserOperationToLogFile(Session["CURRENTUSER"].ToString(), Session["COMP_NAME"].ToString(), "ASSET_ALLOCATION");
                if (clsGeneral._strRights[0] == "0")
                {
                    Response.Redirect("UnauthorizedUser.aspx", false);
                }
                //ddlAllocRtrn.Attributes.Add("onChange", "onselectionChange();");
                PopulateEmployee();
                PopulateLocation();
                PopulateDepartment();
                ddlAssetType.SelectedValue = clsGeneral.gStrAssetType;
                lblAssetType.Text = clsGeneral.gStrAssetType;
                PopulateCategory(lblAssetType.Text.Trim());
                GetAssetAllocationDetails(Session["COMPANY"].ToString());
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    #endregion

    #region PRIVATE FUNCTIONS
    /// <summary>
    /// Catch unhandled exceptions.
    /// </summary>
    /// <param name="ex"></param>
    public void HandleExceptions(Exception ex)
    {
        clsGeneral.LogErrorToLogFile(ex, "Asset Allocation");
        if (!ex.Message.ToString().Contains("Thread was being aborted."))
        {
            //oBL_ClsLog.SaveLog(Convert.ToString(Session["CURRENTUSER"]).Trim(), "Exception", ex.Message.ToString(), "GROUP MASTER");
            clsGeneral.ErrMsg = ex.Message.ToString(); try { string[] arrErr = ex.Message.ToString().Split('\n'); Session["ErrMsg"] = arrErr[0].ToString().Trim(); }
            catch { } Server.Transfer("Error.aspx");
        }
    }

    /// <summary>
    /// Get employee code/name for being associated with assets.
    /// </summary>
    private void PopulateEmployee()
    {
        DataTable dt = new DataTable();
        dt = oDAL.GetEmployee(Session["COMPANY"].ToString());

        //ddlAllocatedTo.DataSource = null;
        //ddlAllocatedTo.DataSource = dt;
        //ddlAllocatedTo.DataValueField = "EMPLOYEE_CODE";
        //ddlAllocatedTo.DataTextField = "EMPLOYEE_NAME";
        //ddlAllocatedTo.DataBind();
        //ddlAllocatedTo.Items.Insert(0, "-- Select Employee --");

        ddlApprovedBy.DataSource = null;
        ddlApprovedBy.DataSource = dt;
        ddlApprovedBy.DataValueField = "EMPLOYEE_CODE";
        ddlApprovedBy.DataTextField = "EMPLOYEE_NAME";
        ddlApprovedBy.DataBind();
        ddlApprovedBy.Items.Insert(0, "-- Select Employee --");

        ddlRequestedBy.DataSource = null;
        ddlRequestedBy.DataSource = dt;
        ddlRequestedBy.DataValueField = "EMPLOYEE_CODE";
        ddlRequestedBy.DataTextField = "EMPLOYEE_NAME";
        ddlRequestedBy.DataBind();
        ddlRequestedBy.Items.Insert(0, "-- Select Employee --");
    }

    /// <summary>
    /// Get asset allocation details.
    /// </summary>
    private void GetAssetAllocationDetails(string CompCode)
    {
        gvAssetAllocation.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.GetAssetAllocationDetails(CompCode);
        gvAssetAllocation.DataSource = dt;
        gvAssetAllocation.DataBind();
    }

    /// <summary>
    /// Populate employee code/name into employee dropdownlist based on 
    /// department selected through department dropdownlist.
    /// </summary>
    /// <param name="_DeptCode"></param>
    private void PopulateProcessEmp(string ProcessCode,string CompCode)
    {
        ddlAllocatedTo.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.GetProcessEmployee(ProcessCode, CompCode);
        if (dt.Rows.Count > 0)
        {
            ddlAllocatedTo.DataSource = dt;
            ddlAllocatedTo.DataValueField = "EMPLOYEE_CODE";
            ddlAllocatedTo.DataTextField = "EMPLOYEE_NAME";
            ddlAllocatedTo.DataBind();
            ddlAllocatedTo.Items.Insert(0, "-- Select Employee --");
        }
        else
        {
            ddlAllocatedTo.DataSource = dt;
            ddlAllocatedTo.DataBind();
            txtAllocatedToId.Text = "";
        }
    }

    /// <summary>
    /// Populate department code/name into department dropdownlist.
    /// </summary>
    private void PopulateProcess(string DeptCode)
    {
        ddlFromProject.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.GetProject(DeptCode, Session["COMPANY"].ToString());
        ddlFromProject.DataSource = dt;
        ddlFromProject.DataValueField = "PROJECT_CODE";
        ddlFromProject.DataTextField = "PROJECT_NAME";
        ddlFromProject.DataBind();
        ddlFromProject.Items.Insert(0, "-- Select Project Name --");

        ddlToProject.DataSource = null;
        DataTable dt1 = new DataTable();
        dt = oDAL.GetProject(DeptCode, Session["COMPANY"].ToString());
        ddlToProject.DataSource = dt;
        ddlToProject.DataValueField = "PROJECT_CODE";
        ddlToProject.DataTextField = "PROJECT_NAME";
        ddlToProject.DataBind();
        ddlToProject.Items.Insert(0, "-- Select Project Name --");
    }

    /// <summary>
    /// Populate department code/name into department dropdownlist.
    /// </summary>
    private void PopulateDepartment()
    {
        ddlFromProject.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.GetDepartment(Session["COMPANY"].ToString());
        ddlFromDept.DataSource = dt;
        ddlFromDept.DataValueField = "DEPT_CODE";
        ddlFromDept.DataTextField = "DEPT_NAME";
        ddlFromDept.DataBind();
        ddlFromDept.Items.Insert(0, "-- Select Department --");

        ddlToProject.DataSource = null;
        DataTable dt1 = new DataTable();
        dt = oDAL.GetDepartment(Session["COMPANY"].ToString());
        ddlToDept.DataSource = dt;
        ddlToDept.DataValueField = "DEPT_CODE";
        ddlToDept.DataTextField = "DEPT_NAME";
        ddlToDept.DataBind();
        ddlToDept.Items.Insert(0, "-- Select Department --");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="DeptCode"></param>
    /// <param name="CompCode"></param>
    private void PopulateFromProcess(string DeptCode)
    {
        ddlFromProject.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.GetProject(DeptCode, Session["COMPANY"].ToString());
        ddlFromProject.DataSource = dt;
        ddlFromProject.DataValueField = "PROJECT_CODE";
        ddlFromProject.DataTextField = "PROJECT_NAME";
        ddlFromProject.DataBind();
        ddlFromProject.Items.Insert(0, "-- Select Project Name --");
    }

    private void PopulateToProcess(string DeptCode)
    {
        ddlToProject.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.GetProject(DeptCode, Session["COMPANY"].ToString());
        ddlToProject.DataSource = dt;
        ddlToProject.DataValueField = "PROJECT_CODE";
        ddlToProject.DataTextField = "PROJECT_NAME";
        ddlToProject.DataBind();
        ddlToProject.Items.Insert(0, "-- Select Project Name --");
    }

    /// <summary>
    /// Populate location code/name into location dropdownlist.
    /// </summary>
    private void PopulateLocation()
    {
        lblLocLevel.Text = "1";
        DataTable dt = new DataTable();
        dt = oDAL.GetLocation(_CompCode, Session["COMPLOCATION"].ToString(), "", 1);
        ddlAssetLocation.DataSource = null;
        ddlAssetLocation.DataSource = dt;
        ddlAssetLocation.DataTextField = "LOC_NAME";
        ddlAssetLocation.DataValueField = "LOC_CODE";
        ddlAssetLocation.DataBind();
        ddlAssetLocation.Items.Insert(0, "-- Select Location --");
    }

    /// <summary>
    /// Fetch category details to be populated in dropdownlist.
    /// </summary>
    private void PopulateCategory(string AssetType)
    {
        lblCatCode.Text = "0";
        lblCatLevel.Text = "1";
        ddlAssetCategory.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.PopulateCategory(AssetType.Trim(), "", 1);
        ddlAssetCategory.DataSource = dt;
        ddlAssetCategory.DataTextField = "CATEGORY_NAME";
        ddlAssetCategory.DataValueField = "CATEGORY_CODE";
        ddlAssetCategory.DataBind();
        ddlAssetCategory.Items.Insert(0, "-- Select Category --");
    }

    /// <summary>
    /// Get asset make based on category selected.
    /// </summary>
    private void PopulateAssetMake(string CategoryCode)
    {
        ddlAssetMake.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.PopulateAssetMake(CategoryCode, Session["COMPANY"].ToString());
        ddlAssetMake.DataSource = dt;
        ddlAssetMake.DataTextField = "ASSET_MAKE";
        ddlAssetMake.DataValueField = "ASSET_MAKE";
        ddlAssetMake.DataBind();
        ddlAssetMake.Items.Insert(0, "-- Select Make --");
    }

    /// <summary>
    /// Get asset model names based on asset make and category selected.
    /// </summary>
    /// <param name="AssetMake"></param>
    private void PopulateModelName(string AssetMake, string CategoryCode)
    {
        lstModelName.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.PopulateModelName(AssetMake, CategoryCode, Session["COMPANY"].ToString());
        lstModelName.DataSource = dt;
        lstModelName.DataTextField = "MODEL_NAME";
        lstModelName.DataValueField = "MODEL_NAME";
        lstModelName.DataBind();
        lstModelName.Items.Insert(0, "-- Select Model --");
    }

    /// <summary>
    /// Get assets for being returned which are already allocated.
    /// </summary>
    /// <param name="_AssetCode"></param>
    private void GetAssetDetails(string _AssetCode)
    {
        if (ddlAllocRtrn.SelectedValue.ToString() == "RETURN" && _AssetCode != "")
        {
            DataTable dt = new DataTable();
            //dt = oDAL.GetAssetToReturn(_AssetCode);
            if (dt.Rows.Count > 0)
            {
                txtReturnDate.Text = "";
                txtAllocatedDate.Text = dt.Rows[0]["ASSET_ALLOCATION_DATE"].ToString();

                if (dt.Rows[0]["EXPECTED_RTN_DATE"].ToString() != "")
                {
                    txtExpRtnDate.Text = dt.Rows[0]["EXPECTED_RTN_DATE"].ToString();
                }
                ddlFromProject.SelectedValue = dt.Rows[0]["ALLOCATED_PROCESS"].ToString();
            }
        }
    }

    /// <summary>
    /// Populate assets for being allocated based on filters selected.
    /// </summary>
    private void GetAssets()
    {
        if (ddlFromProject.SelectedIndex == 0)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Select Project Name.');", true);
            ddlFromProject.Focus();
            return;
        }
        oPRP.CompCode = Session["COMPANY"].ToString();
        oPRP.AssetCode = txtAssetCode.Text.Trim();
        oPRP.SerialCode = txtSerialCode.Text.Trim();
        if (ddlAssetType.SelectedIndex != 0)
            oPRP.AssetType = ddlAssetType.SelectedValue.ToString();
        else
            oPRP.AssetType = "";
        if (ddlAssetCategory.SelectedIndex != 0)
            oPRP.CategoryCode = ddlAssetCategory.SelectedValue.ToString();
        else
            oPRP.CategoryCode = "";
        if (ddlAssetMake.SelectedIndex != 0)
            oPRP.AssetMake = ddlAssetMake.SelectedValue.ToString();
        else
            oPRP.AssetMake = "";
        for (int iCnt = 0; iCnt < lstModelName.Items.Count; iCnt++)
        {
            if (lstModelName.Items[iCnt].Selected)
                oPRP.ModelName += lstModelName.Items[iCnt].Value.ToString() + ",";
        }
        if (oPRP.ModelName != null)
        {
            oPRP.ModelName = oPRP.ModelName.TrimEnd(',');
            oPRP.ModelName = oPRP.ModelName.Replace(",", "','");
            oPRP.ModelName = "'" + oPRP.ModelName + "'";
        }
        else
            oPRP.ModelName = "";
        if (ddlAllocRtrn.SelectedValue == "ALLOCATE")
        {
            lblAllocatedTo.Text = "";
            lblAllocatedToId.Text = "";
            oPRP.FromProcessCode = ddlFromProject.SelectedValue.ToString();
            oPRP.AssetAllocated = false;
            gvAssets.DataSource = null;
            DataTable dt = new DataTable();
            dt = oDAL.GetAssets(oPRP);
            if (dt.Rows.Count > 0)
            {
                gvAssets.DataSource = Session["Assets"] = dt;
                gvAssets.DataBind();
                lblAssetCount.Text = "Assets Count : " + dt.Rows.Count.ToString();
            }
            else
            {
                gvAssets.DataSource = null;
                gvAssets.DataBind();
                lblAssetCount.Text = "Assets Count : 0";
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Either assets not approved or not found as per given criteria.');", true);
                return;
            }
        }
        else if (ddlAllocRtrn.SelectedValue == "RETURN")
        {
            oPRP.AssetAllocated = true;
            //oPRP.AllocatedToId = txtAllocatedToId.Text.Trim();
            gvAssets.DataSource = null;
            oPRP.FromProcessCode = ddlFromProject.SelectedValue.ToString();
            DataTable dt = new DataTable();
            dt = oDAL.GetAssetToReturnReAllocate(oPRP);
            if (dt.Rows.Count > 0)
            {
                gvAssets.DataSource = Session["Assets"] = dt;
                gvAssets.DataBind();

                lblAllocatedTo.Text = dt.Rows[0]["ASSET_ALLOCATED_EMP"].ToString();
                lblAllocatedToId.Text = dt.Rows[0]["ALLOCATED_EMP_ID"].ToString();
                if (dt.Rows[0]["REQUESTED_BY_ID"].ToString() != "")
                {
                    ddlRequestedBy.SelectedValue = dt.Rows[0]["REQUESTED_BY_ID"].ToString();
                    txtRequestedById.Text = dt.Rows[0]["REQUESTED_BY_ID"].ToString();
                }
                if (dt.Rows[0]["APPROVED_BY_ID"].ToString() != "")
                {
                    ddlApprovedBy.SelectedValue = dt.Rows[0]["APPROVED_BY_ID"].ToString();
                    txtApprovedById.Text = dt.Rows[0]["APPROVED_BY_ID"].ToString();
                }
                txtTicketNo.Text = dt.Rows[0]["TICKET_NO"].ToString();
                txtGatePassNo.Text = dt.Rows[0]["GATEPASS_NO"].ToString();
                txtVlan.Text = dt.Rows[0]["VLAN"].ToString();
                if (dt.Rows[0]["EXPECTED_RTN_DATE"].ToString() != "")
                    txtExpRtnDate.Text = Convert.ToDateTime(dt.Rows[0]["EXPECTED_RTN_DATE"].ToString()).ToString("dd/MMM/yyyy");
                else
                    txtExpRtnDate.Text = "";
                txtAllocatedDate.Text = Convert.ToDateTime(dt.Rows[0]["ASSET_ALLOCATION_DATE"].ToString()).ToString("dd/MMM/yyyy");
                lblLocCode.Text = dt.Rows[0]["ASSET_LOCATION"].ToString();
                lblAssetCount.Text = "Assets Count : " + dt.Rows.Count.ToString();
            }
            else
            {
                gvAssets.DataSource = null;
                gvAssets.DataBind();
                lblAssetCount.Text = "Assets Count : 0";
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Either assets not approved or not found as per given criteria.');", true);
                return;
            }
        }
        else if (ddlAllocRtrn.SelectedValue == "REALLOCATE")
        {
            oPRP.AssetAllocated = true;
            //oPRP.AllocatedToId = txtAllocatedToId.Text.Trim();
            gvAssets.DataSource = null;
            oPRP.FromProcessCode = ddlFromProject.SelectedValue.ToString();
            DataTable dt = new DataTable();
            dt = oDAL.GetAssetToReturnReAllocate(oPRP);
            if (dt.Rows.Count > 0)
            {
                gvAssets.DataSource = Session["Assets"] = dt;
                gvAssets.DataBind();

                lblAllocatedTo.Text = dt.Rows[0]["ASSET_ALLOCATED_EMP"].ToString();
                lblAllocatedToId.Text = dt.Rows[0]["ALLOCATED_EMP_ID"].ToString();
                if (dt.Rows[0]["REQUESTED_BY_ID"].ToString() != "")
                {
                    ddlRequestedBy.SelectedValue = dt.Rows[0]["REQUESTED_BY_ID"].ToString();
                    txtRequestedById.Text = dt.Rows[0]["REQUESTED_BY_ID"].ToString();
                }
                if (dt.Rows[0]["APPROVED_BY_ID"].ToString() != "")
                {
                    ddlApprovedBy.SelectedValue = dt.Rows[0]["APPROVED_BY_ID"].ToString();
                    txtApprovedById.Text = dt.Rows[0]["APPROVED_BY_ID"].ToString();
                }
                txtTicketNo.Text = dt.Rows[0]["TICKET_NO"].ToString();
                txtGatePassNo.Text = dt.Rows[0]["GATEPASS_NO"].ToString();
                txtVlan.Text = dt.Rows[0]["VLAN"].ToString();
                if (dt.Rows[0]["EXPECTED_RTN_DATE"].ToString() != "")
                    txtExpRtnDate.Text = Convert.ToDateTime(dt.Rows[0]["EXPECTED_RTN_DATE"].ToString()).ToString("dd/MMM/yyyy");
                else
                    txtExpRtnDate.Text = "";
                txtAllocatedDate.Text = Convert.ToDateTime(dt.Rows[0]["ASSET_ALLOCATION_DATE"].ToString()).ToString("dd/MMM/yyyy");
                lblLocCode.Text = dt.Rows[0]["ASSET_LOCATION"].ToString();
                lblAssetCount.Text = "Assets Count : " + dt.Rows.Count.ToString();
            }
            else
            {
                gvAssets.DataSource = null;
                gvAssets.DataBind();
                lblAssetCount.Text = "Assets Count : 0";
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Either assets not approved or not found as per given criteria.');", true);
                return;
            }
        }
        else
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAllocTypeMsg", "ShowAllocTypeMsg();", true);
            return;
        }
    }
    #endregion

    #region BUTTON EVENTS
    /// <summary>
    /// Allocate/Return/Re-Allocate assets to processes/emlpoyees.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            bool bAssetSelected = false;
            string _LiveGPCode = "";
            if (clsGeneral._strRights[1] == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('You are not authorised to execute this operation.');", true);
                return;
            }
            if (lblLocCode.Text == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Location cannot be blank.');", true);
                return;
            }
            for (int iCnt = 0; iCnt < gvAssets.Rows.Count; iCnt++)
            {
                if (((CheckBox)gvAssets.Rows[iCnt].FindControl("chkSelectAsset")).Checked == true)
                {
                    bAssetSelected = true;
                    break;
                }
            }
            if (!bAssetSelected)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Click on Get Assets button to select assets.');", true);
                return;
            }
            foreach (GridViewRow gvRow in gvAssets.Rows)
            {
                if (ddlAllocRtrn.SelectedValue == "ALLOCATE")
                {
                    if (((CheckBox)gvRow.FindControl("chkSelectAsset")).Checked)
                    {
                        oPRP.AssetCode = ((Label)gvRow.FindControl("lblAssetCode")).Text.Trim();
                        _LiveGPCode = oDAL.ChkLiveGP(oPRP.AssetCode);
                        if (_LiveGPCode != "")
                        {
                            lblErrorMsg.Text = "Asset is already part of Gate Pass No: " + _LiveGPCode + " and is not returned yet.";
                            return;
                        }
                        oPRP.CompCode = Session["COMPANY"].ToString();
                        oPRP.CreatedBy = Session["CURRENTUSER"].ToString();
                        oPRP.AssetLocation = lblLocCode.Text.Trim();
                        oPRP.WorkStationNo = txtWorkStationNo.Text.Trim();
                        oPRP.AllocationDate = txtAllocatedDate.Text.Trim();
                        if (Convert.ToDateTime(oPRP.AllocationDate) > Convert.ToDateTime(DateTime.Now.ToString("dd/MMM/yyyy")))
                        {
                            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Allocated Date should not be greater than current date.');", true);
                            return;
                        }
                        oPRP.ExpReturnDate = (txtExpRtnDate.Text.Trim() != "") ? txtExpRtnDate.Text.Trim() : "01/Jan/1900";
                        if (txtExpRtnDate.Text.Trim() != "")
                        {
                            if (Convert.ToDateTime(oPRP.AllocationDate) > Convert.ToDateTime(oPRP.ExpReturnDate))
                            {
                                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Allocated Date should not be later than expected return date.');", true);
                                return;
                            }
                        }
                        oPRP.AssetAllocated = true;
                        oPRP.ToDeptCode = ddlToDept.SelectedValue.ToString();
                        oPRP.ToProcessCode = ddlToProject.SelectedValue.ToString();
                        oPRP.AllocatedTo = ddlAllocatedTo.SelectedItem.Text.Trim();
                        oPRP.AllocatedToId = txtAllocatedToId.Text.Trim();
                        if (ddlRequestedBy.SelectedIndex > 0)
                            oPRP.RequestedBy = ddlRequestedBy.SelectedItem.Text.Trim();
                        else
                            oPRP.RequestedBy = "";
                        oPRP.RequestedById = txtRequestedById.Text.Trim();
                        if (ddlApprovedBy.SelectedIndex > 0)
                            oPRP.ApprovedBy = ddlApprovedBy.SelectedItem.Text.Trim();
                        else
                            oPRP.ApprovedBy = "";
                        oPRP.ApprovedById = txtApprovedById.Text.Trim();
                        oPRP.PortNo = txtPortNo.Text.Trim();
                        oPRP.Vlan = txtVlan.Text.Trim();
                        oPRP.TicketNo = txtTicketNo.Text.Trim();
                        oPRP.GatePassNo = txtGatePassNo.Text.Trim();
                        oPRP.AllocationRemarks = txtRemarks.Text.Trim().Replace("'", "`");
                        bool bResp = oDAL.SaveAssetAllocation("ALLOCATE", oPRP);
                        if (bResp)
                            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('Selected Assets allocated successfully.');", true);
                    }
                }
                if (ddlAllocRtrn.SelectedValue == "RETURN")
                {
                    if (((CheckBox)gvRow.FindControl("chkSelectAsset")).Checked)
                    {
                        if (txtReturnDate.Text == "")
                        {
                            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Return date cannot be blank when asset is being returned back!');", true);
                            return;
                        }
                        if (ddlToProject.SelectedValue.ToString() != "STOCK")
                        {
                            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Asset must be returned back to STOCK process!');", true);
                            return;
                        }
                        else
                            oPRP.ToProcessCode = ddlToProject.SelectedValue.ToString();
                        oPRP.ToDeptCode = ddlToDept.SelectedValue.ToString();
                        oPRP.AssetCode = ((Label)gvRow.FindControl("lblAssetCode")).Text.Trim();
                        oPRP.CompCode = Session["COMPANY"].ToString();
                        oPRP.AssetLocation = lblLocCode.Text.Trim();
                        oPRP.WorkStationNo = txtWorkStationNo.Text.Trim();
                        oPRP.AllocationDate = (txtAllocatedDate.Text.Trim() != "") ? txtAllocatedDate.Text.Trim() : "01/Jan/1900";
                        oPRP.ExpReturnDate = (txtExpRtnDate.Text.Trim() != "") ? txtExpRtnDate.Text.Trim() : "01/Jan/1900";
                        oPRP.AssetAllocated = false;
                        //oPRP.AllocatedTo = ddlAllocatedTo.SelectedItem.Text.Trim();
                        //oPRP.AllocatedToId = txtAllocatedToId.Text.Trim();
                        if (ddlRequestedBy.SelectedIndex > 0)
                            oPRP.RequestedBy = ddlRequestedBy.SelectedItem.Text.Trim();
                        else
                            oPRP.RequestedBy = "";
                        oPRP.RequestedById = txtRequestedById.Text.Trim();
                        if (ddlApprovedBy.SelectedIndex > 0)
                            oPRP.ApprovedBy = ddlApprovedBy.SelectedItem.Text.Trim();
                        else
                            oPRP.ApprovedBy = "";
                        oPRP.ApprovedById = txtApprovedById.Text.Trim();
                        oPRP.ActualReturnDate = txtReturnDate.Text.Trim();
                        if (Convert.ToDateTime(oPRP.ActualReturnDate) > Convert.ToDateTime(DateTime.Now.ToString("dd/MMM/yyyy")))
                        {
                            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Return Date should not be later than current date.');", true);
                            return;
                        }
                        oPRP.ModifiedBy = Session["CURRENTUSER"].ToString();
                        bool bResp = oDAL.SaveAssetAllocation("RETURN", oPRP);
                        if (bResp)
                            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('Selected Assets returned successfully.');", true);
                    }
                }
                if (ddlAllocRtrn.SelectedValue == "REALLOCATE")
                {
                    if (((CheckBox)gvRow.FindControl("chkSelectAsset")).Checked)
                    {
                        oPRP.AssetAllocated = true;
                        oPRP.AssetCode = ((Label)gvRow.FindControl("lblAssetCode")).Text.Trim();
                        oPRP.CompCode = Session["COMPANY"].ToString();
                        oPRP.ToDeptCode = ddlToDept.SelectedValue.ToString();
                        oPRP.ToProcessCode = ddlToProject.SelectedValue.ToString();
                        oPRP.AssetLocation = lblLocCode.Text.Trim();
                        oPRP.WorkStationNo = txtWorkStationNo.Text.Trim();
                        oPRP.AllocationDate = txtAllocatedDate.Text.Trim();
                        oPRP.ExpReturnDate = (txtExpRtnDate.Text.Trim() != "") ? txtExpRtnDate.Text.Trim() : "01/Jan/1900";
                        oPRP.AllocatedTo = ddlAllocatedTo.SelectedItem.Text.Trim();
                        oPRP.AllocatedToId = txtAllocatedToId.Text.Trim();
                        if (ddlApprovedBy.SelectedIndex > 0)
                            oPRP.ApprovedBy = ddlApprovedBy.SelectedItem.Text.Trim();
                        else
                            oPRP.ApprovedBy = "";
                        oPRP.ApprovedById = txtApprovedById.Text.Trim();
                        if (ddlRequestedBy.SelectedIndex > 0)
                            oPRP.RequestedBy = ddlRequestedBy.SelectedItem.Text.Trim();
                        else
                            oPRP.RequestedBy = "";
                        oPRP.RequestedById = txtRequestedById.Text.Trim();
                        oPRP.ModifiedBy = Session["CURRENTUSER"].ToString();
                        bool bResp = oDAL.SaveAssetAllocation("REALLOCATE", oPRP);
                        if (bResp)
                            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('Selected Assets re-allocated successfully.');", true);
                    }
                }
            }
            GetAssetAllocationDetails(Session["COMPANY"].ToString());
            GetAssets();
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Reset/Clear fields and gets location dropdown refreshed.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnClear_Click(object sender, EventArgs e)
    {
        try
        {
            PopulateLocation();
            lblAllocatedTo.Text = "";
            lblAllocatedToId.Text = "";
            lblAssetCount.Text = "Assets Count : 0";
            DataTable dt = new DataTable();
            
            gvAssets.DataSource = null;
            gvAssets.DataBind();
            PopulateCategory(lblAssetType.Text);
            ddlAssetMake.DataSource = dt;
            ddlAssetMake.DataBind();
            
            lstModelName.DataSource = dt;
            lstModelName.DataBind();
            dt = null;
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Refresh the category level to top (level 1).
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnRefreshCategory_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            PopulateCategory(lblAssetType.Text);
            DataTable dt = new DataTable();
            ddlAssetMake.DataSource = dt;
            ddlAssetMake.DataBind();
            lstModelName.DataSource = dt;
            lstModelName.DataBind();
            dt = null;
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Search assets based on serial code value entered.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            GetAssets();
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Refresh/reset location details.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnRefreshLocation_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            PopulateLocation();
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Get asset details based on asset code entered.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnGo_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            if (txtAssetCode.Text.Trim() != "")
            {
                DataTable dt = new DataTable();
                dt = oDAL.GetAssetDetails(txtAssetCode.Text.Trim());
                if (dt.Rows.Count > 0)
                    txtSerialCode.Text = dt.Rows[0]["SERIAL_CODE"].ToString();
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    #endregion

    #region SELECTEDINDEXCHANGED EVENTS
    /// <summary>
    /// Allocation type selected index changed event.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlAllocRtrn_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlAllocRtrn.SelectedIndex > 0)
            {
                if (ddlAllocRtrn.SelectedValue.ToString() == "RETURN")
                {
                    txtReturnDate.Enabled = true;
                    txtReturnDate.Text = "";
                }
                else if (ddlAllocRtrn.SelectedValue.ToString() == "ALLOCATE")
                {
                    txtReturnDate.Enabled = false;
                    txtReturnDate.Text = "";
                }
                else if (ddlAllocRtrn.SelectedValue.ToString() == "REALLOCATE")
                {
                    txtReturnDate.Enabled = false;
                    txtReturnDate.Text = "";
                }
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Fetch list of categories based on asset type selected.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlAssetType_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlAssetType.SelectedIndex != 0)
            {
                DataTable dtNull = new DataTable();
                ddlAssetCategory.DataSource = dtNull;
                ddlAssetCategory.DataBind();
                ddlAssetMake.DataSource = dtNull;
                ddlAssetMake.DataBind();
                lstModelName.DataSource = dtNull;
                lstModelName.DataBind();
                dtNull = null;

                lblAssetType.Text = ddlAssetType.SelectedValue.ToString();
                PopulateCategory(lblAssetType.Text);
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Get asset model name based on asset make selected.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlAssetMake_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlAssetMake.SelectedIndex != 0)
                PopulateModelName(ddlAssetMake.SelectedValue.ToString(), lblCatCode.Text.Trim());
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Get sub category based on parent category selected.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlAssetCategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlAssetCategory.SelectedIndex > 0)
            {
                DataTable dtNull = new DataTable();
                lstModelName.DataSource = dtNull;
                lstModelName.DataBind();
                dtNull = null;

                PopulateAssetMake(ddlAssetCategory.SelectedValue.ToString());
                int CatLevel = int.Parse(lblCatLevel.Text.Trim());
                lblCatLevel.Text = (CatLevel + 1).ToString();
                int iCatLevel = int.Parse(lblCatLevel.Text.Trim());
                string sCatCode = ddlAssetCategory.SelectedValue.ToString();
                lblCatCode.Text = sCatCode;

                ddlAssetCategory.DataSource = null;
                DataTable dt = oDAL.PopulateCategory(lblAssetType.Text, sCatCode, iCatLevel);
                if (dt.Rows.Count > 0)
                {
                    ddlAssetCategory.DataSource = dt;
                    ddlAssetCategory.DataValueField = "CATEGORY_CODE";
                    ddlAssetCategory.DataTextField = "CATEGORY_NAME";
                    ddlAssetCategory.DataBind();
                    ddlAssetCategory.Items.Insert(0, "-- Select Category --");
                    ddlAssetCategory.Focus();
                }
                else
                {
                    iCatLevel = iCatLevel - 1;
                    lblCatLevel.Text = iCatLevel.ToString();
                    ddlAssetMake.Focus();
                }
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Get location code/name to be populated into dropdownlist.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlAssetLocation_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlAssetLocation.SelectedIndex != 0)
            {
                int locLevel = int.Parse(lblLocLevel.Text.Trim());
                lblLocLevel.Text = (locLevel + 1).ToString();
                int iLocLevel = int.Parse(lblLocLevel.Text.Trim());
                string sLocCode = ddlAssetLocation.SelectedValue.ToString();
                lblLocCode.Text = sLocCode;

                ddlAssetLocation.DataSource = null;
                DataTable dt = oDAL.GetLocation(_CompCode, Session["COMPLOCATION"].ToString(), sLocCode, iLocLevel);
                if (dt.Rows.Count > 0)
                {
                    ddlAssetLocation.DataSource = dt;
                    ddlAssetLocation.DataValueField = "LOC_CODE";
                    ddlAssetLocation.DataTextField = "LOC_NAME";
                    ddlAssetLocation.DataBind();
                    ddlAssetLocation.Items.Insert(0, "-- Select Location --");
                    ddlAssetLocation.Focus();
                }
                else
                {
                    iLocLevel = iLocLevel - 1;
                    lblLocLevel.Text = iLocLevel.ToString();
                    txtAllocatedDate.Focus();
                }
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Get from process name list based on department name provided.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlFromDept_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlFromDept.SelectedIndex > 0)
            {
                PopulateFromProcess(ddlFromDept.SelectedValue.ToString());
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Get to process name list based on department name provided.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlToDept_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlToDept.SelectedIndex > 0)
            {
                PopulateToProcess(ddlToDept.SelectedValue.ToString());
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Get employee code/name on the selection of department name.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlToProject_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlToProject.SelectedIndex > 0)
            {
                PopulateProcessEmp(ddlToProject.SelectedValue.ToString(), Session["COMPANY"].ToString());
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Get allocated to employee code as the employee name selected.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlAllocatedTo_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlAllocatedTo.SelectedIndex > 0)
                txtAllocatedToId.Text = ddlAllocatedTo.SelectedValue.ToString();
            else
                txtAllocatedToId.Text = "";
            
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Get approved by employee code as the employee name selected.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlApprovedBy_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlApprovedBy.SelectedIndex > 0)
                txtApprovedById.Text = ddlApprovedBy.SelectedValue.ToString();
            else
                txtApprovedById.Text = "";
            
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Get requested by employee code as the employee name selected.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlRequestedBy_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlRequestedBy.SelectedIndex > 0)
                txtRequestedById.Text = ddlRequestedBy.SelectedValue.ToString();
            else
                txtRequestedById.Text = "";
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    #endregion

    #region GRIDVIEW EVENTS
    /// <summary>
    /// Embed checkbox into the assets grid as the assets bound to it.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvAssets_RowCreated(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow &&
               (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate))
            {
                CheckBox chkSelect = (CheckBox)e.Row.Cells[0].FindControl("chkSelectAsset");
                CheckBox chkHSelect = (CheckBox)this.gvAssets.HeaderRow.FindControl("chkHSelect");
                chkSelect.Attributes["onclick"] = string.Format("javascript:ChildClick(this,'{0}');", chkHSelect.ClientID);
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Assets gridview page index changing event.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvAssets_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvAssets.PageIndex = e.NewPageIndex;
            gvAssets.DataSource = (DataTable)Session["Assets"];
            gvAssets.DataBind();
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Asset allocation delete event.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvAssetAllocation_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            if (clsGeneral._strRights[3] == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('You are not authorised to execute this operation.');", true);
            }
            else
            {

            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Asset allocation history page index changed event.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvAssetAllocation_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvAssetAllocation.PageIndex = e.NewPageIndex;
            GetAssetAllocationDetails(Session["COMPANY"].ToString());
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    #endregion
}