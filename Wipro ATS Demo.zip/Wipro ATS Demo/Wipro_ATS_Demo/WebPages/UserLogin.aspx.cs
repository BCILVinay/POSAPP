﻿using System;
using System.Data;
using System.Web;
using System.Text;
using System.Web.UI;
using MobiVUE_ATS.DAL;
using MobiVUE_ATS.PRP;

public partial class UserLogin : System.Web.UI.Page
{
    UserMaster_DAL oDAL;
    UserMaster_PRP oPRP;
    public UserLogin()
    {
        oDAL = new UserMaster_DAL("IT");
        oPRP = new UserMaster_PRP();
    }
    ~UserLogin()
    {
        oDAL = null; oPRP = null;
    }

    #region PAGE EVENTS
    /// <summary>
    /// User login page.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Page.IsPostBack)
            {
                
                Session["DATABASE"] = "IT";
                Session["COMPLOCATION"] = null;
                Session["COMPANY"] = null;
                HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                HttpContext.Current.Response.Cache.SetAllowResponseInBrowserHistory(false);
                PopulateCompany();
                ddlCompany.Focus();
                this.Form.DefaultButton = btnSignIn.UniqueID;
            }
            lblMsg.Visible = false;
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    #endregion

    #region PRIVATE FUNCTIONS
    /// <summary>
    /// Catch unhandled exceptions.
    /// </summary>
    /// <param name="ex"></param>
    public void HandleExceptions(Exception ex)
    {
        clsGeneral.LogErrorToLogFile(ex, "User Login");
        if (!ex.Message.ToString().Contains("Thread was being aborted."))
        {
            clsGeneral.ErrMsg = ex.Message.ToString(); try { string[] arrErr = ex.Message.ToString().Split('\n'); Session["ErrMsg"] = arrErr[0].ToString().Trim(); }
            catch { } Server.Transfer("Error.aspx");
        }
    }

    /// <summary>
    /// Populate company code/name details based on asset type selected.
    /// </summary>
    private void PopulateCompany()
    {
        ddlCompany.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.GetCompany();
        ddlCompany.DataSource = dt;
        ddlCompany.DataTextField = "COMP_NAME";
        ddlCompany.DataValueField = "COMP_CODE";
        ddlCompany.DataBind();
        ddlCompany.Items.Insert(0, "-- Select Company --");
    }

    private void PopulateLocation(string Company)
    {
        ddlCompLocation.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.GetCompLocation(Company);
        ddlCompLocation.DataSource = dt;
        ddlCompLocation.DataTextField = "STORAGE_LOC_NAME";
        ddlCompLocation.DataValueField = "STORAGE_LOC_CODE";
        ddlCompLocation.DataBind();
        ddlCompLocation.Items.Insert(0, "-- Select Location --");
    }

    /// <summary>
    /// Encrypt user password in order to check login credentials.
    /// </summary>
    /// <param name="password"></param>
    /// <returns></returns>
    private string EncryptPassword(string password)
    {
        string EncryptedPswd = string.Empty;
        byte[] encode = new byte[password.Length];
        encode = Encoding.UTF8.GetBytes(password);
        EncryptedPswd = Convert.ToBase64String(encode);
        return EncryptedPswd;
    }
    #endregion

    #region BUTTON EVENTS
    /// <summary>
    /// User logs in selecting asset type, company/location and on entering user id, password.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSignIn_Click(object sender, ImageClickEventArgs e)
    {
        oDAL = new UserMaster_DAL(Session["DATABASE"].ToString());
        oPRP = new UserMaster_PRP();
        try
        {
            DataTable dtGrpRights = new DataTable();
            oPRP.UserID = txtUserId.Text.Trim();
            oPRP.UserPswd = EncryptPassword(txtPassword.Text.Trim());
            oPRP.CompCode = ddlCompany.SelectedValue.ToString();
            oPRP.LocationCode = ddlCompLocation.SelectedValue.ToString();
            if (oPRP.UserID.ToUpper() == "SUPERUSER" && oPRP.UserPswd.ToUpper() == "DELL@123")
            {
                //if (ddlAssetType.SelectedValue.ToString() == "ADMIN")
                //    clsGeneral.gStrAssetType = "ADMIN";
                //else if (ddlAssetType.SelectedValue.ToString() == "IT")
                //    clsGeneral.gStrAssetType = "IT";
                Session["SUPER_USER_ID"] = txtUserId.Text.Trim();
                Session["COMPANY"] = ddlCompany.SelectedIndex <= 0 ? "" : ddlCompany.SelectedValue.ToString();
                Response.Redirect("~/Webpages/CreateInitialData.aspx", false);
            }
            else if (ddlCompLocation.SelectedIndex == 0)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ValidateLogin1", "ValidateLogin1();", true);
            }
            else if (ddlCompany.SelectedIndex == 0)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ValidateLogin", "ValidateLogin();", true);
            }
            else
            {
                if (oDAL.ValidateUserLogin(oPRP))
                {
                    Session["SUPER_USER_ID"] = null;
                    Session["COMPANY"] = ddlCompany.SelectedValue.ToString();
                    Session["EMAIL"] = oDAL.GetUserEmailID(oPRP.UserID, Session["COMPANY"].ToString()).ToString();
                    Session["CURRENTUSER"] = txtUserId.Text.Trim();
                    Session["CurrentLocation"] = ddlCompLocation.SelectedValue;
                    Session["COMP_NAME"] = ddlCompany.SelectedItem.Text.Trim();
                    
                    Session["GROUP"] = oDAL.GetLogInUserGroup(oPRP.UserID, oPRP.CompCode);
                    dtGrpRights = oDAL.GetGroupRights(oPRP.UserID, oPRP.CompCode);
                    clsGeneral.gStrSessionID = Session.SessionID.ToString();
                    if (dtGrpRights.Rows.Count == 0)
                    {
                        Session["ErrMsg"] = "The logged in user doesn't belong to any group, please contact system administrator.";
                        Response.Redirect("~/Webpages/Error.aspx", false);
                    }
                    else
                    {
                        Session["UserRights"] = dtGrpRights;
                        Response.Redirect("~/Webpages/Home.aspx", false);
                    }
                }
                else
                {
                    lblMsg.Text = "Invalid User ID/Password!";
                    lblMsg.Visible = true;
                    txtUserId.Text = "";
                    txtPassword.Text = "";
                    //ddlAssetType.SelectedIndex = 0;
                    ddlCompLocation.SelectedIndex = 0;
                    ddlCompany.SelectedIndex = 0;
                    ddlCompLocation.Focus();
                    // ddlAssetType.Focus();
                }
            }
        }
        catch (Exception ex)
        {
            clsGeneral.LogErrorToLogFile(ex, "User sign in error occured.");
            if (ex.Message.ToString().ToUpper().Contains("LOGIN FAILED FOR USER"))
            {
                Session["CURRENTUSER"] = null;
                HandleExceptions(ex);
            }
        }
        finally
        { oDAL = null; oPRP = null; }
    }

    /// <summary>
    /// User is redirected to forgot password page.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnForgotPswd_Click(object sender, EventArgs e)
    {
        try
        {
            Session["COMPANY"] = ddlCompany.SelectedValue.ToString();
            Response.Redirect("~/Webpages/ForgotPassword.aspx");
        }
        catch (Exception ex)
        {
            clsGeneral.LogErrorToLogFile(ex, "User sign in error occured.");
            if (ex.Message.ToString().ToUpper().Contains("LOGIN FAILED FOR USER"))
            {
                Session["CURRENTUSER"] = null;
                HandleExceptions(ex);
            }
        }
    }
    #endregion

    #region SELECTED INDEX CHANGED EVENTS
    /// <summary>
    /// Populate company names based on Asset Type selected from dropdownlist.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    //protected void ddlAssetType_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        if (ddlAssetType.SelectedIndex != 0)
    //        {
    //            if (ddlAssetType.SelectedValue.ToString() == "ADMIN")
    //            {
    //                Session["DATABASE"] = "ADMIN";
    //                oDAL = new UserMaster_DAL(Session["DATABASE"].ToString());
    //                oPRP = new UserMaster_PRP();
    //                PopulateLocation();
    //                //PopulateCompany();
    //                ddlCompLocation.Focus();
    //            }
    //            else if (ddlAssetType.SelectedValue.ToString() == "IT")
    //            {
    //                Session["DATABASE"] = "IT";
    //                oDAL = new UserMaster_DAL(Session["DATABASE"].ToString());
    //                oPRP = new UserMaster_PRP();
    //                PopulateLocation();
    //                //PopulateCompany();
    //                ddlCompLocation.Focus();
    //            }
    //        }
    //    }
    //    catch (Exception ex)
    //    { HandleExceptions(ex); }
    //    finally
    //    { oDAL = null; oPRP = null; }
    //}

    protected void ddlCompany_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlCompany.SelectedIndex != 0)
            {
                Session["COMPANY"] = ddlCompany.Text.Trim();
                Session["DATABASE"] = "IT";
                PopulateLocation(ddlCompany.Text.Trim());
                ddlCompLocation.Focus();
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
        finally
        { oDAL = null; oPRP = null; }
    }

    protected void ddlCompLocation_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlCompLocation.SelectedIndex != 0)
            {
                Session["COMPLOCATION"] = ddlCompLocation.Text.Trim();
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
        finally
        { oDAL = null; oPRP = null; }
    }

    #endregion



}