﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Text;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MobiVUE_ATS.PRP;

namespace MobiVUE_ATS.DAL
{
    /// <summary>
    /// Summary description for UserMaster_DAL
    /// </summary>
    public class UserMaster_DAL
    {
       private static  clsDb oDb =null;
        StringBuilder sbQuery;
        public UserMaster_DAL(string DatabaseType)
        {
            if (oDb == null)
            {
                oDb = new clsDb();
            }

            if (DatabaseType != "")
                oDb.Connect(DatabaseType);
        }
        ~UserMaster_DAL()
        {
            if (oDb != null)
            {
                oDb.Disconnect();
            }
          
            oDb = null;
            sbQuery = null;
        }

        /// <summary>
        /// Checks User Login Credentials When User Logins.
        /// </summary>
        /// <param name="oPRP"></param>
        /// <returns>bValid</returns>
        public bool ValidateUserLogin(UserMaster_PRP oPRP)
        {
            try
            {
                bool bValid = false;
                sbQuery = new StringBuilder();
                sbQuery.Append("EXEC sp_UserLogin @TYPE='VALIDATEUSERLOGIN',  @USER_ID='" + oPRP.UserID.Trim().Replace("'", "''") + "', ");
                sbQuery.Append("@PASSWORD='" + oPRP.UserPswd.Trim().Replace("'", "''") + "', @COMP_CODE='" + oPRP.CompCode.Trim() + "' , @LOC_CODE='" + oPRP.LocationCode + "', @ACTIVE=1");
                DataTable dt = oDb.GetDataTable(sbQuery.ToString());
                if (dt.Rows.Count > 0)
                {
                    bValid = true;
                }
                return bValid;
            }
            catch (Exception ex)
            { throw ex; }
        }

        /// <summary>
        /// Update session state into user accounts table to avoid multiple 
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="CompCode"></param>
        /// <param name="SessionID"></param>
        public bool SaveLoggedInSessionID(string UserID, string CompCode, string SessionID)
        {
            bool bResp = false;
            sbQuery = new StringBuilder();
            sbQuery.Append("EXEC sp_UserLogin @TYPE='SAVELOGGEDINSESSIONID', @SESSION_ID='" + SessionID + "', @USER_ID='" + UserID + "'");
            sbQuery.Append(" , @COMP_CODE='" + CompCode + "'");
            int iRes = oDb.ExecuteQuery(sbQuery.ToString());
            if (iRes > 0)
                bResp = true;
            return bResp;
        }

        /// <summary>
        /// Update session state as null into user accounts table when user logs out.
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="CompCode"></param>
        public void UpdateLoggedInSessionID(string UserID, string CompCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("EXEC sp_UserLogin @TYPE='UPDATELOGGEDINSESSIONID', @USER_ID='" + UserID + "', @COMP_CODE='" + CompCode + "'");
            oDb.ExecuteQuery(sbQuery.ToString());
        }

        /// <summary>
        /// Update session state as null into user accounts table when user logs out.
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="CompCode"></param>
        public string GetLoggedInSessionID(string UserID, string CompCode)
        {
            string SessionID = "";
            sbQuery = new StringBuilder();
            sbQuery.Append("EXEC sp_UserLogin @TYPE='GETLOGGEDINSESSIONID', @USER_ID='" + UserID + "', @COMP_CODE='" + CompCode + "'");
            DataTable dt = oDb.GetDataTable(sbQuery.ToString());
            if (dt.Rows.Count > 0)
            {
                SessionID = dt.Rows[0]["USER_SESSION_ID"].ToString();
            }
            return SessionID;
        }

        /// <summary>
        /// Fetches User Rights For View/Save/Edit/Delete/Export Operations Throughout The Application Scope.
        /// </summary>
        /// <param name="_UserID"></param>
        /// <returns>DataTable</returns>
        public DataTable GetGroupRights(string _UserID, string _CompCode)
        {
            try
            {
                sbQuery = new StringBuilder();
                sbQuery.Append("EXEC sp_UserLogin @TYPE='GETGROUPRIGHTS', @USER_ID= '" + _UserID.Trim().Replace("'", "''") + "', @COMP_CODE='" + _CompCode + "'");
                return oDb.GetDataTable(sbQuery.ToString());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Save/Update User Details.
        /// </summary>
        /// <param name="OpType"></param>
        /// <param name="oPRP"></param>
        /// <returns>bResult</returns>
        public bool SaveUpdateUser(string OpType, UserMaster_PRP oPRP)
        {
            try
            {
                bool bResult = false;
                sbQuery = new StringBuilder();
                sbQuery.Append("EXEC sp_UserLogin @TYPE='SAVEUPDATEUSER',@OPTYPE='" + OpType + "', @USER_ID= '" + oPRP.UserID.Trim().Replace("'", "''") + "',@USER_NAME='" + oPRP.UserName.Trim().Replace("'", "''") + "',");
                if (OpType != "UPDATE")
                    sbQuery.Append(" @PASSWORD='" + oPRP.UserPswd.Trim().Replace("'", "''") + "',");
                sbQuery.Append(" @USER_EMAIL='" + oPRP.UserEmail + "',");
                sbQuery.Append(" @COMP_CODE='" + oPRP.CompCode + "',@LOC_CODE='" + oPRP.LocationCode + "',@GROUP_CODE='" + oPRP.GroupCode + "',");
                sbQuery.Append(" @ACTIVE='" + oPRP.Active + "',@CREATED_BY='" + oPRP.CreatedBy + "',@MODIFIED_BY='" + oPRP.ModifiedBy + "',");
                sbQuery.Append(" @TECH_OPS_EMAIL='" + oPRP.TechOpsEmail.Trim() + "'");
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }

        public bool UserExists(UserMaster_PRP oPRP)
        {
            try
            {
                 bool bResult = false;
                sbQuery = new StringBuilder();
                sbQuery.Append("EXEC sp_UserLogin @TYPE='CHECKUSER', @USER_ID= '" + oPRP.UserID.Trim().Replace("'", "''") + "',@USER_NAME='" + oPRP.UserName.Trim().Replace("'", "''") + "',");
                sbQuery.Append(" @COMP_CODE='" + oPRP.CompCode + "'");
                DataTable tbl = oDb.GetDataSet(sbQuery.ToString()).Tables[0];
                if (Convert.ToInt16(tbl.Rows[0][0]) > 0)
                {
                    bResult = true;
                }
                else
                {
                    bResult = false;
                }
                    
                return bResult;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// User Password Can Be Changed Through This Function
        /// </summary>
        /// <param name="oPRP"></param>
        /// <returns>bResult</returns>
        public bool ChangePassword(UserMaster_PRP oPRP)
        {
            try
            {
                bool bResult = false;
                sbQuery = new StringBuilder();
                sbQuery.Append("EXEC sp_UserLogin @TYPE='CHANGEPASSWORD', @NEWPASSWORD='" + oPRP.NewPswd.Trim().Replace("'", "''") + "', @USER_ID='" + oPRP.UserID.Trim().Replace("'", "''") + "',");
                sbQuery.Append(" @PASSWORD='" + oPRP.UserPswd.Trim().Replace("'", "''") + "', @COMP_CODE='" + oPRP.CompCode + "'");
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }

        /// <summary>
        /// Checks For Duplicate User ID
        /// </summary>
        /// <param name="_UserID"></param>
        /// <returns>bDup</returns>
        private bool CheckDuplicateUser(string _UserID, string _CompCode)
        {
            try
            {
                bool bDup = false;
                sbQuery = new StringBuilder();
                sbQuery.Append("EXEC sp_UserLogin @TYPE='CHECKDUPLICATEUSER', @USER_ID= '" + _UserID.Trim().Replace("'", "''") + "', @COMP_CODE='" + _CompCode + "'");
                DataTable dt = oDb.GetDataTable(sbQuery.ToString());
                if (dt.Rows.Count > 0)
                    bDup = true;
                return bDup;
            }
            catch (Exception ex)
            { throw ex; }
        }

        /// <summary>
        /// Fetches User Details To Be Populated In GridView
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable GetUserDetails(string CompCode)
        {
            try
            {
                sbQuery = new StringBuilder();
                sbQuery.Append("EXEC sp_UserLogin @TYPE='GETUSERDETAILS', @COMP_CODE='" + CompCode + "'");
                return oDb.GetDataTable(sbQuery.ToString());
            }
            catch (Exception ex)
            { throw ex; }
        }

        /// <summary>
        /// Delete A Particular User
        /// </summary>
        /// <param name="oPRP"></param>
        /// <returns>bResult</returns>
        public bool DeleteUser(UserMaster_PRP oPRP)
        {
            try
            {
                bool bResult = false;
                sbQuery = new StringBuilder();
                sbQuery.Append("EXEC sp_UserLogin @TYPE='DELETEUSER', @USER_ID= '" + oPRP.UserID.Trim().Replace("'", "''") + "', @COMP_CODE='" + oPRP.CompCode + "'");
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }

        /// <summary>
        /// Gets Existing Password For An Existing User
        /// </summary>
        /// <param name="_UserID"></param>
        /// <param name="_UserEmail"></param>
        /// <returns>_UserPswd</returns>
        public string GetUserPassword(string _UserID, string _CompCode, string _UserEmail)
        {
            try
            {
                string _UserPswd = "";
                sbQuery = new StringBuilder();
                sbQuery.Append("EXEC sp_UserLogin @TYPE='GETUSERPASSWORD', @USER_ID= '" + _UserID + "',@USER_EMAIL='" + _UserEmail + "', @COMP_CODE='" + _CompCode + "'");
                DataTable dt = oDb.GetDataTable(sbQuery.ToString());
                if (dt.Rows.Count > 0)
                {
                    _UserPswd = dt.Rows[0][0].ToString();
                }
                else
                    _UserPswd = "NOT_FOUND";
                return _UserPswd;
            }
            catch (Exception ex)
            { throw ex; }
        }



        public bool SendPassword(string To , string CC, string Body,string subject)
        {
            try
            {
                sbQuery = new StringBuilder();
                sbQuery.Append("EXEC USP_SendMailConfiguration  @Recipients='" + To + "', @SUBJECT= '" + subject + "',@BODY='" + Body + "'");
                DataTable dt = oDb.GetDataTable(sbQuery.ToString());
                if (dt.Rows.Count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }
        /// <summary>
        /// Fetch Locations details for mapping with user id
        /// </summary>
        /// <param name="_ParentLocCode"></param>
        /// <param name="_LocLevel"></param>
        /// <returns>DataTable</returns>
        public DataTable GetLocation(string _CompCode, string _ParentLocCode, int _LocLevel)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("EXEC sp_UserLogin @TYPE='GETLOCATION', @PARENT_LOC_CODE= '" + _ParentLocCode + "',@LOC_LEVEL=" + _LocLevel + ", @COMP_CODE='" + _CompCode + "'");
            return oDb.GetDataTable(sbQuery.ToString());
            oDb.Disconnect();
            oDb = null;
        }

        /// <summary>
        /// Fetch Group details for mapping with user id
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable GetGroup(string CompanyCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("EXEC sp_UserLogin @TYPE='GETGROUP', @COMP_CODE='" + CompanyCode + "'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Fetches Company details
        /// </summary>
        /// <returns></returns>
        public DataTable GetCompany()
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("EXEC sp_UserLogin @TYPE='GETCOMPANY'");
            return oDb.GetDataTable(sbQuery.ToString());
            oDb.Disconnect();
            oDb = null;
        }

        /// <summary>
        /// Fetches Company details for mapping with user id
        /// </summary>
        /// <returns></returns>
        //public DataTable GetCompany()
        //{
        //    sbQuery = new StringBuilder();
        //    sbQuery.Append("SELECT COMP_CODE,COMP_NAME FROM COMPANY_MASTER WHERE ACTIVE='1' AND COMP_OWNER=0");
        //    return oDb.GetDataTable(sbQuery.ToString());
        //}

        /// <summary>
        /// Get logged in user email id.
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        public string GetUserEmailID(string UserID, string CompCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("EXEC sp_UserLogin @TYPE='GETUSEREMAILID',@USER_ID='" + UserID + "', @COMP_CODE='" + CompCode + "'");
            return oDb.GetDataTable(sbQuery.ToString()).Rows[0]["TECHOPS_EMAIL"].ToString();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="CompCode"></param>
        /// <returns></returns>
        public string GetLogInUserGroup(string UserID, string CompCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("EXEC sp_UserLogin @TYPE='GETLOGINUSERGROUP',@USER_ID='" + UserID + "', @COMP_CODE='" + CompCode + "'");
            return oDb.GetDataTable(sbQuery.ToString()).Rows[0]["GROUP_CODE"].ToString();
        }

        /// <summary>
        /// Get list of distinct locations.
        /// </summary>
        public DataTable GetCompLocation(string CompCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("EXEC sp_UserLogin @TYPE='GETCOMPLOCATION',@COMP_CODE='" + CompCode + "'");
            return oDb.GetDataTable(sbQuery.ToString());
            oDb.Disconnect();
            oDb = null;
        }

        /// <summary>
        /// Fetches Company details
        /// </summary>
        /// <returns></returns>
        public DataTable GetCompany(string CompLocation)
        {
            sbQuery = new StringBuilder();
            //sbQuery.AppendLine("SELECT COMP_CODE,COMP_NAME FROM COMPANY_LOCATION WHERE LOCATION='" + CompLocation + "' AND ACTIVE='1'");
            sbQuery.Append("EXEC sp_UserLogin @TYPE='GETLOCCOMPANY',@COMP_LOCATION='" + CompLocation + "'");
            return oDb.GetDataTable(sbQuery.ToString());
        }
    }
}