﻿//************************************************************************************************************************************************
//  Data Access Layer Class For Add/Edit/Update/Delete Project Master
//  Created By : Neeraj Saxena
//  Created On : June 01, 2012
//  Modified By : Neeraj Saxena
//  Modified On : June 03, 2012 
//************************************************************************************************************************************************
using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Text;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MobiVUE_ATS.PRP;

namespace MobiVUE_ATS.DAL
{
    /// <summary>
    /// Summary description for Project Master Data Access Layer
    /// </summary>
    public class SubProjectMaster_DAL
    {
        clsDb oDb;
        StringBuilder sbQuery;
        public SubProjectMaster_DAL(string DatabaseType)
        {
            oDb = new clsDb();
            if (DatabaseType != "")
                oDb.Connect(DatabaseType);
        }
        ~SubProjectMaster_DAL()
        {
            oDb.Disconnect();
            oDb = null;
            sbQuery = null;
        }

        /// <summary>
        /// Checks Duplicate Project Code
        /// </summary>
        /// <param name="_DeptCode"></param>
        /// <returns>bDup</returns>
        private bool CheckDuplicateSubProject(string _SubProjectCode,string _ProjectCode, string _LocCode)
        {
            try
            {
                bool bDup = false;
                sbQuery = new StringBuilder();
                sbQuery.Append("EXEC sp_SubProjectMaster @TYPE='CHECKDUPLICATESUBPROJECT',@SUB_PROJECT_CODE='" + _SubProjectCode + "', @PROJECT_CODE= '" + _ProjectCode.Trim() + "',@LOCATION_CODE='" + _LocCode + "'");
                DataTable dt = oDb.GetDataTable(sbQuery.ToString());
                if (dt.Rows.Count > 0)
                    bDup = true;
                return bDup;                
            }
            catch (Exception ex)
            { throw ex; }
        }

        /// <summary>
        /// Save/Update Project Master
        /// </summary>
        /// <param name="OpType"></param>
        /// <param name="oPRP"></param>
        /// <returns>bResult</returns>
        public bool SaveSubProject(SubProjectMaster_PRP  oPRP)
        {
            try
            {
                bool bResult = false;
                if (!CheckDuplicateSubProject(oPRP.SubProjectCode,oPRP.ProjectCode, oPRP.LocCode))
                {
                    sbQuery = new StringBuilder();
                    sbQuery.Clear();
                    sbQuery.Append("EXEC sp_SubProjectMaster @TYPE='SAVESUBPROJECT',@SUB_PROJECT_CODE='" + oPRP.SubProjectCode.Trim().Replace("'", "''") + "',@SUB_PROJECT_NAME='" + oPRP.SubProjectName.Trim().Replace("'", "''") + "',");
                    sbQuery.Append(" @PROJECT_CODE='" + oPRP.ProjectCode.Trim().Replace("'", "''") + "', @PROJECT_MANAGER='" + oPRP.ProjectManager.Trim().Replace("'", "''") + "',");
                    sbQuery.Append(" @LOCATION_CODE='" + oPRP.LocCode + "', @REMARKS='" + oPRP.Remarks.Trim() + "',@ACTIVE='" + oPRP.Active + "',@CREATED_BY='" + oPRP.CreatedBy + "'");
                }

                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }

        public bool UpdateSubProject(SubProjectMaster_PRP oPRP)
        {
            try
            {
                bool bResult = false;
                sbQuery = new StringBuilder();
                sbQuery.Clear();
                sbQuery.Append("EXEC sp_SubProjectMaster @TYPE='UPDATESUBPROJECT', @SUB_PROJECT_NAME= '" + oPRP.SubProjectName + "',@ACTIVE='" + oPRP.Active + "',");
                sbQuery.Append(" @PROJECT_MANAGER='" + oPRP.ProjectManager + "',@REMARKS='" + oPRP.Remarks + "',");
                sbQuery.Append(" @MODIFIED_BY='" + oPRP.ModifiedBy + "',@LOCATION_CODE='" + oPRP.LocCode + "',");
                sbQuery.Append(" @PROJECT_CODE='" + oPRP.ProjectCode + "',@SUB_PROJECT_CODE='" + oPRP.SubProjectCode + "'");
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }

        /// <summary>
        /// Fetches Project Master Records For GridView Population
        /// </summary>
        /// <returns>DataTable</returns>        
        public DataTable GetSubProjectDetails(string LocCode)
        {
            try
            {
                sbQuery = new StringBuilder();
                sbQuery.Clear();
                sbQuery.Append("EXEC sp_SubProjectMaster @TYPE='GETSUBPROJECTDETAILS',@LOCATION_CODE='" + LocCode + "'");
                return oDb.GetDataTable(sbQuery.ToString());
            }
            catch (Exception ex)
            { throw ex; }
        }

        /// <summary>
        /// Delete A Project From Project Master
        /// </summary>
        /// <param name="_EmpCode"></param>
        /// <returns>bResult</returns>
        //public string DeleteProject(string _ProjectCode,string _CompCode)
        //{
        //    try
        //    {
        //        string DelRslt = "";
        //        sbQuery = new StringBuilder();
        //        sbQuery.Append("SELECT COUNT(*) AS Project FROM EMPLOYEE_MASTER WHERE EMP_Project_CODE='" + _ProjectCode + "' AND COMP_CODE='" + _CompCode + "'");
        //        DataTable dtRefChk = oDb.GetDataTable(sbQuery.ToString());
        //        if (dtRefChk.Rows[0]["Project"].ToString() != "0")
        //        {
        //            DelRslt = "Project_MAPPED";
        //            return DelRslt;
        //        }
        //        sbQuery = new StringBuilder();
        //        sbQuery.Append("SELECT COUNT(*) AS Project FROM ASSET_ACQUISITION WHERE ASSET_Project='" + _ProjectCode + "' AND COMP_CODE='" + _CompCode + "'");
        //        DataTable dt1 = oDb.GetDataTable(sbQuery.ToString());
        //        if (dt1.Rows[0]["Project"].ToString() != "0")
        //        {
        //            DelRslt = "ASSET_MAPPED";
        //            return DelRslt;
        //        }
        //        sbQuery = new StringBuilder();
        //        sbQuery.Append("DELETE FROM [Project_MASTER] WHERE [Project_CODE] = '" + _ProjectCode + "' AND COMP_CODE='" + _CompCode + "'");
        //        int iRes = oDb.ExecuteQuery(sbQuery.ToString());
        //        if (iRes > 0)
        //            DelRslt = "SUCCESS";
        //        return DelRslt;
        //    }
        //    catch (Exception ex)
        //    { throw ex; }
        //}

        public bool DeleteSubProject(string _SubProjectCode,string _LocCode)
        {
            try
            {
                bool bResult = false;
                sbQuery = new StringBuilder();
                sbQuery.Append("EXEC sp_SubProjectMaster @TYPE='DELETESUBPROJECT', @SUB_PROJECT_CODE='" + _SubProjectCode + "',@LOCATION_CODE='" + _LocCode + "'");
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }

        /// <summary>
        /// Get employee code/name to be populated into dropdownlist.
        /// </summary>
        /// <returns></returns>
        public DataTable GetPRojectManager(string LocCode)
        {
            try
            {
                sbQuery = new StringBuilder();
                sbQuery.Clear();
                sbQuery.Append("EXEC sp_SubProjectMaster @TYPE='GETPROJECTMANAGER',@LOCATION_CODE='" + LocCode + "'");
                return oDb.GetDataTable(sbQuery.ToString());
            }
            catch (Exception ex)
            { throw ex; }
        }

        /// <summary>
        /// Get department code/name to be populated into dropdownlist.
        /// </summary>
        /// <returns></returns>
        public DataTable GetProject(string LocCode)
        {
            try
            {
                sbQuery = new StringBuilder();
                sbQuery.Clear();
                sbQuery.Append("EXEC sp_SubProjectMaster @TYPE='GETPROJECT',@LOCATION_CODE='" + LocCode + "'");
                return oDb.GetDataTable(sbQuery.ToString());
            }
            catch (Exception ex)
            { throw ex; }
        }
    }
}