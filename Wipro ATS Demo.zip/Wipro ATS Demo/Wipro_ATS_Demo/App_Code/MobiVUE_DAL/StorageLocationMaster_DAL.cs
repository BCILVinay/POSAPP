﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Text;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MobiVUE_ATS.PRP;

namespace MobiVUE_ATS.DAL
{
    /// <summary>
    /// Summary description for CompanyMaster_DAL
    /// </summary>
    public class StorageLocationMaster_DAL
    {
        clsDb oDb;
        StringBuilder sbQuery;
        public StorageLocationMaster_DAL(string DatabaseType)
        {
            oDb = new clsDb();
            if (DatabaseType != "")
                oDb.Connect(DatabaseType);
        }
        ~StorageLocationMaster_DAL()
        {
            oDb.Disconnect();
            oDb = null;
            sbQuery = null;
        }

        private bool CheckDuplicateSLoc(string _SLocCode)
        {
            try
            {
                bool bDup = false;
                sbQuery = new StringBuilder();
                sbQuery.Append("EXEC sp_StorageLocationMaster @TYPE='CHECKDUPLICATELOCATION', @STORAGE_LOC_CODE= '" + _SLocCode.Trim() + "'");
                DataTable dt = oDb.GetDataTable(sbQuery.ToString());
                if (dt.Rows.Count > 0)
                    bDup = true;
                return bDup;
            }
            catch (Exception ex)
            { throw ex; }
        }

        public bool CheckDuplicateSAPLOC(string SAP_Location)
        {

            try
            {
                bool bDup = false;
                sbQuery = new StringBuilder();
                sbQuery.Append("EXEC sp_StorageLocationMaster @TYPE='CHECKDUPLICATESAPLOCATION', @SAP_LOC_CODE= '" + SAP_Location.Trim() + "'");
                DataTable dt = oDb.GetDataTable(sbQuery.ToString());
                if (dt.Rows.Count > 0)
                    bDup = true;
                return bDup;
            }
            catch (Exception ex)
            { throw ex; }
        }

        public bool SaveSLoc(StorageLocationMaster_PRP oPRP)
        {
            try
            {
                bool bResult = false;
                if (!CheckDuplicateSLoc(oPRP.SLocCode))
                {
                    sbQuery = new StringBuilder();
                    sbQuery.Clear();
                    sbQuery.Append("EXEC sp_StorageLocationMaster @TYPE='SAVELOCATION',@STORAGE_LOC_CODE='" + oPRP.SLocCode.Trim().Replace("'", "''") + "' ,@SAP_LOC_CODE='" + oPRP.SAPLocationCode.Trim().Replace("'", "''") + "'  ,@CMF_GROUP_EMAIL='" + oPRP.CMFgrpEmail.Trim().Replace("'", "''") + "',");
                    sbQuery.Append(" @STORAGE_LOC_NAME='" + oPRP.SLocName.Trim().Replace("'", "''") + "',@GSG_GROUP_EMAIL='" + oPRP.GSGgrpEmail.Trim().Replace("'", "''") + "', @REMARKS='" + oPRP.Remarks.Trim() + "',@ACTIVE='" + oPRP.Active + "',@CREATED_BY='" + oPRP.CreatedBy + "'");
                    int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                    if (iRes > 0)
                        bResult = true;
                    return bResult;

                }
                else
                {
                    return false;
                }

                
            }
            catch (Exception ex)
            { throw ex; }
        }

        public bool UpdateSLoc(StorageLocationMaster_PRP oPRP)
        {
            try
            {
                bool bResult = false;                
                sbQuery = new StringBuilder();
                sbQuery.Clear();
                sbQuery.Append("EXEC sp_StorageLocationMaster @TYPE='UPDATELOCATION', @STORAGE_LOC_NAME= '" + oPRP.SLocName + "',@ACTIVE='" + oPRP.Active + "',@CMF_GROUP_EMAIL='" + oPRP.CMFgrpEmail.Trim().Replace("'", "''") + "',");
                sbQuery.Append(" @REMARKS='" + oPRP.Remarks + "',@MODIFIED_BY='" + oPRP.ModifiedBy + "',@GSG_GROUP_EMAIL='" + oPRP.GSGgrpEmail.Trim().Replace("'", "''") + "',@STORAGE_LOC_CODE='" + oPRP.SLocCode + "'");
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }

        public DataTable GetSLocDetails()
        {
            try
            {
                sbQuery = new StringBuilder();
                sbQuery.Clear();
                sbQuery.Append("EXEC sp_StorageLocationMaster @TYPE='GETLOCATIONDETAILS'");                
                return oDb.GetDataTable(sbQuery.ToString());
            }
            catch (Exception ex)
            { throw ex; }
        }

        public DataTable GetCity()
        {
            try
            {
                sbQuery = new StringBuilder();
                sbQuery.Clear();
                sbQuery.Append("EXEC sp_StorageLocationMaster @TYPE='GETCITY'");
                return oDb.GetDataTable(sbQuery.ToString());
            }
            catch (Exception ex)
            { throw ex; }
        }


       

        /// <summary>
        /// Delete entire details of the company from database based on company location master.
        /// </summary>       
        public bool DeleteSLoc(string _SLocCode)
        {
            try
            {
                bool bResult = false;
                sbQuery = new StringBuilder();
                sbQuery.Clear();
                sbQuery.Append("EXEC sp_StorageLocationMaster @TYPE='DELETELOCATION',@STORAGE_LOC_CODE='" + _SLocCode + "'");
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }


        public int GetMaxSLocationId(string SLocCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.Clear();
            sbQuery.Append("EXEC sp_StorageLocationMaster @TYPE='GETMAXUNIQUEID',@STORAGE_LOC_CODE='" + SLocCode + "'");
            DataTable dt = oDb.GetDataTableInTransaction(sbQuery.ToString());
            return int.Parse(dt.Rows[0]["RSN"].ToString());
        }
    }
}