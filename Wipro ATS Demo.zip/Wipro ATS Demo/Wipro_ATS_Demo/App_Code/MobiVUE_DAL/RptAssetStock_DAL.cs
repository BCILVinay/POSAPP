﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Text;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MobiVUE_ATS.PRP;

namespace MobiVUE_ATS.DAL
{
    /// <summary>
    /// Summary description for RptAssetStock_DAL
    /// </summary>
    public class RptAssetStock_DAL
    {
        clsDb oDb;
        StringBuilder sbQuery;
        public RptAssetStock_DAL(string DatabaseType)
        {
            oDb = new clsDb();
            if (DatabaseType != "")
                oDb.Connect(DatabaseType);
        }
        ~RptAssetStock_DAL()
        {
            oDb.Disconnect();
            oDb = null;
            sbQuery = null;
        }

        /// <summary>
        /// Fetch Locations details for mapping with user id
        /// </summary>
        /// <param name="_ParentLocCode"></param>
        /// <param name="_LocLevel"></param>
        /// <returns>DataTable</returns>
        public DataTable GetLocation(string _CompCode,string _ParentLocCode, int _LocLevel)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("SELECT LOC_CODE, LOC_NAME FROM LOCATION_MASTER");
            sbQuery.Append(" WHERE PARENT_LOC_CODE LIKE '" + _ParentLocCode + "%' AND LOC_LEVEL=" + _LocLevel + "");
            sbQuery.Append(" AND COMP_CODE='" + _CompCode + "' AND ACTIVE=1");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Fetch category code/name details to be populated into dropdownlist.
        /// </summary>
        /// <returns></returns>
        public DataTable PopulateCategory(string _AssetType, string _ParentCategory, int _CatLevel)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("SELECT CATEGORY_CODE,CATEGORY_NAME FROM CATEGORY_MASTER");
            sbQuery.Append(" WHERE ASSET_TYPE='" + _AssetType + "' AND PARENT_CATEGORY='" + _ParentCategory + "'");
            sbQuery.Append(" AND CATEGORY_LEVEL=" + _CatLevel + " AND ACTIVE=1");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="CompCode"></param>
        /// <returns></returns>
        public DataTable PopulateAssetMake(string CategoryCode, string CompCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("SELECT DISTINCT [ASSET_MAKE] FROM [ASSET_ACQUISITION] WHERE [CATEGORY_CODE] = '" + CategoryCode + "' AND [COMP_CODE]='" + CompCode + "'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="CompCode"></param>
        /// <returns></returns>
        public DataTable PopulateModelName(string AssetMake, string CategoryCode, string CompCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("SELECT DISTINCT [MODEL_NAME] FROM [ASSET_ACQUISITION] WHERE [ASSET_MAKE]='" + AssetMake + "'");
            sbQuery.Append(" AND [CATEGORY_CODE]='" + CategoryCode + "' AND [COMP_CODE]='" + CompCode + "'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Get asset stock report details.
        /// </summary>
        /// <param name="oPRP"></param>
        /// <returns></returns>
        public DataTable GetAssetStockReport(RptAssetStock_PRP oPRP)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("SELECT COUNT(A.ASSET_CODE) AS TOTAL,A.ASSET_CODE,A.CATEGORY_NAME,A.ASSET_ID,A.SERIAL_CODE,A.LOC_NAME,A.ASSET_MAKE,A.MODEL_NAME,A.COMP_CODE FROM");
            sbQuery.Append("(SELECT ASSET_ACQUISITION.ASSET_CODE, ASSET_ACQUISITION.ASSET_ID, ASSET_ACQUISITION.SERIAL_CODE, ASSET_ACQUISITION.ASSET_MAKE,");
            sbQuery.Append(" ASSET_ACQUISITION.MODEL_NAME, ASSET_ACQUISITION.ASSET_TYPE,ASSET_ACQUISITION.COMP_CODE, CATEGORY_MASTER.CATEGORY_NAME,");
            sbQuery.Append(" LOCATION_MASTER.LOC_NAME, COMPANY_MASTER.COMP_NAME, VENDOR_MASTER.VENDOR_NAME, CONVERT(VARCHAR,");
            sbQuery.Append(" NULLIF(ASSET_ACQUISITION.INSTALLED_DATE,''), 105) AS INSTALLED_DATE, CONVERT(VARCHAR, NULLIF(ASSET_ACQUISITION.PURCHASED_DATE,''), 105)");
            sbQuery.Append(" AS PURCHASED_DATE, ASSET_ACQUISITION.PURCHASED_AMT, ASSET_ACQUISITION.PO_NUMBER, CONVERT(VARCHAR,");
            sbQuery.Append(" ASSET_ACQUISITION.PO_DATE, 105) AS PO_DATE, ASSET_ACQUISITION.INVOICE_NO, ASSET_ACQUISITION.ASSET_ALLOCATED,");
            sbQuery.Append(" ASSET_ACQUISITION.CATEGORY_CODE, ASSET_ACQUISITION.ASSET_LOCATION,ASSET_ACQUISITION.ASSET_APPROVED,ASSET_ACQUISITION.ASSET_PROCESS,ASSET_ACQUISITION.SOLD_SCRAPPED_STATUS FROM ASSET_ACQUISITION INNER JOIN");
            sbQuery.Append(" CATEGORY_MASTER ON ASSET_ACQUISITION.CATEGORY_CODE = CATEGORY_MASTER.CATEGORY_CODE INNER JOIN");
            sbQuery.Append(" LOCATION_MASTER ON ASSET_ACQUISITION.ASSET_LOCATION = LOCATION_MASTER.LOC_CODE LEFT JOIN");
            sbQuery.Append(" VENDOR_MASTER ON ASSET_ACQUISITION.VENDOR_CODE = VENDOR_MASTER.VENDOR_CODE INNER JOIN");
            sbQuery.Append(" COMPANY_MASTER ON ASSET_ACQUISITION.COMP_CODE = COMPANY_MASTER.COMP_CODE) A");
            sbQuery.Append(" WHERE A.ASSET_TYPE LIKE '" + oPRP.AssetType + "%' AND A.CATEGORY_CODE LIKE '" + oPRP.CategoryCode + "%' AND A.ASSET_MAKE LIKE '" + oPRP.AssetMake + "%' AND A.ASSET_LOCATION LIKE '" + oPRP.AssetLocation + "%' AND A.COMP_CODE = '" + oPRP.CompCode + "'");
            if (oPRP.ModelName != "")
                sbQuery.Append(" AND A.MODEL_NAME IN (" + oPRP.ModelName + ")");
            else
                sbQuery.Append(" AND A.MODEL_NAME LIKE '" + oPRP.ModelName + "%'");
            sbQuery.Append(" AND A.ASSET_APPROVED = 'True' AND A.ASSET_PROCESS = 'STOCK' AND A.SOLD_SCRAPPED_STATUS IS NULL");
            sbQuery.Append(" GROUP BY A.ASSET_CODE,A.CATEGORY_NAME,A.ASSET_ID,A.SERIAL_CODE,A.LOC_NAME,A.LOC_NAME,A.ASSET_MAKE,A.MODEL_NAME,A.COMP_CODE,A.ASSET_APPROVED ORDER BY A.MODEL_NAME");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ReturnableDateExpired"></param>
        /// <param name="CompCode"></param>
        /// <returns></returns>
        public DataTable GetReturnableAssetReport(bool ReturnableDateExpired, string CompCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("SELECT AA.ASSET_CODE,AA.SERIAL_CODE, GG.GATEPASS_CODE, CONVERT(VARCHAR, NULLIF(GA.GATEPASS_IN_DATE,''), 105) AS GATEPASS_IN_DATE,");
            sbQuery.Append(" CONVERT(VARCHAR, NULLIF(GA.EXP_RETURN_DATE,''), 105) AS EXP_RETURN_DATE FROM GATEPASS_ASSETS GA INNER JOIN ASSET_ACQUISITION AA");
            sbQuery.Append(" ON GA.ASSET_CODE = AA.ASSET_CODE INNER JOIN GATEPASS_GENERATION GG ON GA.GATEPASS_CODE = GG.GATEPASS_CODE");
            sbQuery.Append(" WHERE GA.EXP_RETURN_DATE IS NOT NULL ");
            sbQuery.Append((ReturnableDateExpired == true ? " AND GA.EXP_RETURN_DATE < GETDATE()" : ""));
            sbQuery.Append(" AND GG.COMP_CODE='" + CompCode + "' AND AA.COMP_CODE = GG.COMP_CODE");
            //sbQuery.Append(" AND GA.GATEPASS_IN_DATE IS NULL AND GA.GATEPASS_OUT_DATE IS NOT NULL");
            return oDb.GetDataTable(sbQuery.ToString());
        }
    }
}