﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Text;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MobiVUE_ATS.PRP;

namespace MobiVUE_ATS.DAL
{
    /// <summary>
    /// Summary description for CompanyMaster_DAL
    /// </summary>
    public class CompanyMaster_DAL
    {
        clsDb oDb;
        StringBuilder sbQuery;
        public CompanyMaster_DAL(string DatabaseType)
        {
            oDb = new clsDb();
            if (DatabaseType != "")
                oDb.Connect(DatabaseType);
        }
        ~CompanyMaster_DAL()
        {
            oDb.Disconnect();
            oDb = null;
            sbQuery = null;
        }

        private bool CheckDuplicateComp(string _CompCode, string _PlantCode, string _LocCode)
        {
            try
            {
                bool bDup = false;
                sbQuery = new StringBuilder();
                sbQuery.Append("EXEC sp_CompanyMaster @TYPE='CHECKDUPLICATECOMPANY', @COMP_CODE= '" + _CompCode.Trim() + "',@PLANT_CODE='" + _PlantCode + "',@STORAGE_LOC_CODE='" + _LocCode + "'");
                DataTable dt = oDb.GetDataTable(sbQuery.ToString());
                if (dt.Rows.Count > 0)
                    bDup = true;
                return bDup;
            }
            catch (Exception ex)
            { throw ex; }
        }

        private bool CheckDuplicateCompLocation(string _CompCode, string LocationCode)
        {
            try
            {
                bool bDup = false;
                sbQuery = new StringBuilder();
                sbQuery.Append("SELECT * FROM COMPANY_LOCATION WHERE COMP_CODE = '" + _CompCode.Trim().Replace("'", "''") + "' AND LOCATION='" + LocationCode + "'");
                DataTable dt = oDb.GetDataTable(sbQuery.ToString());
                if (dt.Rows.Count > 0)
                    bDup = true;
                return bDup;
            }
            catch (Exception ex)
            { throw ex; }
        }

        public bool SaveUpdateCompLocation(string OpType, CompanyMaster_PRP oPRP)
        {
            try
            {
                bool bResult = false;
                if (OpType == "SAVE")
                {
                    if (!CheckDuplicateCompLocation(oPRP.CompCode, oPRP.Location))
                    {
                        //Add new Comp...
                        sbQuery = new StringBuilder();
                        sbQuery.AppendLine("INSERT INTO [COMPANY_LOCATION]([COMP_CODE],[COMP_NAME],[LOCATION],[REMARKS],[ACTIVE],[CREATED_BY],[CREATED_ON])");
                        sbQuery.AppendLine("VALUES ('" + oPRP.CompCode.Trim() + "','" + oPRP.CompName.Trim() + "','" + oPRP.Location.Trim() + "','" + oPRP.Remarks.Trim() + "','" + oPRP.Active + "', ");
                        sbQuery.AppendLine("'" + oPRP.CreatedBy + "',GETDATE())");
                    }
                }
                if (OpType == "UPDATE")
                {
                    //Update Comp Information...
                    sbQuery = new StringBuilder();
                    sbQuery.AppendLine("UPDATE [COMPANY_LOCATION] SET [LOCATION] = '" + oPRP.Location + "',[TECHOPS_EMAIL] = '" + oPRP.TechopsEmail + "',[REMARKS] = '" + oPRP.Remarks + "',[ACTIVE] = '" + oPRP.Active + "', ");
                    sbQuery.AppendLine("[MODIFIED_BY]='" + oPRP.ModifiedBy + "',[MODIFIED_ON]=GETDATE()");
                    sbQuery.AppendLine("WHERE [COMP_NAME] = '" + oPRP.CompName + "' AND [COMP_CODE] = '" + oPRP.CompCode + "'");
                }
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }

        //public bool SaveUpdateComp(string OpType, CompanyMaster_PRP oPRP)
        //{
        //    try
        //    {
        //        bool bResult = false;
        //        if (OpType == "SAVE")
        //        {
        //            if (!CheckDuplicateComp(oPRP.CompCode))
        //            {
        //                //Add new Comp...
        //                sbQuery = new StringBuilder();
        //                sbQuery.Append("INSERT INTO [COMPANY_MASTER]([COMP_CODE],[COMP_NAME],[REMARKS],[ACTIVE],[CREATED_BY],[CREATED_ON])");
        //                sbQuery.Append(" VALUES ('" + oPRP.CompCode.Trim() + "','" + oPRP.CompName.Trim() + "','" + oPRP.Remarks.Trim() + "','" + oPRP.Active + "', ");
        //                sbQuery.Append("'" + oPRP.CreatedBy + "',GETDATE())");
        //            }
        //        }
        //        if (OpType == "UPDATE")
        //        {
        //            //Update Comp Information...
        //            sbQuery = new StringBuilder();
        //            sbQuery.Append("UPDATE [COMPANY_MASTER] SET [COMP_NAME] = '" + oPRP.CompName + "',[REMARKS] = '" + oPRP.Remarks + "',[ACTIVE] = '" + oPRP.Active + "', ");
        //            sbQuery.Append("[MODIFIED_BY]='" + oPRP.ModifiedBy + "',[MODIFIED_ON]=GETDATE()");
        //            sbQuery.Append(" WHERE [COMP_CODE] = '" + oPRP.CompCode + "'");
        //        }
        //        int iRes = oDb.ExecuteQuery(sbQuery.ToString());
        //        if (iRes > 0)
        //            bResult = true; 
        //        return bResult;
        //    }
        //    catch (Exception ex)
        //    { throw ex; }
        //}

        public bool SaveCompany(CompanyMaster_PRP oPRP)
        {
            try
            {
                bool bResult = false;
                if (!CheckDuplicateComp(oPRP.CompCode,oPRP.Plant,oPRP.Location))
                {
                    sbQuery = new StringBuilder();
                    sbQuery.Clear();
                    sbQuery.Append("EXEC sp_CompanyMaster @TYPE='SAVECOMPANY',@PLANT_CODE='" + oPRP.Plant + "',@COMP_CODE='" + oPRP.CompCode.Trim().Replace("'", "''") + "',@STORAGE_LOC_CODE='" + oPRP.Location + "',");
                    sbQuery.Append(" @COMP_NAME='" + oPRP.CompName.Trim().Replace("'", "''") + "', @REMARKS='" + oPRP.Remarks.Trim() + "',@ACTIVE='" + oPRP.Active + "',@CREATED_BY='" + oPRP.CreatedBy + "'");
                }

                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }

        public bool UpdateCompany(CompanyMaster_PRP oPRP)
        {
            try
            {
                bool bResult = false;
                sbQuery = new StringBuilder();
                sbQuery.Clear();
                sbQuery.Append("EXEC sp_CompanyMaster @TYPE='UPDATECOMPANY', @COMP_NAME= '" + oPRP.CompName + "',@ACTIVE='" + oPRP.Active + "',@PLANT_CODE='" + oPRP.Plant.Trim() + "',");
                sbQuery.Append(" @REMARKS='" + oPRP.Remarks + "',@MODIFIED_BY='" + oPRP.ModifiedBy + "',@COMP_CODE='" + oPRP.CompCode + "',@STORAGE_LOC_CODE='" + oPRP.Location + "',");
                sbQuery.Append(" @NEW_PLANT_CODE='" + oPRP.New_Plant + "',@NEW_STORAGE_LOC_CODE='" + oPRP.New_Location + "'");
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }

        public DataTable GetComp()
        {
            try
            {
                sbQuery = new StringBuilder();
                sbQuery.Clear();
                sbQuery.Append("EXEC sp_CompanyMaster @TYPE='GETCOMPANYDETAILS'");
                return oDb.GetDataTable(sbQuery.ToString());
            }
            catch (Exception ex)
            { throw ex; }
        }

        public DataTable GetPlant()
        {
            try
            {
                sbQuery = new StringBuilder();
                sbQuery.Clear();
                sbQuery.Append("EXEC sp_CompanyMaster @TYPE='GETPLANT'");
                return oDb.GetDataTable(sbQuery.ToString());
            }
            catch (Exception ex)
            { throw ex; }
        }

        public DataTable GetSLocation()
        {
            try
            {
                sbQuery = new StringBuilder();
                sbQuery.Clear();
                sbQuery.Append("EXEC sp_CompanyMaster @TYPE='GETSLOCATION'");
                return oDb.GetDataTable(sbQuery.ToString());
            }
            catch (Exception ex)
            { throw ex; }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable GetCompanyLocDetails()
        {
            try
            {
                sbQuery = new StringBuilder();
                sbQuery.AppendLine("SELECT COMP_CODE,COMP_NAME,LOCATION,TECHOPS_EMAIL,REMARKS,ACTIVE,CREATED_BY,CREATED_ON FROM COMPANY_LOCATION");
                return oDb.GetDataTable(sbQuery.ToString());
            }
            catch (Exception ex)
            { throw ex; }
        }

        /// <summary>
        /// Delete entire details of the company from database based on company location master.
        /// </summary>
        public string DeleteCompLocation(string _CompCode)
        {
            try
            {
                string DelRslt = "";
                sbQuery = new StringBuilder();
                sbQuery.AppendLine("SELECT COUNT(*) AS ASSETFOUND FROM ASSET_ACQUISITION WHERE COMP_CODE='" + _CompCode + "'");
                DataTable dtRefChk = oDb.GetDataTable(sbQuery.ToString());
                if (dtRefChk.Rows[0]["ASSETFOUND"].ToString() != "0")
                {
                    DelRslt = "ASSET_FOUND";
                    return DelRslt;
                }
                sbQuery = new StringBuilder();
                sbQuery.AppendLine("EXEC sp_DeleteAllDataOfCompany '" + _CompCode + "'");
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                DelRslt = "SUCCESS";
                return DelRslt;
            }
            catch (Exception ex)
            { throw ex; }
        }

        public bool DeleteComp(string _CompCode)
        {
            try
            {
                bool bResult = false;
                sbQuery = new StringBuilder();
                sbQuery.Append("EXEC sp_DeleteAllDataOfCompany '" + _CompCode + "'");
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }
    }
}