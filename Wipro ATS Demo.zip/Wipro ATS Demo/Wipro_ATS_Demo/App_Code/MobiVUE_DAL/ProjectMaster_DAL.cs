﻿//************************************************************************************************************************************************
//  Data Access Layer Class For Add/Edit/Update/Delete Project Master
//  Created By : Neeraj Saxena
//  Created On : June 01, 2012
//  Modified By : Neeraj Saxena
//  Modified On : June 03, 2012 
//************************************************************************************************************************************************
using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Text;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MobiVUE_ATS.PRP;

namespace MobiVUE_ATS.DAL
{
    /// <summary>
    /// Summary description for Project Master Data Access Layer
    /// </summary>
    public class ProjectMaster_DAL
    {
        clsDb oDb;
        StringBuilder sbQuery;
        public ProjectMaster_DAL(string DatabaseType)
        {
            oDb = new clsDb();
            if (DatabaseType != "")
                oDb.Connect(DatabaseType);
        }
        ~ProjectMaster_DAL()
        {
            oDb.Disconnect();
            oDb = null;
            sbQuery = null;
        }

        /// <summary>
        /// Checks Duplicate Project Code
        /// </summary>
        /// <param name="_DeptCode"></param>
        /// <returns>bDup</returns>
        private bool CheckDuplicateProject(string _ProjectCode, string _LocCode)
        {
            try
            {
                bool bDup = false;
                sbQuery = new StringBuilder();
                sbQuery.Append("EXEC sp_ProjectMaster @TYPE='CHECKDUPLICATEPROJECT', @PROJECT_CODE= '" + _ProjectCode.Trim() + "',@LOCATION_CODE='" + _LocCode + "'");
                DataTable dt = oDb.GetDataTable(sbQuery.ToString());
                if (dt.Rows.Count > 0)
                    bDup = true;
                return bDup;                
            }
            catch (Exception ex)
            { throw ex; }
        }

        /// <summary>
        /// Save/Update Project Master
        /// </summary>
        /// <param name="OpType"></param>
        /// <param name="oPRP"></param>
        /// <returns>bResult</returns>
        public bool SaveProject(ProjectMaster_PRP  oPRP)
        {
            try
            {
                bool bResult = false;
                if (!CheckDuplicateProject(oPRP.ProjectCode, oPRP.LocCode))
                {
                    sbQuery = new StringBuilder();
                    sbQuery.Clear();
                    sbQuery.Append("EXEC sp_ProjectMaster @TYPE='SAVEPROJECT' , @Comp_Code='"+oPRP.CompCode+"' , @DEPT_CODE ='" + oPRP.DeptCode + "' , @PROJECT_CODE='" + oPRP.ProjectCode.Trim().Replace("'", "''") + "',@PROJECT_NAME='" + oPRP.ProjectName.Trim().Replace("'", "''") + "',");
                    sbQuery.Append(" @LOCATION_CODE='" + oPRP.LocCode + "', @REMARKS='" + oPRP.Remarks.Trim() + "',@ACTIVE='" + oPRP.Active + "',@CREATED_BY='" + oPRP.CreatedBy + "' ,@PROJECT_MANAGER ='" + oPRP.ProejctManagerName + "' , @PM_EMAIL ='"+ oPRP.ProejctManagerEmailId+"'");
                }

                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }

        public bool UpdateProject(ProjectMaster_PRP oPRP)
        {
            try
            {
                bool bResult = false;
                sbQuery = new StringBuilder();
                sbQuery.Clear();
                sbQuery.Append("EXEC sp_ProjectMaster @TYPE='UPDATEPROJECT', @DEPT_CODE='"+oPRP.DeptCode+"' , @PROJECT_NAME= '" + oPRP.ProjectName + "',@ACTIVE='" + oPRP.Active + "',");
                sbQuery.Append(" @REMARKS='" + oPRP.Remarks +"',@PROJECT_MANAGER ='" + oPRP.ProejctManagerName + "' , @PM_EMAIL ='"+ oPRP.ProejctManagerEmailId+ "',@MODIFIED_BY='" + oPRP.ModifiedBy + "',@LOCATION_CODE='" + oPRP.LocCode + "',");
                sbQuery.Append(" @PROJECT_CODE='" + oPRP.ProjectCode + "'");
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }

        /// <summary>
        /// Fetches Project Master Records For GridView Population
        /// </summary>
        /// <returns>DataTable</returns>        
        public DataTable GetProjectDetails(string LocCode)
        {
            try
            {
                sbQuery = new StringBuilder();
                sbQuery.Clear();
                sbQuery.Append("EXEC sp_ProjectMaster @TYPE='GETPROJECTDETAILS',@LOCATION_CODE='" + LocCode + "'");
                return oDb.GetDataTable(sbQuery.ToString());
            }
            catch (Exception ex)
            { throw ex; }
        }

        /// <summary>
        /// Delete A Project From Project Master
        /// </summary>
        /// <param name="_EmpCode"></param>
        /// <returns>bResult</returns>
        //public string DeleteProject(string _ProjectCode,string _CompCode)
        //{
        //    try
        //    {
        //        string DelRslt = "";
        //        sbQuery = new StringBuilder();
        //        sbQuery.Append("SELECT COUNT(*) AS Project FROM EMPLOYEE_MASTER WHERE EMP_Project_CODE='" + _ProjectCode + "' AND COMP_CODE='" + _CompCode + "'");
        //        DataTable dtRefChk = oDb.GetDataTable(sbQuery.ToString());
        //        if (dtRefChk.Rows[0]["Project"].ToString() != "0")
        //        {
        //            DelRslt = "Project_MAPPED";
        //            return DelRslt;
        //        }
        //        sbQuery = new StringBuilder();
        //        sbQuery.Append("SELECT COUNT(*) AS Project FROM ASSET_ACQUISITION WHERE ASSET_Project='" + _ProjectCode + "' AND COMP_CODE='" + _CompCode + "'");
        //        DataTable dt1 = oDb.GetDataTable(sbQuery.ToString());
        //        if (dt1.Rows[0]["Project"].ToString() != "0")
        //        {
        //            DelRslt = "ASSET_MAPPED";
        //            return DelRslt;
        //        }
        //        sbQuery = new StringBuilder();
        //        sbQuery.Append("DELETE FROM [Project_MASTER] WHERE [Project_CODE] = '" + _ProjectCode + "' AND COMP_CODE='" + _CompCode + "'");
        //        int iRes = oDb.ExecuteQuery(sbQuery.ToString());
        //        if (iRes > 0)
        //            DelRslt = "SUCCESS";
        //        return DelRslt;
        //    }
        //    catch (Exception ex)
        //    { throw ex; }
        //}

        public bool DeleteProject(string _ProjectCode,string _LocCode)
        {
            try
            {
                bool bResult = false;
                sbQuery = new StringBuilder();
                sbQuery.Append("EXEC sp_ProjectMaster @TYPE='DELETEPROJECT', @PROJECT_CODE='" + _ProjectCode + "',@LOCATION_CODE='" + _LocCode + "'");
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }

        /// <summary>
        /// Get employee code/name to be populated into dropdownlist.
        /// </summary>
        /// <returns></returns>
        public DataTable GetEmployee(string CompCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("SELECT EMPLOYEE_CODE,EMPLOYEE_NAME FROM EMPLOYEE_MASTER WHERE ACTIVE = '1' AND COMP_CODE='" + CompCode + "'");
            sbQuery.Append(" ORDER BY EMPLOYEE_NAME");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Get department code/name to be populated into dropdownlist.
        /// </summary>
        /// <returns></returns>
        public DataTable GetDepartment(string CompCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("SELECT DEPT_CODE,DEPT_NAME FROM DEPARTMENT_MASTER WHERE ACTIVE = '1' AND COMP_CODE='" + CompCode + "'");
            sbQuery.Append(" ORDER BY DEPT_NAME");
            return oDb.GetDataTable(sbQuery.ToString());
        }
    }
}