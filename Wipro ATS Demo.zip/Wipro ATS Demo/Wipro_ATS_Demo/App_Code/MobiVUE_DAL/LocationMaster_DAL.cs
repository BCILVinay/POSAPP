﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Text;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MobiVUE_ATS.PRP;

namespace MobiVUE_ATS.DAL
{
    /// <summary>
    /// Summary description for LocationMaster_DAL
    /// </summary>
    public class LocationMaster_DAL
    {
        clsDb oDb;
        StringBuilder sbQuery;
        public LocationMaster_DAL(string DatabaseType)
        {
            oDb = new clsDb();
            if (DatabaseType != "")
                oDb.Connect(DatabaseType);
        }
        ~LocationMaster_DAL()
        {
            oDb.Disconnect();
            oDb = null;
            sbQuery = null;
        }

        /// <summary>
        /// Save/Update location master details.
        /// </summary>
        /// <param name="OpType"></param>
        /// <param name="oPRP"></param>
        /// <returns></returns>
        //public bool SaveUpdateLocation(string OpType, LocationMaster_PRP oPRP)
        //{
        //    try
        //    {
        //        bool bResult = false;
        //        if (OpType == "SAVE")
        //        {
        //            if (!CheckDuplicateLocation(oPRP.LocCode.Trim(),oPRP.CompCode.Trim()))
        //            {
        //                //Add new Location...
        //                sbQuery = new StringBuilder();
        //                sbQuery.Append("INSERT INTO LOCATION_MASTER ([LOC_CODE],[LOC_NAME],[PARENT_LOC_CODE],[COMP_CODE],[DESCRIPTION],[LOC_LEVEL],[ACTIVE],[CREATED_BY],[CREATED_ON])");
        //                sbQuery.Append(" VALUES ");
        //                sbQuery.Append("('" + oPRP.LocCode.Trim() + "','" + oPRP.LocName.Trim() + "','" + oPRP.ParentLocCode.Trim() + "','" + oPRP.CompCode + "','" + oPRP.LocDesc + "'," + oPRP.LocLevel + ",");
        //                sbQuery.Append(" '" + oPRP.Active + "', '" + oPRP.CreatedBy.Trim() + "', GETDATE())");
        //            }
        //        }
        //        if (OpType == "UPDATE")
        //        {
        //            //Update Location Details...
        //            sbQuery = new StringBuilder();
        //            sbQuery.Append("UPDATE LOCATION_MASTER SET [LOC_NAME] = '" + oPRP.LocName.Trim() + "',[PARENT_LOC_CODE] = '" + oPRP.ParentLocCode.Trim() + "',");
        //            sbQuery.Append(" [COMP_CODE] = '" + oPRP.CompCode.Trim() + "',[DESCRIPTION] = '" + oPRP.LocDesc.Trim() + "',");
        //            sbQuery.Append(" [LOC_LEVEL] = " + oPRP.LocLevel + ",[ACTIVE] = '" + oPRP.Active + "',[MODIFIED_BY] = '" + oPRP.ModifiedBy.Trim() + "',[MODIFIED_ON]=GETDATE()");
        //            sbQuery.Append(" WHERE [LOC_CODE] = '" + oPRP.LocCode.Trim() + "' AND [COMP_CODE]='" + oPRP.CompCode + "'");
        //        }
        //        int iRes = oDb.ExecuteQuery(sbQuery.ToString());
        //        if (iRes > 0)
        //            bResult = true;
        //        return bResult;
        //    }
        //    catch (Exception ex)
        //    { throw ex; }
        //}

        public bool SaveLocation(LocationMaster_PRP oPRP)
        {
            try
            {
                bool bResult = false;
                if (!CheckDuplicateLocation(oPRP.LocCode, oPRP.StorageLocCode))
                {
                    sbQuery = new StringBuilder();
                    sbQuery.Clear();
                    sbQuery.Append("EXEC sp_AssetLocationMaster @TYPE='SAVELOCATION', @Comp_Code='"+oPRP.CompCode+"' , @LOC_CODE='" + oPRP.LocCode.Trim().Replace("'", "''") + "',@LOC_NAME='" + oPRP.LocName.Trim().Replace("'", "''") + "',");
                    sbQuery.Append(" @PARENT_LOC_CODE='" + oPRP.ParentLocCode.Trim().Replace("'", "''") + "', @STORAGE_LOC_CODE='" + oPRP.StorageLocCode + "',");
                    sbQuery.Append(" @LOC_LEVEL='" + oPRP.LocLevel + "', @REMARKS='" + oPRP.LocDesc.Trim() + "',@ACTIVE='" + oPRP.Active + "',@CREATED_BY='" + oPRP.CreatedBy + "'");
                }

                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }

        public bool UpdateLocation(LocationMaster_PRP oPRP)
        {
            try
            {
                bool bResult = false;
                sbQuery = new StringBuilder();
                sbQuery.Clear();
                sbQuery.Append("EXEC sp_AssetLocationMaster @TYPE='UPDATELOCATION',@LOC_CODE='" + oPRP.LocCode.Trim().Replace("'", "''") + "',@LOC_NAME='" + oPRP.LocName.Trim().Replace("'", "''") + "',");
                sbQuery.Append(" @PARENT_LOC_CODE='" + oPRP.ParentLocCode.Trim().Replace("'", "''") + "', @STORAGE_LOC_CODE='" + oPRP.StorageLocCode + "',");
                sbQuery.Append(" @LOC_LEVEL='" + oPRP.LocLevel + "', @REMARKS='" + oPRP.LocDesc.Trim() + "',@ACTIVE='" + oPRP.Active + "',@MODIFIED_BY='" + oPRP.ModifiedBy + "'");
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }

        /// <summary>
        /// Check duplicate location code.
        /// </summary>
        /// <param name="_LocCode"></param>
        /// <returns></returns>
        private bool CheckDuplicateLocation(string _LocCode, string _StorageLocCode)
        {
            try
            {
                bool bDup = false;
                sbQuery = new StringBuilder();
                sbQuery.Append("EXEC sp_AssetLocationMaster @TYPE='CHECKDUPLICATELOCATION', @LOC_CODE='" + _LocCode + "', @STORAGE_LOC_CODE='" + _StorageLocCode + "'");                
                DataTable dt = oDb.GetDataTable(sbQuery.ToString());
                if (dt.Rows.Count > 0)
                    bDup = true;
                return bDup;
            }
            catch (Exception ex)
            { throw ex; }
        }

        //public DataTable GetLocationCode(string _CompCode,  string _ParentLocCode, int _LocLevel)
        //{
        //    sbQuery = new StringBuilder();
        //    //sbQuery.Append("SELECT LOC_CODE, LOC_NAME FROM dbo.LOCATION_MASTER");
        //    //sbQuery.Append(" WHERE COMP_CODE='" + _CompCode + "' AND PARENT_LOC_CODE='" + _ParentLocCode + "' AND LOC_LEVEL=" + _LocLevel + "");
        //    sbQuery.Append("EXEC sp_AssetLocationMaster @TYPE='GETLOCATIONCODE', @LOC_CODE='" + _ParentLocCode + "',@LOC_LEVEL=" + _LocLevel + "");
        //    return oDb.GetDataTable(sbQuery.ToString());
        //}

        /// <summary>
        /// Get location code and level from selected location name.
        /// </summary>
        /// <param name="_ParentLocCode"></param>
        /// <param name="_LocLevel"></param>
        /// <returns></returns>
        public DataTable GetLocationCode(string _CompCode,string _StorageLocationCode ,string _ParentLocCode, int _LocLevel)
        {
            sbQuery = new StringBuilder();
            //sbQuery.Append("SELECT LOC_CODE, LOC_NAME FROM dbo.LOCATION_MASTER");
            //sbQuery.Append(" WHERE COMP_CODE='" + _CompCode + "' AND PARENT_LOC_CODE='" + _ParentLocCode + "' AND LOC_LEVEL=" + _LocLevel + "");
            sbQuery.Append("EXEC sp_AssetLocationMaster @TYPE='GETLOCATIONCODE',  @STORAGE_LOC_CODE = '" + _StorageLocationCode + "' , @LOC_CODE='" + _ParentLocCode + "',@LOC_LEVEL=" + _LocLevel + ""); 
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Get all existing locations to be populated in the grid.
        /// </summary>
        /// <returns></returns>
        public DataTable GetLocation(string _StorageLocCode)
        {
            try
            {
                sbQuery = new StringBuilder();
                //sbQuery.Append("SELECT CM.COMP_NAME,LM.LOC_CODE,LM.LOC_NAME,LM.PARENT_LOC_CODE,LM.DESCRIPTION,LM.LOC_LEVEL,LM.ACTIVE,");
                //sbQuery.Append("LM.CREATED_BY,CONVERT(VARCHAR,LM.CREATED_ON,105) AS CREATED_ON FROM LOCATION_MASTER LM");
                //sbQuery.Append(" INNER JOIN COMPANY_MASTER CM ON LM.COMP_CODE = CM.COMP_CODE");
                //sbQuery.Append(" WHERE LM.COMP_CODE='" + _CompCode + "'");
                sbQuery.Append("EXEC sp_AssetLocationMaster @TYPE='GETLOCATIONDETAILS', @STORAGE_LOC_CODE='" + _StorageLocCode + "'");               
                return oDb.GetDataTable(sbQuery.ToString());
            }
            catch (Exception ex)
            { throw ex; }
        }

        /// <summary>
        /// Fetches Company Details For DropDownList Population
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable GetCompany()
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("SELECT COMP_CODE,COMP_NAME FROM COMPANY_MASTER WHERE ACTIVE=1");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Fetches Company details for mapping with user id
        /// </summary>
        /// <returns></returns>
        //public string GetCompany()
        //{
        //    string _CompCode = "";
        //    sbQuery = new StringBuilder();
        //    sbQuery.Append("SELECT COMP_CODE,COMP_NAME FROM COMPANY_MASTER");
        //    DataTable dt = oDb.GetDataTable(sbQuery.ToString());
        //    if (dt.Rows.Count > 0)
        //    {
        //        _CompCode = dt.Rows[0]["COMP_CODE"].ToString();
        //    }
        //    return _CompCode;
        //}

        /// <summary>
        /// Delete a particular location from data table.
        /// </summary>
        /// <param name="_LocCode"></param>
        /// <returns></returns>
        //public string DeleteLocation(string _LocCode, string _CompCode)
        //{
        //    try
        //    {
        //        string DelRslt = "";
        //        sbQuery = new StringBuilder();
        //        sbQuery.Append("SELECT COUNT(*) AS CHLOC FROM LOCATION_MASTER");
        //        sbQuery.Append(" WHERE PARENT_LOC_CODE='" + _LocCode.Trim() + "'");
        //        DataTable dt = oDb.GetDataTable(sbQuery.ToString());
        //        if (dt.Rows.Count > 0)
        //        {
        //            int iChild = 0;
        //            int.TryParse(dt.Rows[0]["CHLOC"].ToString(), out iChild);
        //            if (iChild > 0)
        //            {
        //                DelRslt = "CHILD_FOUND";
        //                return DelRslt;
        //            }
        //        }
        //        sbQuery = new StringBuilder();
        //        sbQuery.Append("SELECT COUNT(*) AS LOCFOUND FROM ASSET_ACQUISITION WHERE ASSET_LOCATION='" + _LocCode + "'");
        //        DataTable dtRefChk = oDb.GetDataTable(sbQuery.ToString());
        //        if (dtRefChk.Rows[0]["LOCFOUND"].ToString() != "0")
        //        {
        //            DelRslt = "LOCATION_IN_USE";
        //            return DelRslt;
        //        }
        //        sbQuery = new StringBuilder();
        //        sbQuery.Append("DELETE FROM [LOCATION_MASTER] WHERE [LOC_CODE] = '" + _LocCode.Trim() + "' AND [COMP_CODE]='" + _CompCode + "'");
        //        int iRes = oDb.ExecuteQuery(sbQuery.ToString());
        //        if (iRes > 0)
        //            DelRslt = "SUCCESS";
        //        return DelRslt;
        //    }
        //    catch (Exception ex)
        //    { throw ex; }
        //}

        public bool DeleteLocation(string _LocCode, string _StorageLocCode)
        {
            try
            {
                bool bResult = false;
                sbQuery = new StringBuilder();
                sbQuery.Append("EXEC sp_AssetLocationMaster @TYPE='DELETELOCATION', @LOC_CODE='" + _LocCode + "',@STORAGE_LOC_CODE='" + _StorageLocCode + "'");
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }

        /// <summary>
        /// Get Location level for parent child relationship (maximum 6 levels).
        /// </summary>
        /// <param name="_LocCode"></param>
        /// <returns></returns>
        public DataTable GetLocationCodeLevel(string _LocCode)
        {
            sbQuery = new StringBuilder();
            //sbQuery.Append("SELECT LOC_CODE,LOC_LEVEL FROM LOCATION_MASTER");
            //sbQuery.Append(" WHERE LOC_CODE LIKE '" + _LocCode + "%'");
            sbQuery.Append("EXEC sp_AssetLocationMaster @TYPE='GETLOCATIONCODELEVEL', @LOC_CODE='" + _LocCode + "'");
            return oDb.GetDataTable(sbQuery.ToString());
        }
    }
}