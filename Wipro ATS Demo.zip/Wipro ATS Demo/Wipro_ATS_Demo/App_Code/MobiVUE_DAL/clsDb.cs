using System;
using System.Text;
using System.Data;
using System.IO;
using System.Configuration;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace MobiVUE_ATS.DAL
{
    public class clsDb
    {
        SqlConnection m_Con;
        SqlTransaction sqlTrans;
        SqlCommand com;
        #region PUBLIC PROPERTY
        private string m_DataSource;
        public string DataSource
        {
            get { return m_DataSource; }
            set { m_DataSource = value; }
        }
        private string m_UserID;
        public string UserID
        {
            get { return m_UserID; }
            set { m_UserID = value; }
        }
        private string m_Password;
        public string Password
        {
            get { return m_Password; }
            set { m_Password = value; }
        }
        private string m_InitialCatalog;
        public string InitialCatalog
        {
            get { return m_InitialCatalog; }
            set { m_InitialCatalog = value; }
        }

        private bool m_IsConnected;
        public bool IsConnected
        {
            get { return m_IsConnected; }
            set { m_IsConnected = value; }
        }
        #endregion

        private string _dataBaseType = string.Empty;

        public clsDb()
        {
            //ReadSetting();
            this.m_Con = this.m_Con ?? new SqlConnection();
        }

        //~clsDb()
        //{
        //    if (this.m_Con.State == ConnectionState.Open)
        //    {
        //        lock (this)
        //        {
        //            this.m_Con.Close();
        //            m_Con = null;
        //        }
        //    }

        //}
        void ReadSetting()
        {
            //StreamReader sr = new StreamReader(Application.StartupPath + "\\DBSettings.txt");
            //this.DataSource = sr.ReadLine();
            //this.InitialCatalog = sr.ReadLine();
            //this.UserID = sr.ReadLine();
            //this.Password = sr.ReadLine();
            //sr.Close();
        }

        /// <summary>
        /// Connect to Database as per asset type provided.
        /// </summary>
        public void Connect(string DatabaseType)
        {
            try
            {
                this._dataBaseType = DatabaseType;
                string strConnectionString = string.Empty;
                if (DatabaseType == "IT")
                {
                    clsGeneral.gStrAssetType = "IT";
                    strConnectionString = ConfigurationManager.AppSettings["ConnStrIT"].ToString();
                }
                if (DatabaseType == "ADMIN")
                {
                    clsGeneral.gStrAssetType = "ADMIN";
                    strConnectionString = ConfigurationManager.AppSettings["ConnStrAdmin"].ToString();
                }

                if (this.m_Con.State == ConnectionState.Open)
                {
                    this.m_Con.Close();
                    m_Con.ConnectionString = strConnectionString;
                    this.m_Con.Open();
                    com = new SqlCommand();
                    com = m_Con.CreateCommand();
                }
                else if (this.m_Con.State == ConnectionState.Closed)
                {
                    m_Con.ConnectionString = strConnectionString;
                    this.m_Con.Open();
                    com = new SqlCommand();
                    com = m_Con.CreateCommand();
                }


                m_IsConnected = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Begin Transection
        /// </summary>
        public void BeginTrans()
        {
            //sqlTrans = new SqlTransaction();
            try
            {
                if (this.m_Con.State == ConnectionState.Closed)
                {
                    this.m_Con.Open();
                }
                sqlTrans = m_Con.BeginTransaction(IsolationLevel.ReadCommitted);
                com.Transaction = sqlTrans;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Commit Transection
        /// </summary>
        public void CommitTrans()
        {
            try
            {
                sqlTrans.Commit();
                sqlTrans.Dispose();
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Rollback trasection
        /// </summary>
        ///       
        public void RollBack()
        {
            try
            {
                sqlTrans.Rollback();
                sqlTrans.Dispose();
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Disconnect database connection
        /// </summary>
        public void Disconnect()
        {
            try
            {
                if (m_Con != null && m_Con.State == ConnectionState.Open)
                {
                    com.Dispose();
                    m_Con.Close();
                    m_IsConnected = false;
                }
            }
            catch (Exception ex)
            {
                //throw ex;
            }
        }

        /// <summary>
        /// Fetch data from data set 
        /// </summary>
        /// <param name="strSql"></param>
        /// <returns></returns>
        public DataSet GetDataSet(string strSql)
        {
            DataSet ds = new DataSet();
            SqlDataAdapter da;
            try
            {
                if (this.m_Con.State == ConnectionState.Closed)
                {
                    this.Connect(_dataBaseType);
                }

                ds = new DataSet();
                da = new SqlDataAdapter(strSql, m_Con);
                da.Fill(ds);
                da.Dispose();
                if (this.m_Con.State == ConnectionState.Open)
                {
                    Disconnect();
                }


            }
            catch (Exception ex)
            { throw ex; }
            return ds;
        }

        public DataTable GetDataTable(string strSql)
        {
            DataTable dt = new DataTable();
            SqlDataAdapter da;
            try
            {
                if (this.m_Con.State == ConnectionState.Closed)
                {
                    this.Connect(_dataBaseType);
                }


                dt = new DataTable();
                da = new SqlDataAdapter(strSql, m_Con);
                da.Fill(dt);
                da.Dispose();

                if (this.m_Con.State == ConnectionState.Open)
                {
                    Disconnect();
                }

            }
            catch (Exception ex)
            { throw ex; }
            return dt;
        }

        public DataTable GetDataTableInTransaction(string strSql)
        {
            DataTable dt = new DataTable();
            SqlDataAdapter da;
            try
            {
                if (this.m_Con.State == ConnectionState.Closed)
                {
                    this.Connect(_dataBaseType);
                }

                dt = new DataTable();
                da = new SqlDataAdapter(strSql, m_Con);
                da.SelectCommand.Transaction = sqlTrans;
                da.Fill(dt);
                da.Dispose();

                if (this.m_Con.State == ConnectionState.Open && this.sqlTrans == null)
                {
                    Disconnect();
                }

            }
            catch (Exception ex)
            { throw ex; }
            return dt;
        }

        public DataSet GetDataSetInTransaction(string strSql)
        {
            DataSet ds = new DataSet();
            SqlDataAdapter da;
            try
            {
                if (this.m_Con.State == ConnectionState.Closed)
                {
                    this.Connect(_dataBaseType);
                }

                ds = new DataSet();
                da = new SqlDataAdapter(strSql, m_Con);
                da.SelectCommand.Transaction = sqlTrans;
                da.Fill(ds);
                da.Dispose();

                if (this.m_Con.State == ConnectionState.Open)
                {
                    Disconnect();
                }

            }
            catch (Exception ex)
            { throw ex; }
            return ds;
        }

        public int ExecuteQuery(string StrSql)
        {
            int result = 0;
            try
            {
                if (this.m_Con.State == ConnectionState.Closed)
                {
                    this.Connect(_dataBaseType);
                }
                com.CommandText = StrSql;
                com.CommandTimeout = 0;
                result = com.ExecuteNonQuery();

                //if (this.m_Con.State == ConnectionState.Open && this.sqlTrans == null)
                //{
                //    Disconnect();
                //}
            }
            catch (Exception ex)
            { throw ex; }
            return result;
        }

        public int ExecuteQueryTran(string StrSql)
        {
            int result = 0;
            try
            {
                if (this.m_Con.State == ConnectionState.Closed)
                {
                    this.Connect(_dataBaseType);
                }

                com.Transaction = sqlTrans;
                com.CommandText = StrSql;
                result = com.ExecuteNonQuery();

                if (this.m_Con.State == ConnectionState.Open)
                {
                    Disconnect();
                }
            }
            catch (Exception ex)
            { throw ex; }
            return result;
        }

        public void ExecuteCommand(SqlCommand cmd)
        {
            try
            {
                if (this.m_Con.State == ConnectionState.Closed)
                {
                    this.Connect(_dataBaseType);
                }

                cmd.Connection = m_Con;
                cmd.CommandTimeout = 0;
                cmd.ExecuteNonQuery();
                if (this.m_Con.State == ConnectionState.Open)
                {
                    Disconnect();
                }
            }
           catch (Exception)
            { throw; }
        }

        public SqlDataReader GetRecord(SqlCommand cmd)
        {
            try
            {
                if (this.m_Con.State == ConnectionState.Open)
                {
                    this.m_Con.Close();
                    this.m_Con.Open();
                }
                else if (this.m_Con.State == ConnectionState.Closed)
                {
                    this.m_Con.Open();
                }

                cmd.Connection = this.m_Con;
                return cmd.ExecuteReader(CommandBehavior.CloseConnection);
            }
            catch (Exception)
            {
                throw;
            }
        }


        /// <summary>
        ///  For using this function you need to open connection where you call and open Transation 
        ///  for open Connection Connect(database) function call  and beginTran() call  after execute function close the connection.
        /// </summary>
        /// <param name="cmd"></param>
        /// <returns></returns>
        public int ExecuteQueryWithTransation(SqlCommand cmd)
        {
            var ctr = default(Int32);
            try
            {
                cmd.Transaction = sqlTrans;
                cmd.Connection = m_Con;
                ctr = cmd.ExecuteNonQuery();
                return ctr;
            }

            catch (Exception ex)
            {
                sqlTrans.Rollback();
                throw ex;
            }
        }


        public int ExecuteSQLQuery(string StrSql)
        {
            int result = 0;
            try
            {
                com.CommandText = StrSql;
                com.CommandType = CommandType.Text;
                result = com.ExecuteNonQuery();
            }
            catch (Exception ex)
            { throw ex; }
            return result;
        }


        public DataTable GetDataTable(SqlCommand cmd)
        {
            try
            {
                if (this.m_Con.State == ConnectionState.Closed)
                {
                    this.Connect(_dataBaseType);
                }

                cmd.Connection = m_Con;
              DataSet ds = new DataSet();
              SqlDataAdapter  da = new SqlDataAdapter();
              da.SelectCommand = cmd;
              da.Fill(ds);
                if (this.m_Con.State == ConnectionState.Open)
                {
                    Disconnect();
                }
                return ds.Tables[0];
            }
            catch (Exception)
            { throw; }
        }


    }
}