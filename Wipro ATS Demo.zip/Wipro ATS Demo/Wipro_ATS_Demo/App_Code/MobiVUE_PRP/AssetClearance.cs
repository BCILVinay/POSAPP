﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for AssetClearance
/// </summary>
/// 

public class Clearance
{
    public AssetRequest AssetRequest { get; set; }
    public List<UploadDocument> Documents { get; set; }
    public List<AssetClearance> AssetClerance { get; set; }
    
    public Clearance()
    {
        this.AssetRequest = default(AssetRequest);
        this.Documents = new List<UploadDocument>();
        this.AssetClerance = new List<AssetClearance>();
    }

}
public class AssetClearance 
{

    public int ClearanceCode { get; set; }
    public string Description { get; set; }
    public string Type { get; set; }
    public string CreatedBY { get; set; }
    public DateTime? CreatedOn { get; set; }
   
    public bool IsClearanced { get; set; }
    public DateTime? ClearanceOn { get; set; }
    public string ClearanceBy { get; set; }
    public String Remarks { get; set; }

    public AssetClearance()
    {
        this.ClearanceCode = 0;
        this.Description = string.Empty;
        this.Type = string.Empty;
        this.CreatedBY = string.Empty;
        this.CreatedOn = default(DateTime?);
        this.IsClearanced = default(bool);
    }

    

}