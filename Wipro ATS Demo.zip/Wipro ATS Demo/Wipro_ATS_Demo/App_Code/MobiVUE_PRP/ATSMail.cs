﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Web;

/// <summary>
/// Summary description for ATSMail
/// </summary>
public class ATSMail
{
    private readonly string DisplayName = "ATS";
    private MailMessage _atsMail = null;
    private SmtpClient _atsMailClient = null;
    private MailAddress _fromAddress = null;

    public readonly string HostName;
    public readonly int Port;
    public readonly string From;
    public readonly string UserId;
    public readonly string password;

    public string Recipients { get; set; }
    public string Subject { get; set; }
    public string MailContent { get; set; }
    public bool IsBodyHtml { get; set; }

    /// <summary>
    /// thread logic
    /// </summary>
    /// <param name="hostName"></param>
    /// <param name="port"></param>
    /// <param name="from"></param>

    // private bool 

    public ATSMail(string hostName, int port, string from, string userId, string password)
    {
        this.HostName = hostName;
        this.Port = port;
        this.From = from;
        this.UserId = userId;
        this.password = password;
        _atsMail = new MailMessage();
        _atsMailClient = new SmtpClient();
        _fromAddress = new MailAddress(this.From, this.DisplayName);
        _atsMailClient.Host = this.HostName;
        _atsMailClient.Port = this.Port;
        _atsMail.From = _fromAddress;

    }
    public bool Send(string Recipients, string Subject, bool IsMailHtmlBody, string MailBody)
    {
        try
        {
            this.Recipients = Recipients;
            this.Subject = Subject;
            this.IsBodyHtml = IsBodyHtml;
            this.MailContent = MailBody;
            _atsMail.Body = this.MailContent;
            bool result = this.SendMail();
            return result;
        }
        catch (Exception)
        {
            return false;
        }
    }

    public bool Send()
    {
        try
        {
            bool result = this.SendMail();
            return result;
        }
        catch (Exception)
        {
            return false;
        }
    }

    private bool SendMail()
    {
        try
        {
            _atsMail.To.Add(this.Recipients);
            _atsMail.Subject = this.Subject;
            _atsMail.IsBodyHtml = this.IsBodyHtml;
            this._atsMailClient.Send(this._atsMail);
            return true;
        }
        catch (Exception)
        {
            return false;
        }
    }


}

public class Mail
{
    public void  SendMailForApproval(string hostName, string port, string userId, string password, string senderEmail, string ToEmail, string AssetCode, string ActionByUser)
    {
        SmtpClient smtpClient = new SmtpClient();
        MailMessage message = new MailMessage();
        MailAddress fromAddress = new MailAddress(senderEmail, "RTS");
        smtpClient.Host = hostName;
        smtpClient.Port = int.Parse(port);
        smtpClient.UseDefaultCredentials = false;
        smtpClient.EnableSsl = true;
        smtpClient.Credentials = new NetworkCredential(userId, password);
        message.From = fromAddress;
        message.To.Add(ToEmail);

        message.Subject = "WIPRO : RTS - Asset Received";
        message.IsBodyHtml = false;
        StringBuilder sbMsg = new StringBuilder();
        //  sbMsg.AppendLine("Please Note,");
        sbMsg.AppendLine("");
        sbMsg.AppendLine("An asset has been received with asset code as : " + AssetCode + " by '" + ActionByUser + "'.");
        sbMsg.AppendLine("");
        //sbMsg.AppendLine("Company/Location : " + Session["COMP_NAME"] + ".");
        sbMsg.AppendLine("");
        //sbMsg.AppendLine("Kindly approve the same.");
        sbMsg.AppendLine("");
        sbMsg.AppendLine("");
        sbMsg.AppendLine("");
        //sbMsg.AppendLine("http://10.164.91.191/FIS_ATS/WebPages/UserLogin.aspx");
        message.Body = sbMsg.ToString();
        smtpClient.Send(message);
    }
}

