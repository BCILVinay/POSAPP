﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for AssetApprove
/// </summary>
public class AssetApprove
{
    public AssetApprove()
    {
        this.AssetRequest = new AssetRequest();
        this.Documents = new List<UploadDocument>();
        this.Remark = string.Empty;
    }

    public AssetRequest AssetRequest { get; set; }

    public List<UploadDocument> Documents { get; set; }

    public string Remark { get; set; }

}

public class MovementConfig
{
    public string RequestStage { get; set; }
    public int RequestOrder { get; set; }
    public bool IsActive { get; set; }

    public MovementConfig()
    {
        this.RequestStage = string.Empty;
        this.RequestOrder = default(int);
        this.IsActive = default(bool);
    }
}